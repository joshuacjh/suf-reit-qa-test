class CompanyDetails {
    _isEnabled = true;

    get prefix() {
        return this._prefix;
    }

    constructor(prefix) {
        this._prefix = prefix;
    }

    set isEnabled(val) {
        this._isEnabled = val;
    }

    init() {
        //Util.InitPartialViews(".cd");
        $("select.cd").select2({ destroy: true, width: "100%" });
        this.bindEvents(this._prefix);
        $(`#${this._prefix}Country`).trigger("select2:select");
    }

    bindEvents(prefix) {
        $(`#${prefix}Country`).on("select2:select", events.RetrieveStates_change);
        $(`#${prefix}State`).on("select2:select", events.RetrieveCities_change);
        $(`#${prefix}City`).on("change", events.RetrieveDistricts_change);
        //$(`#${prefix}Country`).change(events.RetrieveStates_change);
        //$(`#${prefix}State`).change(events.RetrieveCities_change);
        //$(`#${prefix}City`).change(events.RetrieveDistricts_change);
    }

    initAjax(companyID) {
        let prefix = this._prefix;
        let isEnabled = this._isEnabled;
        $.get(cdUrl.GetCompanyByIDUrl, { "companyID": companyID }, function (result) {
            //console.log(result);
            let coy = new CompanyDetails(prefix);
            coy.isEnabled = isEnabled;
            coy.setDetails(result);

        }).fail(function (xhr, textStatus, errorThrown) {
            console.log(xhr.responseText);
            var error = $($.parseHTML(xhr.responseText)[1]).text();
            Util.alert("Company details", `Exception occurred : ${error}.`, true);
        });
    }

    getDetails() {
        let phoneNo = $("#" + this._prefix + "PhoneNo").val().trim();
        let taxRegNo = $("#" + this._prefix + "TaxRegNo").val().trim();
        let postcodeVal = $("#" + this._prefix + "Postcode").val().trim();
        let sstVal = $("#" + this._prefix + "SSTRegistrationNo").val().trim();

        return {
            "CompanyCode": $("#" + this._prefix + "CompanyCode").val() || "",
            "CompanyName": $("#" + this._prefix + "CompanyName").val() || "",
            "IsIFCACompany": parseInt($("input[name='" + this._prefix + "ifcacompany']:checked").val()) === 1,
            "IsJVCompany": parseInt($("input[name='" + this._prefix + "jvcompany']:checked").val()) === 1,
            "RegistrationNo": $("#" + this._prefix + "RegNo").val() || "",
            "TaxTypefoTaxTypeID": $("#" + this._prefix + "TaxType").val() || null,
            "TaxRegistrationNo": taxRegNo === "" ? null : taxRegNo,
            "CompanyAddressLine1": $("#" + this._prefix + "Addr1").val() || "",
            "CompanyAddressLine2": $("#" + this._prefix + "Addr2").val() || "",
            "CompanyAddressLine3": $("#" + this._prefix + "Addr3").val() || "",
            "CompanyAddressLine4": $("#" + this._prefix + "Addr4").val() || "",
            "CompanyAddressLine5": $("#" + this._prefix + "Addr5").val() || "",
            "CompanyfoCountryID": Util.GetSingleSelectedIDFromSelect2(`#${this._prefix}Country`) || null,
            "CompanyfoStateID": Util.GetSingleSelectedIDFromSelect2(`#${this._prefix}State`) || null,
            "CompanyfoCityID": Util.GetSingleSelectedIDFromSelect2(`#${this._prefix}City`) || null,
            "CompanyfoDistrictID": Util.GetSingleSelectedIDFromSelect2(`#${this._prefix}District`) || null,
            "CompanyPostcode": parseInt(postcodeVal) || null,
            "CompanyPhoneNo": phoneNo === "" ? null : "+60" + phoneNo,
            "CompanyEmailAddress": $("#" + this._prefix + "Email").val() || "",
            "CompanyWebsite": $("#" + this._prefix + "Website").val() || "",
            "CompanyRemark": $("#" + this._prefix + "Remark").val() || "",
            "CompanyStatus": Util.GetSingleSelectedIDFromSelect2(`#${this._prefix}CompanyStatus`) || null,
            "Status": StatusID.Draft,
            "IsDeleted": false,

            // --- Enhancement Fields ---
            "GSTRegistrationNo": $("#" + this._prefix + "GSTRegistrationNo").val() || "",
            "SSTRegistrationNo": sstVal === "" ? null : sstVal,
            "HasSST": sstVal === "" ? "No" : "Yes", // derived from SST textbox
            "eInvoicing": parseInt($("input[name='" + this._prefix + "eInvoicing']:checked").val()) === 1,
            "ClientID": $("#" + this._prefix + "ClientID").val() || "",
            "eInvoiceStartDate": $("#" + this._prefix + "eInvoiceStartDate").val() || null,
            "eInvoiceEndDate": $("#" + this._prefix + "eInvoiceEndDate").val() || null,
            "SecretKey1": $("#" + this._prefix + "SecretKey1").val() || "",
            "SecretKey2": $("#" + this._prefix + "SecretKey2").val() || "",
            "MSICCodefoID": $("#" + this._prefix + "MSICCodefoID").val() || null,
            "ClassificationCodefoID": $("#" + this._prefix + "ClassificationCodefoID").val() || null,
            "CreditorTINNo": $("#" + this._prefix + "CreditorTINNo").val() || "",
            "JDEIndustryType": $("#" + this._prefix + "JDEIndustryType").val() || "",
            "JDECompanyCode": $("#" + this._prefix + "JDECompanyCode").val() || "",
            "JDEBusinessUnitCode": $("#" + this._prefix + "JDEBusinessUnitCode").val() || "",
            "JDEEnviroment": Util.GetSingleSelectedIDFromSelect2(`#${this._prefix}JDEEnviroment`) || null
        };
    }


    setDetails(data) {
        const prefix = this._prefix;
        const isEnabled = this._isEnabled;

        // --- Radios and checkboxes ---
        $(`input[name='${prefix}ifcacompany'][value='${data.IsIFCACompany ? 1 : 0}']`).prop("checked", true);
        $(`input[name='${prefix}jvcompany'][value='${data.IsJVCompany ? 1 : 0}']`).prop("checked", true);
        $(`input[name='${prefix}eInvoicing'][value='${data.eInvoicing ? 1 : 0}']`).prop("checked", true);

        // --- Textboxes ---
        $("#" + prefix + "CompanyCode").val(data.CompanyCode || "");
        $("#" + prefix + "CompanyName").val(data.CompanyName || "");
        $("#" + prefix + "RegNo").val(data.RegistrationNo || "");
        $("#" + prefix + "TaxType").val(data.TaxTypefoTaxTypeID).change();
        $("#" + prefix + "TaxRegNo").val(data.TaxRegistrationNo || "");
        $("#" + prefix + "Addr1").val(data.CompanyAddressLine1 || "");
        $("#" + prefix + "Addr2").val(data.CompanyAddressLine2 || "");
        $("#" + prefix + "Addr3").val(data.CompanyAddressLine3 || "");
        $("#" + prefix + "Addr4").val(data.CompanyAddressLine4 || "");
        $("#" + prefix + "Addr5").val(data.CompanyAddressLine5 || "");
        $("#" + prefix + "Postcode").val(data.CompanyPostcode || "");
        $("#" + prefix + "PhoneNo").val(data.CompanyPhoneNo || "");
        $("#" + prefix + "Email").val(data.CompanyEmailAddress || "");
        $("#" + prefix + "Website").val(data.CompanyWebsite || "");
        $("#" + prefix + "Remark").val(data.CompanyRemark || "");
        $("#" + prefix + "GSTRegistrationNo").val(data.GSTRegistrationNo || "");
        $("#" + prefix + "ClientID").val(data.ClientID || "");
        $("#" + prefix + "SecretKey1").val(data.SecretKey1 || "");
        $("#" + prefix + "SecretKey2").val(data.SecretKey2 || "");
        $("#" + prefix + "MSICCodefoID").val(data.MSICCodefoID || "").change();
        $("#" + prefix + "ClassificationCodefoID").val(data.ClassificationCodefoID || "").change();
        $("#" + prefix + "CreditorTINNo").val(data.CreditorTINNo || "");
        $("#" + prefix + "JDEIndustryType").val(data.JDEIndustryType || "");
        $("#" + prefix + "JDECompanyCode").val(data.JDECompanyCode || "");
        $("#" + prefix + "JDEBusinessUnitCode").val(data.JDEBusinessUnitCode || "");

        // --- Select2 fields ---
        $(`#${prefix}Country`).val(data.CompanyfoCountryID).change();
        $(`#${prefix}JDEEnviroment`).val(data.JDEEnviroment).trigger("change.select2");
        $(`#${prefix}CompanyStatus`).val(data.CompanyStatus).trigger("change.select2");

        // --- Dates safely ---
        const parseDate = (dateStr) => {
            if (!dateStr || dateStr === '0001-01-01T00:00:00') return "";
            const d = new Date(dateStr.replace(/\D/g, ''));
            return isNaN(d.getTime()) ? "" : $.datepicker.formatDate('dd/mm/yy', d);
        };
        $("#" + prefix + "eInvoiceStartDate").val(parseDate(data.eInvoiceStartDate));
        $("#" + prefix + "eInvoiceEndDate").val(parseDate(data.eInvoiceEndDate));

        // --- SST handling ---
        this.setSST(data);

        // --- Dependent dropdowns ---
        $.get(cdUrl.GetStatesUrl, { countryID: data.CompanyfoCountryID })
            .then(result => {
                $(`#${prefix}State`).empty().append('<option value="">Select State</option>');
                $.each(result.data, (i, item) => $(`#${prefix}State`).append($('<option>', { value: item.StateIFCAID, text: item.StateIFCAName })));
                $(`#${prefix}State`).val(data.CompanyfoStateID).prop("disabled", !isEnabled).change();
                return $.get(cdUrl.GetCitiesUrl, { countryID: data.CompanyfoCountryID, stateID: data.CompanyfoStateID });
            })
            .then(result => {
                $(`#${prefix}City`).empty().append('<option value="">Select City</option>');
                $.each(result.data, (i, item) => $(`#${prefix}City`).append($('<option>', { value: item.CityIFCAID, text: item.CityIFCAName })));
                $(`#${prefix}City`).val(data.CompanyfoCityID).prop("disabled", !isEnabled).change();
                return $.get(cdUrl.GetDistrictsUrl, { countryID: data.CompanyfoCountryID, stateID: data.CompanyfoStateID, cityID: data.CompanyfoCityID });
            })
            .then(result => {
                $(`#${prefix}District`).empty().append('<option value="">Select District</option>');
                $.each(result.data, (i, item) => $(`#${prefix}District`).append($('<option>', { value: item.DistrictIFCAID, text: item.DistrictIFCAName })));
                $(`#${prefix}District`).val(data.CompanyfoDistrictID).prop("disabled", !isEnabled);
            })
            .catch(xhr => {
                const error = $($.parseHTML(xhr.responseText)[1]).text();
                Util.alert("Company details", `Exception occurred: ${error}`, true);
            });
    }

    setSST(data) {
        const prefix = this._prefix;
        const $sstInput = $("#" + prefix + "SSTRegistrationNo");
        const $hasYes = $("#HasSST_Yes");
        const $hasNo = $("#HasSST_No");

        // Derive value
        const sstVal = data?.SSTRegistrationNo?.trim() || "";

        // Initial state from DB or default
        if (sstVal === "" || sstVal === "N/A") {
            $hasNo.prop("checked", true);
            $sstInput.prop("disabled", true).val("").css("background-color", "#eee");
        } else {
            $hasYes.prop("checked", true);
            $sstInput.prop("disabled", false).val(sstVal).css("background-color", "white");
        }

        // 🔁 Always rebind to avoid duplicate events
        $("input[name='HasSST']").off("change").on("change", function () {
            if (this.value === "Yes") {
                $sstInput.prop("disabled", false).css("background-color", "white");
            } else {
                $sstInput.prop("disabled", true).val("").css("background-color", "#eee");
            }

            // 🔹 Optional: clear validation error when disabled
            const validator = $("#AddCompanyForm").data("validator");
            if (validator && $sstInput.is(":disabled")) {
                validator.successList.push($sstInput[0]);
                validator.showErrors();
            }
        });
    }


    enableDisableFields(isEnabled) {
        $("#details input, #details select, #details textarea").each(function () {
            $(this).attr("disabled", !isEnabled);
        });
    }
}

let events = {
    RetrieveDistricts_change: function (e) {
        e.preventDefault();
        let prefix = $(this).data("prefix");
        let countryID = Util.GetSingleSelectedIDFromSelect2(`#${prefix}Country`);
        let stateID = Util.GetSingleSelectedIDFromSelect2(`#${prefix}State`);
        let cityID = Util.GetSingleSelectedIDFromSelect2(`#${prefix}City`);

        let params = {
            countryID: countryID,
            stateID: stateID,
            cityID: cityID
        };

        $.get(cdUrl.GetDistrictsUrl, params, function (result) {
            //console.log(result);
            $(`#${prefix}District option:not(:first)`).remove();

            $.each(result.data, function (index, item) {
                $(`#${prefix}District`).append($('<option>', {
                    value: item.DistrictIFCAID,
                    text: item.DistrictIFCAName
                }));
            });

            $(`#${prefix}District`).prop("disabled", false);
        });
    },
    RetrieveCities_change: function (e) {
        e.preventDefault();
        let prefix = $(this).data("prefix");
        let countryID = Util.GetSingleSelectedIDFromSelect2(`#${prefix}Country`);
        let stateID = Util.GetSingleSelectedIDFromSelect2(`#${prefix}State`);
        let params = {
            countryID: countryID,
            stateID: stateID
        };

        $.get(cdUrl.GetCitiesUrl, params, function (result) {
            $(`#${prefix}City option:not(:first)`).remove();

            $.each(result.data, function (index, item) {
                $(`#${prefix}City`).append($('<option>', {
                    value: item.CityIFCAID,
                    text: item.CityIFCAName
                }));
            });

            $(`#${prefix}City`).prop("disabled", false);
        });
    },
    RetrieveStates_change: function (e) {
        e.preventDefault();
        let prefix = $(this).data("prefix");
        let countryID = Util.GetSingleSelectedIDFromSelect2(`#${prefix}Country`);
        $.get(cdUrl.GetStatesUrl, { countryID: countryID }, function (result) {
            $(`#${prefix}State option:not(:first)`).remove();

            $.each(result.data, function (index, item) {
                if ($("#CompanyID").val() === undefined && item.StateIFCAID === "43") {
                    $(`#${prefix}State`).append($('<option>', {
                        value: item.StateIFCAID,
                        text: item.StateIFCAName,
                        selected: true
                    }));

                    $(`#${prefix}State`).trigger("select2:select");
                }
                else {
                    $(`#${prefix}State`).append($('<option>', {
                        value: item.StateIFCAID,
                        text: item.StateIFCAName
                    }));
                }
            });

            $(`#${prefix}State`).prop("disabled", false);
            
        });
    }
};

let cdUrl = {
    GetStatesUrl: "",
    GetCitiesUrl: "",
    GetDistrictsUrl: ""
};

$(".input-group.datetimepicker input").datetimepicker({
    format: "DD/MM/YYYY",
    sideBySide: true,
});


