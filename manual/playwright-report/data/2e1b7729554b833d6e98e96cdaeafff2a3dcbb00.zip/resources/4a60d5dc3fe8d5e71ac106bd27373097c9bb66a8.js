var prevRoleId = '';
var prevDefaultAlternate = 0;
var teamMember = {
    Init: function () {
        //Util.InitPartialViews(".tm");

        return this;
    },
    DisableAddRowButton: function (prefix, isDisabled) {
        $(`#${prefix}Row, #${prefix}Teams button`).prop("disabled", isDisabled);
    },
    ViewTableAjax: function (prefix, url, data) {
        var tableId = `#${prefix}Teams`;

        if (prefix == 'compJV' || prefix == 'coyJV') {
            $(tableId).find('.JVPartnerDescription').html('(JV Partner)');
        }
        else {
            $(tableId).find('.JVPartnerDescription').html('');
        }

        $(tableId).DataTable().clear().destroy();
        // disable the add button
        $(`#${prefix}Row`).hide();
        // do datatable ajax
        $(tableId).DataTable({
            "ajax": {
                "url": url,
                "type": "get",
                "data": data
            },
            "searching": false,
            "paging": false,
            "info": false,
            "ordering": false,
            "autoWidth": false,
            "columnDefs": [
                {
                    "className": "center",
                    "targets": [1, 2, 3, 4,5]
                },
                {
                    "targets": 2,
                    "data": "TeamMemberUserStatus",
                    "searchable": false,
                    "orderable": false,
                    "render": function (data, row, type) {
                        var result = "";

                        if (data === 1) {
                            result = "<span class='label-custom label label-default'>Active</span>";
                        }
                        else {
                            result = "<span class='label-danger label label-default'>Inactive</span>";
                        }

                        return result;
                    }
                },
                {
                    "targets": 3,
                    "data": "DefaultAltType",
                    "searchable": false,
                    "orderable": false,
                    "render": function (data, row, type) {
                        var result = "";

                        if (data == 120) {
                            result = "Default";
                        }
                        else if (data == 121) {
                            result = "Alternate";
                        }

                        return result;
                    }
                },
                {
                    "targets": 4,
                    "searchable": false,
                    "orderable": false,
                    "render": function (data, type, row) {
                        var date = "";
                        if (row.ModifiedAt && row.ModifiedAt !== null) {
                            date = Util.DateAndTime(row.ModifiedAt);
                        }
                        else if (row.CreatedAt && row.CreatedAt !== null) {
                            date = Util.DateAndTime(row.CreatedAt);
                            if (date == "01 Jan 0001, 12:00:00 AM" || date == "01 Jan 0001, 06:46:46 AM" || date == "01/01/0001 12:00:00 AM" || date == "01/01/0001 06:46:46 AM") {
                                date = "-";
                            }
                        }
                        else {
                            date = "-";
                        }
                        return date;
                    }
                },
                {
                    "targets": 5,
                    "data": "TeamMemberID",
                    "searchable": false,
                    "orderable": false,
                    "render": function (data, row, type) {
                        //var editLink = "<button class='btn btn-add btn-sm edit-tm' rowId='" + data + "'><i class='fa fa-pencil'></i></button>"
                        var editLink = `<button class='btn btn-add btn-sm edit-tm' rowId='${data}' data-bs-toggle="modal" data-bs-target="#Member"><i class='fa fa-pencil'></i></button>`
                        var deleteButton = "<button class='btn btn-danger btn-sm delete-tm' rowId='" + data + "' style='margin-left:5px;'><i class='fa fa-times'></i></button>";
                        return editLink + deleteButton;
                    }
                }
            ],
            columns: [
                {
                    "targets": 0,
                    "width": "15%",
                    "data": function (row, type) {
                        return `${row.RoleName}<input type="hidden" name="RoleID" value="${row.RoleID}">` +
                            `<input type="hidden" name="Deleted" value="${row.IsDeleted}"`;
                    }
                },
                {
                    "targets": 1,
                    "width": "35%",
                    "data": function (row, type) {
                        if (row.TeamMemberADCompany && row.TeamMemberADCompany != null && row.TeamMemberADCompany != "") {
                            return `${row.TeamMemberADFullname + " (" + row.TeamMemberADCompany + ")"}<input type="hidden" name="UserID" value="${row.TeamMemberfoUserAccountID}">`;
                        }
                        else {
                            return `${row.TeamMemberADFullname}<input type="hidden" name="UserID" value="${row.TeamMemberfoUserAccountID}">`;
                        }
                        //return `${row.Username}<input type="hidden" name="UserID" value="${row.TeamMemberfoUserAccountID}">`;
                    }
                },
                {
                    "targets": 2,
                    "width": "10%",
                },
                {
                    "targets": 3,
                    "width": "10%",
                },
                {
                    "targets": 4,
                    "width": "20%",
                },
                {
                    "targets": 5,
                    "width": "10%",
                },
            ],
            "initComplete": function (settings, json) {
                console.log("View Team Members Result", json);
            }
        });
        // hide the action columns
        $(tableId).DataTable().column(5).visible(false);
    },
    InitTable: function (prefix) {
        var tableId = `#${prefix}Teams`;

        if (prefix == 'editJV' || prefix == 'addJV') {
            $(tableId).find('.JVPartnerDescription').html('(JV Partner)');
        }
        else {
            $(tableId).find('.JVPartnerDescription').html('');
        }
        
        $(tableId).DataTable().clear().destroy();
        $(tableId).DataTable({
            "searching": false,
            "paging": false,
            "info": false,
            "ordering": false,
            "autoWidth": false,
            "columnDefs": [
                {
                    "className": "center",
                    "targets": [1,2,3,4,5]
                },
                {
                    "targets": 2,
                    "data": "TeamMemberUserStatus",
                    "searchable": false,
                    "orderable": false,
                    "render": function (data, row, type) {
                        var result = "";

                        if (data === 1) {
                            result = "<span class='label-custom label label-default'>Active</span>";
                        }
                        else {
                            result = "<span class='label-danger label label-default'>Inactive</span>";
                        }

                        return result;
                    }
                },
                {
                    "targets": 3,
                    "data": "DefaultAltType",
                    "searchable": false,
                    "orderable": false,
                    "render": function (data, row, type) {
                        var result = "";

                        if (data == 120) {
                            result = "Default";
                        }
                        else if (data == 121) {
                            result = "Alternate";
                        }

                        return result;
                    }
                },
                {
                    "targets": 4,
                    "searchable": false,
                    "orderable": false,
                    "render": function (data, type, row) {
                        var date = "";
                        if (row.ModifiedAt && row.ModifiedAt !== null) {
                            date = Util.DateAndTime(row.ModifiedAt);
                        }
                        else if (row.CreatedAt && row.CreatedAt !== null) {
                            date = Util.DateAndTime(row.CreatedAt);
                            if (date == "01 Jan 0001, 12:00:00 AM" || date == "01 Jan 0001, 06:46:46 AM" || date == "01/01/0001 12:00:00 AM" || date == "01/01/0001 06:46:46 AM")
                            {
                                date = "-";
                            }
                        }
                        else {
                            date = "-";
                        }
                        return date;
                    }
                },
                {
                    "targets": 5,
                    "data": "TeamMemberID",
                    "searchable": false,
                    "orderable": false,
                    "render": function (data, row, type) {
                        var editLink = `<button class='btn btn-add btn-sm edit-tm' rowId='${data}'><i class='fa fa-pencil'></i></button>`;
                        var deleteButton = "<button class='btn btn-danger btn-sm delete-tm' rowId='" + data + "' style='margin-left:5px;'><i class='fa fa-times'></i></button>";
                        return editLink + deleteButton;
                    }
                }
            ],
            columns: [
                {
                    "targets": 0,
                    "width": "15%",
                    "data": function (row, type) {
                        return `${row.RoleName}<input type="hidden" name="RoleID" value="${row.RoleID}">` +
                            `<input type="hidden" name="Deleted" value="${row.IsDeleted}"`;
                    }
                },
                {
                    "targets": 1,
                    "width": "35%",
                    "data": function (row, type) {
                        if (row.TeamMemberADCompany && row.TeamMemberADCompany != null && row.TeamMemberADCompany != "") {
                            return `${row.TeamMemberADFullname + " (" + row.TeamMemberADCompany + ")"}<input type="hidden" name="UserID" value="${row.TeamMemberfoUserAccountID}">`;
                        }
                        else {
                            return `${row.TeamMemberADFullname}<input type="hidden" name="UserID" value="${row.TeamMemberfoUserAccountID}">`;
                        }
                    }
                },
                {
                    "targets": 2,
                    "width": "10%",
                },
                {
                    "targets": 3,
                    "width": "10%",
                },
                {
                    "targets": 4,
                    "width": "20%",
                },
                {
                    "targets": 5,
                    "width": "10%",
                },
            ],
            //"initComplete": function () {
            //    var handlers = teamMember.Handlers;

            //    $(tableId + " td").on("click", ".edit-tm", handlers.EditMember_click);
            //    $(tableId + " td").on("click", ".delete-tm", handlers.DeleteMember_click);
            //},
            drawCallback: function (settings) {
                var handlers = teamMember.Handlers;

                $(tableId + " td").on("click", ".edit-tm", handlers.EditMember_click);
                $(tableId + " td").on("click", ".delete-tm", handlers.DeleteMember_click);
            }
        });
        $(".newRole, .newStatus, .newUser, .newDefaultAltType").select2({ destroy: true, width: "100%" });
        return this;
    },
    SetDefaultRows: function (prefix, url, type) {
        let tableID = `#${prefix}Teams`;
        $.get(url, { memberType: type }, function (result) {

            $.each(result.data, function (index, value) {

                let data = {
                    RoleID: value.RoleId,
                    RoleName: value.RoleName,
                    TeamMemberType: 0,
                    ReferenceID: 0,
                    TeamMemberfoUserAccountID: 0,
                    Username: "",
                    TeamMemberUserStatus: 1,
                    IsDeleted: false,
                    JVPartnerID: "",
                    TeamMemberfoADID: 0,
                    TeamMemberADUsername: "",
                    TeamMemberADFullname: "",
                    TeamMemberADCompany: "",
                    TeamMemberADLabel: "",
                    DefaultAltType: 120,
                    TeamMemberADEmail: ""
                };

                $(tableID).DataTable().row.add(data).draw(false);
            });
        });
    },
    BindEvents: function (prefix) {
        var handlers = teamMember.Handlers;
        $("#" + prefix + "Row").click(handlers.NewMember_click);
        $("#" + prefix + "Save").click(handlers.AddMember_click)
        $(`#${prefix}Update`).click(handlers.UpdateMember_click)

        return this;
    },
    PopulateTeamMembers: function (data, prefix, disableEdit) {
        var tableId = `#${prefix}Teams`;
        console.log("Data to be populated to prefix " + prefix, data);
        $(tableId).DataTable().clear().draw();
        $(tableId).DataTable().rows.add(data).draw();
        
        this.BindTableEvents(prefix);

        if (disableEdit) {
            $('#projManRow').addClass('hidden');
            $(tableId).find('.edit-tm').addClass('hidden');
            $(tableId).find('.delete-tm').addClass('hidden');
        }
    },
    RetrieveData: function (prefix) {
        var tableId = `#${prefix}Teams`;
        var data = $(tableId).DataTable().rows().data().toArray();
        let result = [];
        $.each(data, function (index, value) {
            if (value.TeamMemberfoADID > 0 || (value.JVPartnerID != null && value.JVPartnerID != '')) {
                result.push(value);
            }
        });

        return result;
    },
    BindTableEvents: function (prefix) {
        var tableId = `#${prefix}Teams`;
        var handlers = teamMember.Handlers;

        $(tableId + " td").on("click", ".edit-tm", handlers.EditMember_click);
        $(tableId + " td").on("click", ".delete-tm", handlers.DeleteMember_click);
    },
    ClearData: function (prefix) {
        $("#TeamMemberID").val("");
        //$(`#${prefix}Role`).get(0).selectedIndex = 0;
        $(`#${prefix}Users`).val(null).change();
        //$(`#${prefix}TeamStatus`).get(0).selectedIndex = 0;
        //$(`#${prefix}TeamDefaultAltType`).get(0).selectedIndex = 0;
        //$(`#${prefix}TeamStatus`).val($(`#${prefix}TeamStatus option:first`).val());
        //$(`#${prefix}TeamDefaultAltType`).val($(`#${prefix}TeamDefaultAltType option:first`).val());
        $(`#${prefix}TeamStatus`).prop("selectedIndex", 0).change();
        $(`#${prefix}TeamDefaultAltType`).prop("selectedIndex", 0).change();
    },
    GetUsers: function (prefix) {
        var tableId = `#${prefix}Teams`;
        var data = $(tableId).DataTable().rows().data().toArray();
        let result = [];
        $.each(data, function (index, value) {
            if (value.TeamMemberfoADID > 0 || (value.JVPartnerID != null && value.JVPartnerID != '')) {
                result.push(value);
            }
        });

        return result;
    }
};

teamMember.Handlers = {
    UpdateMember_click: function (e) {
        e.preventDefault();
        let prefix = $("#Prefix").val();
        var usr = $(`#${prefix}EditUser`).select2("data");
        //let userID = Util.GetSingleSelectedIDFromSelect2(`#${prefix}EditUser`);

        var adUsername = "";
        if (usr[0].username && usr[0].username != '') {
            adUsername = usr[0].username;
        }
        else {
            if (usr[0].title && usr[0].title != '') {
                adUsername = usr[0].title;
            }
        }

        var adFullname = "";
        if (usr[0].fullname && usr[0].fullname != '') {
            adFullname = usr[0].fullname;
        }
        else {
            if (usr[0].element.dataset['fullname'] && usr[0].element.dataset['fullname'] != '') {
                adFullname = usr[0].element.dataset['fullname'];
            }
        }

        var adCompany = "";
        if (usr[0].company && usr[0].company != '') {
            adCompany = usr[0].company;
        }
        else {
            if (usr[0].element.dataset['company'] && usr[0].element.dataset['company'] != '') {
                adCompany = usr[0].element.dataset['company'];
            }
        }

        var userEmail = "";
        if (usr[0].userEmail && usr[0].userEmail != '') {
            userEmail = usr[0].userEmail;
        }
        else {
            if (usr[0].element.dataset['userEmail'] && usr[0].element.dataset['userEmail'] != '') {
                userEmail = usr[0].element.dataset['userEmail'];
            }
        }

        //validate Default/Alternate
        var existingUsers = [];

        if (prefix == "addJV" || prefix == "editJV") {
            existingUsers = existingUsers.concat(teamMember.GetUsers("addJV"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("editJV"));
        }
        else {
            existingUsers = existingUsers.concat(teamMember.GetUsers("addMem"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("addDir"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("addCom"));

            existingUsers = existingUsers.concat(teamMember.GetUsers("editMem"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("editDir"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("editCom"));

            existingUsers = existingUsers.concat(teamMember.GetUsers("compMem"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("compDir"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("compCom"));

            existingUsers = existingUsers.concat(teamMember.GetUsers("phaseMem"));
        }

        var userId = usr[0].id;
        var roleId = Util.GetSingleSelectedIDFromSelect2(`#${prefix}EditRole`);
        var roleName = $(`#${prefix}EditRole option:selected`).text();
        var defaultAlternate = parseInt($(`#${prefix}EditTeamDefaultAltType`).val());
        var isDefaultRole = defaultAlternate == "120";
        var isActive = parseInt($(`#${prefix}TeamStatus`).val());

        if (prevRoleId == roleId && prevDefaultAlternate == defaultAlternate) {

        }
        else {
            var alreadyHasDefaultRole = existingUsers.some(i => i.RoleID === roleId && i.DefaultAltType === 120); 
            if (isDefaultRole) {
                //validation - only one default role for one role can be added
                if (alreadyHasDefaultRole) {
                    Util.alert("Unable to add User",
                        "Default role for " + roleName + " already exists, please add as Alternate role.",
                        true);
                    return false;
                }
            }
            else {
                //validation - must have default role first before allow to add Alternate role
                if (!alreadyHasDefaultRole) {
                    Util.alert("Unable to add User",
                        "You must add Default role first before adding Alternate role.",
                        true);
                    return false;
                }

                var userIDSets = new Set();
                usr.forEach(i => userIDSets.add(Number.parseInt(i.id, 10)));
                var userAltRoleExist = $(`#${prefix}Teams`).DataTable().rows().data().toArray().find(i => i.RoleID === roleId && i.DefaultAltType === 121
                    && i.TeamMemberUserStatus == isActive && userIDSets.has(Number.parseInt(i.TeamMemberfoADID, 10)));
                if (userAltRoleExist) {
                    Util.alert("Unable to add User", `${userAltRoleExist.TeamMemberADFullname} already exists as an alternate user`, true);
                    return false;
                }
            }
        }

        let result = {
            TeamMemberID: parseInt($("#EditTeamMemberID").val()),
            RoleID: Util.GetSingleSelectedIDFromSelect2(`#${prefix}EditRole`),
            RoleName: $(`#${prefix}EditRole option:selected`).text(),
            //TeamMemberfoUserAccountID: parseInt(userID),
            JVPartnerID: usr[0].id,
            TeamMemberfoADID: usr[0].id,
            Username: usr[0].text,
            TeamMemberUserStatus: parseInt($(`#${prefix}EditTeamStatus`).val()),
            IsDeleted: false,
            TeamMemberType: 0,
            ReferenceID: 0,
            TeamMemberADUsername: adUsername,
            TeamMemberADFullname: adFullname,
            TeamMemberADCompany: adCompany,
            TeamMemberADLabel: usr[0].text,
            DefaultAltType: parseInt($(`#${prefix}EditTeamDefaultAltType`).val()),
            TeamMemberADEmail: userEmail
        };
        let index = parseInt($("#EditTableRowID").val());
        $(`#${prefix}Teams`).DataTable().row(index).data(result).draw();
    },
    EditMember_click: function (e) {
        e.preventDefault();
        var prefix = $(this).closest("table").data("prefix");
        $("#Prefix").val(prefix);
        teamMember.ClearData(prefix);

        var url = '/ProjectSetup/UserAccount/GetAdUsersAutoComplete';
        var minimumInputLength = 1;
        if (prefix == 'editJV' || prefix == 'addJV') {
            url = '/ProjectSetup/JVPartner/GetJVPartnersAutoComplete';
            minimumInputLength = 0;

            let val = $(`#${prefix}EditRole`).find("option:contains('JV Partners')").val();
            $(`#${prefix}EditRole`).val(val).change();
            //$(`#${prefix}EditRole`).prop('disabled', true);
        }

        $(`#${prefix}EditUser`).empty();

        var editUsers = $(`#${prefix}EditUser`).select2({
            placeholder: "Select user",
            minimumInputLength: minimumInputLength,
            //multiple: true,
            width: '100%',
            ajax: {
                url: url,
                dataType: 'json',
                data: function (params) {
                    var query = {
                        prefix: params.term,
                    }
                    return query;
                },
                processResults: function (data) {
                    //var existingUsers = [];
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("addMem"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("addDir"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("addCom"));

                    //existingUsers = existingUsers.concat(teamMember.GetUsers("editMem"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("editDir"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("editCom"));

                    //existingUsers = existingUsers.concat(teamMember.GetUsers("compMem"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("compDir"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("compCom"));

                    //existingUsers = existingUsers.concat(teamMember.GetUsers("phaseMem"));

                    //var existingADIDs = [];
                    //for (var k = 0; k < existingUsers.length; k++) {
                    //    existingADIDs.push(existingUsers[k].TeamMemberfoADID);
                    //}

                    //for (var i = 0; i < existingADIDs.length; i++) {
                    //    for (var j = 0; j < data.length; j++) {
                    //        if (existingADIDs[i] === data[j].Value) {
                    //            data.splice(j, 1);
                    //            break;
                    //        }
                    //    }
                    //}

                    var res = data.map(function (item) {
                        return { id: item.Value, text: item.Label, userEmail: item.Email, username: item.Username, fullname: item.FullName, company: item.Company };
                    });
                    return {
                        results: res
                    };
                }
            }
        });

        var index = $(this).closest('tr').index();
        $("#EditTableRowID").val(index);
        var data = $(`#${prefix}Teams`).DataTable().row(index).data();
        prevRoleId = data.RoleID;
        prevDefaultAlternate = data.DefaultAltType;
        $(`#${prefix}EditRole`).val(data.RoleID).change();
        $("#EditTeamMemberID").val(data.TeamMemberID);
        //$(`#${prefix}EditUser`).val(data.TeamMemberfoUserAccountID).change();
        //$(`#${prefix}EditUser`).val(data.TeamMemberADUsername).change();

        if (data.TeamMemberADCompany && data.TeamMemberADCompany != null && data.TeamMemberADCompany != "") {
            editUsers.append('<option data-userEmail="' + data.TeamMemberADEmail + '" data-fullname="' + data.TeamMemberADFullname + '" data-company="' + data.TeamMemberADCompany + '" title="' + data.TeamMemberADUsername + '" value="' + data.TeamMemberfoADID + '" selected="selected">' + data.TeamMemberADFullname + ' (' + data.TeamMemberADCompany + ')' + '</option>');
        }
        else {
            editUsers.append('<option data-userEmail="' + data.TeamMemberADEmail + '" data-fullname="' + data.TeamMemberADFullname + '" data-company="' + data.TeamMemberADCompany + '" title="' + data.TeamMemberADUsername + '" value="' + data.TeamMemberfoADID + '" selected="selected">' + data.TeamMemberADFullname + '</option>');
        }

        editUsers.trigger('change');
        $(`#${prefix}EditTeamStatus`).val(data.TeamMemberUserStatus).change();
        $(`#${prefix}EditTeamDefaultAltType`).val(data.DefaultAltType).change();
        $(`#${prefix}EditMember`).modal("show");
        
    },
    DeleteMember_click: function (e) {
        e.preventDefault();

        var prefix = $(this).closest("table").data("prefix");

        // 🔒 Prevent deleting if only 1 row remains
        if ($(`#${prefix}Teams tbody tr`).length === 1) {
            Swal.fire({
                title: "Warning",
                text: "There should be at least 1 row in the table.",
                icon: "warning",
                confirmButtonText: "OK"
            });
            return;
        }

        var index = $(this).closest("tr").index();
        $("#TableRowID").val(index);

        let $row = $(this).closest("tr");

        Swal.fire({
            title: "Are you sure?",
            text: "Do you really want to delete this team member?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "Cancel"
        }).then((result) => {
            if (result.isConfirmed) {
                var data = $(`#${prefix}Teams`).DataTable().row(index).data();

                if (data.TeamMemberID > 0 && !isNaN(data.TeamMemberID)) {
                    // Mark existing record as deleted, hide row
                    data.IsDeleted = true;
                    $(`#${prefix}Teams`).DataTable().row(index).data(data);
                    $(`#${prefix}Teams tbody tr`).eq(index).hide();
                } else {
                    // Remove new (unsaved) row completely
                    $(`#${prefix}Teams`).DataTable().row($row).remove().draw(false);
                }

                Swal.fire({
                    title: "Deleted!",
                    text: "Team member has been deleted.",
                    icon: "success",
                    confirmButtonText: "OK"
                });
            }
        });
    },

    NewMember_click: function (e) {
        e.preventDefault();
        var prefix = $(this).data("prefix");

        $("#Prefix").val(prefix);
        //$(`#${prefix}Users`).select2({ destroy: true, width: "100%" });
        $("#TableRowID").val("");
        teamMember.ClearData(prefix);

        $(`#${prefix}Member`).modal("show");

        var url = '/ProjectSetup/UserAccount/GetAdUsersAutoComplete';
        var minimumInputLength = 1;
        if (prefix == 'editJV' || prefix == 'addJV') {
            url = '/ProjectSetup/JVPartner/GetJVPartnersAutoComplete';
            minimumInputLength = 0;

            let val = $(`#${prefix}Role`).find("option:contains('JV Partners')").val();
            $(`#${prefix}Role`).val(val).change();
            //$(`#${prefix}Role`).prop('disabled', true);
        }

        $(`#${prefix}Users`).empty();

        var addUsers = $(`#${prefix}Users`).select2({
            placeholder: "Select user(s)",
            minimumInputLength: minimumInputLength,
            multiple: true,
            width: '100%',
            ajax: {
                url: url,
                dataType: 'json',
                data: function (params) {
                    var query = {
                        prefix: params.term,
                    }
                    return query;
                },
                processResults: function (data) {
                    //var existingUsers = [];
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("addMem"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("addDir"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("addCom"));

                    //existingUsers = existingUsers.concat(teamMember.GetUsers("editMem"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("editDir"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("editCom"));

                    //existingUsers = existingUsers.concat(teamMember.GetUsers("compMem"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("compDir"));
                    //existingUsers = existingUsers.concat(teamMember.GetUsers("compCom"));

                    //existingUsers = existingUsers.concat(teamMember.GetUsers("phaseMem"));

                    //var existingADIDs = [];
                    //for (var k = 0; k < existingUsers.length; k++) {
                    //    existingADIDs.push(existingUsers[k].TeamMemberfoADID);
                    //}

                    //for (var i = 0; i < existingADIDs.length; i++) {
                    //    for (var j = 0; j < data.length; j++) {
                    //        if (existingADIDs[i] === data[j].Value) {
                    //            data.splice(j, 1);
                    //            break;
                    //        }
                    //    }
                    //}

                    var res = data.map(function (item) {
                        //return { id: item.Value, text: item.Label, email: item.Email, username: item.Username };
                        return { id: item.Value, text: item.Label, userEmail: item.Email, username: item.Username, fullname: item.FullName, company: item.Company };
                    });
                    return {
                        results: res
                    };
                }
            }
        });
    },
    AddMember_click: function (e) {
        e.preventDefault();
        let prefix = $("#Prefix").val();
        var tableID = `#${prefix}Teams`;
        var usr = $(`#${prefix}Users`).select2("data");

        // on add members, multiple selections. when save, make the users separate.

        var existingUsers = [];

        if (prefix == "addJV" || prefix == "editJV") {
            existingUsers = existingUsers.concat(teamMember.GetUsers("addJV"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("editJV"));
        }
        else {
            existingUsers = existingUsers.concat(teamMember.GetUsers("addMem"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("addDir"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("addCom"));

            existingUsers = existingUsers.concat(teamMember.GetUsers("editMem"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("editDir"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("editCom"));

            existingUsers = existingUsers.concat(teamMember.GetUsers("compMem"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("compDir"));
            existingUsers = existingUsers.concat(teamMember.GetUsers("compCom"));

            existingUsers = existingUsers.concat(teamMember.GetUsers("phaseMem"));
        }
        
        var roleId = $(`#${prefix}Role`).val();
        var roleName = $(`#${prefix}Role option:selected`).text();
        var isActive = parseInt($(`#${prefix}TeamStatus`).val());
        var isDefaultRole = parseInt($(`#${prefix}TeamDefaultAltType`).val()) == "120";

        if (isDefaultRole) {
            if (usr.length > 1) {
                Util.alert("Unable to add User", "You only can add one Default role at one time.", true)
                return false;
            }
            else if (usr.length == 1) {
                var userId = usr[0].id;
                var alreadyHasDefaultRole = false;
                for (var i = 0; i < existingUsers.length; i++) {
                        if (roleId == existingUsers[i].RoleID && existingUsers[i].DefaultAltType == "120") {
                            alreadyHasDefaultRole = true;
                            break;
                        }
                }

                if (alreadyHasDefaultRole) {
                    Util.alert("Unable to add User",
                        "Default role for " + roleName + " already exists, please add as Alternate role.",
                        true,
                    );
                    return false;
                }
            }
        }
        else {
            //validation - must have default role first before allow to add Alternate role
            var alreadyHasDefaultRole = existingUsers.some(i => i.RoleID === roleId && i.DefaultAltType === 120);
            if (!alreadyHasDefaultRole) {
                Util.alert("Unable to add User", "You must add Default role first before adding Alternate role.", true);
                return false;
            }

            var userIDSets = new Set();
            usr.forEach(i => userIDSets.add(Number.parseInt(i.id, 10)));
            var userAltRoleExist = $(tableID).DataTable().rows().data().toArray().find(i => i.RoleID === roleId && i.DefaultAltType === 121
                                      && i.TeamMemberUserStatus == isActive && userIDSets.has(Number.parseInt(i.TeamMemberfoADID, 10)));
            if (userAltRoleExist) {
                Util.alert("Unable to add User", `${userAltRoleExist.TeamMemberADFullname} already exists as an alternate user`, true);
                return false;
            }
        }

        $.each(usr, function (index, value) {
            let result = {
                RoleID: $(`#${prefix}Role`).val(),
                RoleName: $(`#${prefix}Role option:selected`).text(),
                TeamMemberType: 0,
                ReferenceID: 0,
                //TeamMemberfoUserAccountID: value.id,
                JVPartnerID: value.id,
                TeamMemberfoADID: value.id,
                Username: value.text,
                TeamMemberUserStatus: parseInt($(`#${prefix}TeamStatus`).val()),
                IsDeleted: false,
                TeamMemberADUsername: value.username,
                TeamMemberADFullname: value.fullname,
                TeamMemberADCompany: value.company,
                TeamMemberADLabel: value.text,
                DefaultAltType: parseInt($(`#${prefix}TeamDefaultAltType`).val()),
                TeamMemberADEmail: value.userEmail
            };

            $(tableID).DataTable().row.add(result).draw(false);
        });
    }
}
