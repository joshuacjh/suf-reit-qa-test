var Listing = {
    canView: false,
    canEdit: false,
    canDelete: false,
    canEditTeamMember: false,
    Init: function () {
        $('#CompanyListing').DataTable().destroy();
        $("#CompanyListing").DataTable({
            "responsive": true,
            "info": false,
            "ajax": {
                "url": $("#GetCompanyUrl").val(),
                "type": "POST",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: function () {
                    return JSON.stringify({
                        "CompanyIds": $('#ddlCompany').val(),
                        "CompanyStatusIds": $('#ddlCompanyStatus').val(),
                        "CreatedByNames": $('#ddlCreatedByName').val()
                    });
                }
            },
            "columnDefs": [
                {
                    targets: 2, // CompanyStatus
                    data: "CompanyStatus",
                    orderable: false,
                    searchable: true,
                    render: function (data, row, type) {
                        let result = "";
                        switch (data) {
                            case CompanyStatus.Active: result = "Active"; break;
                            case CompanyStatus.WindingUp: result = "Winding Up/Discontinued"; break;
                            case CompanyStatus.Dormant: result = "Dormant"; break;
                            case CompanyStatus.TransferBU: result = "Transfer to other BU"; break;
                        }
                        return result;
                    }
                },
                {
                    targets: 5, // CreatedAt
                    data: "CreatedAt",
                    orderable: false,
                    searchable: true,
                    render: function (data, row, type) {
                        return Util.DateAndTime(data);
                    }
                },
                {
                    targets: 6, // Actions (Edit/Delete/TM)
                    data: "CompanyID",
                    searchable: false,
                    orderable: false,
                    render: function (data, row, type) {
                        let editLink = "";
                        let deleteButton = "";
                        let editTm = "";

                        if (Listing.canEdit) {
                            editLink = ` <a href="${$("#EditCompanyUrl").val()}/${data}" class='btn btn-add btn-sm' title="Edit Company"><i class='fa fa-pencil'></i></a> `;
                        }
                        if (Listing.canDelete) {
                            deleteButton = `<button class='btn btn-danger btn-sm delete-project' rowId='${data}' title="Delete Company"><i class='fa fa-times'></i></button>`;
                        }
                        if (Listing.canEditTeamMember) {
                            editTm = ` <a href="${$("#EditCompanyUrl").val()}/${data}?view=1&edittm=true" class='btn btn-success btn-sm colorWhite' title="Edit Team Member"><i class='fa fa-user'></i></a> `;
                        }
                        return editLink + deleteButton + editTm;
                    }
                },
                {
                    targets: 7, // Project List
                    data: "CompanyID",
                    render: function (data, type, row) {
                        var addProjectLink = "";
                        switch (row.StatusID) {
                            case StatusID.Draft:
                                return addProjectLink;
                            default:
                                addProjectLink = Listing.canViewProject
                                    ? "<a class='btn btn-sunway' href='" + $("#AddProjectUrl").val() + "/" + data + "'>Project List</a>"
                                    : "";
                        }
                        return addProjectLink;
                    }
                },
                {
                    "targets": [2, 3],
                    "className": "text-center"
                },
                {
                    "targets": [4],
                    "orderable": false,
                    "className": "text-center"
                },
                {
                    "targets": [6, 7],
                    "className": "text-center actions"
                },
                {
                    "targets": [8],
                    "className": "hidden"
                }
            ],
            "columns": [
                { targets: 0, data: "CompanyCode" },
                { targets: 1, data: "CompanyName" },
                { targets: 2, data: "CompanyStatus" },
                { targets: 3, data: "StatusName" },
                { targets: 4, data: "CreatedByName" },
                { targets: 5, data: "CreatedAt" },
                { targets: 6, data: "CompanyID" }, // Actions
                { targets: 7, data: "CompanyID" }, // Project List
                { targets: 8, data: "CreatedAt" }  // Hidden sort column
            ],
            "order": [[8, 'desc']],
            "initComplete": function (settings, json) {
                $('#CompanyListing tbody tr').hover(
                    function () {
                        $(this).addClass('hover');
                        $(this).css('cursor', 'pointer');
                    },
                    function () {
                        $(this).removeClass('hover');
                    }
                );
            }
        });
    },
    DisplayTableStatus: function (row, type, set) {
        return !row.IsDeleted
            ? "<span class='label-custom label label-default'>Active</span>"
            : "<span class='label-danger label label-default'>Inactive</span>";
    }
};


Listing.Handlers = {
    ViewProject_click: function (e) {
        e.preventDefault();
        
        let data = $("#CompanyListing").DataTable().row($(this).closest("tr")).data();
        let url = `${$("#EditCompanyUrl").val()}/${data.CompanyID}?view=1`;
        if (Listing.canView) {
            window.location.replace(url);
        }
    },
    DeleteProject_click: function (e) {
        e.preventDefault();
        var id = $(this).attr("rowId");
        console.log("Delete company id", id);
        var $deleteRow = $("#CompanyListing").DataTable().row($(this).closest("tr"));

        Util.confirmAction("Company", "Are you sure you want to delete this company?", function (isTrue) {
            if (isTrue) {
                $.ajax({
                    type: "delete",
                    url: $("#DeleteCompanyUrl").val(),
                    data: { "companyID": id },
                    success: function () {
                        Util.alert("Company", "Company was successfully removed", false, function () {
                            $deleteRow.remove().draw();
                        });
                    },
                    error: function (xhr, textStatus, errorThrown) {
                        var error = $($.parseHTML(xhr.responseText)[1]).text();
                        Util.alert("Company", `Exception occurred : ${error}.`, true);
                    }
                });
            }
        });
    }
}

$('#ddlCompany').select2({ width: "100%", allowClear: true, placeholder: "Select Company" });
$('#ddlCompanyStatus').select2({ width: "100%", allowClear: true, placeholder: "Select Company Status" });
$('#ddlCreatedByName').select2({ width: "100%", allowClear: true, placeholder: "Select Created By Name" });

$("body").on("click", "#CompanyListing tbody tr td:not(.actions)", function (e) {
    e.preventDefault();

    let data = $("#CompanyListing").DataTable().row($(this).closest("tr")).data();
    let url = `${$("#EditCompanyUrl").val()}/${data.CompanyID}?view=1`;
    if (Listing.canView) {
        window.location.replace(url);
    }
});

$("body").on("click", "#filterTbl", function (e) {
    e.preventDefault();
    Listing.Init();
});

$("body").on("click", "#clearTblFilter", function (e) {
    e.preventDefault();

    $('#ddlCompany').val('').change();
    $('#ddlCompanyStatus').val('').change();
    $('#ddlCreatedByName').val('').change();

    Listing.Init();
});
$("body").on("click", "#CompanyListing tbody td .delete-project", function (e) {
    e.preventDefault();

    var id = $(this).attr("rowId"); // make sure rowId exists in your button markup
    var $deleteRow = $("#CompanyListing").DataTable().row($(this).closest("tr"));

    Swal.fire({
        title: "Are you sure?",
        text: "Do you really want to delete this company?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "Cancel"
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "DELETE",
                url: $("#DeleteCompanyUrl").val(), // backend must accept companyID in body
                data: { "companyID": id },
                success: function () {
                    Swal.fire({
                        title: "Deleted!",
                        text: "Company was successfully removed.",
                        icon: "success",
                        confirmButtonText: "OK"
                    }).then(() => {
                        location.reload();
                    });
                },
                error: function (xhr) {
                    var error = $($.parseHTML(xhr.responseText)[1]).text();
                    Swal.fire({
                        title: "Error",
                        text: `Exception occurred: ${error}.`,
                        icon: "error",
                        confirmButtonText: "OK"
                    });
                }
            });
        }
    });
});

