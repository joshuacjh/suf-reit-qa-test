var AddCompany = {
    Init: function () {
        Util.InitPartialViews(".cd")
            .InitPartialViews(".atch");

        this.BindEvents();
        this.InitTables("add");

        $("select").select2({ destroy: true, width: "100%" });

        $("#CompanyList tr:last .newUser, " +
            "#CommitteeList tr:last .newUser, " +
            "#JVPartnersList tr:last .newUser").select2();

        $("#team-members").removeClass("active").removeClass("in");

        let url = $("#GetRolesByTeamMemberTypeUrl").val();
        teamMember.SetDefaultRows("addMem", url, TeamMemberType.Normal);
        teamMember.SetDefaultRows("addCom", url, TeamMemberType.TenderCommittee);
        teamMember.SetDefaultRows("addJV", url, TeamMemberType.TenderCommitteeByJVPartners);
        teamMember.SetDefaultRows("addDir", url, TeamMemberType.DirectorOfCompany)
        teamMember.InitTable("addMem").InitTable("addCom").InitTable("addJV").InitTable("addDir");
        teamMember.BindEvents("addMem").BindEvents("addCom").BindEvents("addJV").BindEvents("addDir");

        // SaveCompany form
        Util.initFormValidator("#AddCompanyForm", this.validationRules());
        this.SetValidatorMethods();

        // 🔹 Default SST state setup (for Add New mode)
        $("#HasSST_No").prop("checked", true);
        $("#addSSTRegistrationNo").prop("disabled", true).css("background-color", "#eee");

        //dropzone
        let attch = new Attachments("add");
        attch.initDropzone();

        this.JVPartnerTeamMembersView();
        var MainForm = this;

        $('body').on('change', 'input[name="addeInvoicing"]', function () {
            var settings = $('#AddCompanyForm').validate().settings;
            if ($('input[name="addeInvoicing"]:checked').val() == 1) {
                delete settings.rules.addMSICCodefoID;
                delete settings.rules.addeInvoiceStartDate;
                delete settings.rules.addClassificationCodefoID;
               // settings.rules.addMSICCodefoID = { required: true };
                settings.rules.addeInvoiceStartDate = { required: true };
               // settings.rules.addClassificationCodefoID = { required: true };
            } else {
                //delete settings.rules.addMSICCodefoID;
                delete settings.rules.addeInvoiceStartDate;
                //delete settings.rules.addClassificationCodefoID;
            }
        });
    },
    InitTables: function(prefix) {
        $("#" + prefix + "Attachments").DataTable({
            "searching": false,
            "info": false,
            "ordering": false,
            "columnDefs": [
                { "className": "dt-center", "targets": "_all" }
            ]
        })
    },
    BindEvents: function () {
        var handlers = AddCompany.Handlers;
        $("#SaveCompany").click(handlers.SaveCompany_click);
        $("#addSuggest").click(handlers.DisplaySuggestions_click);
        $("#addSaveSuggest").click(handlers.SelectSuggestion_click);

        $(".processWorkflow").click(handlers.SaveCompany_click);

        $("body").on("change", "input[type=radio][name=addjvcompany]", function (e) {
            AddCompany.JVPartnerTeamMembersView();
        });
    },
    SetCompanyDetails: function (prefix) {
        let details = new CompanyDetails(prefix);
        let result = details.getDetails();

        return result;        
    },
    validationRules: function () {
        let MSICCodeVal = [{ "required": false }]
        let ClassificationVal = [{ "required": false }]
        let InvoiceSDateVal = [{ "required": false }]
        let InvoiceEDateVal = [{ "required": false }]

        return {
            rules: {
                "addCompanyName": {
                    "required": true
                },
                "addCompanyCode": {
                    "required": true,
                    "code": true,
                },
                "addifcacompany": {
                    "required": true
                },
                "addjvcompany": {
                    "required": true
                },
                "addRegNo": {
                    "required": true
                },
                "addTaxRegNo": {
                    "validateTaxRegNo": true
                },
                "addAddr1": {
                    "required": true
                },
                "addCountry": {
                    "required": true
                },
                "addState": {
                    "required": true
                },
                "addCity": {
                    "required": true
                },
                "addDistrict": {
                    "required": true
                },
                "addPostcode": {
                    "required": true,
                    "digits": true
                },
                "addEmail": {
                    "email": true
                },
                "addWebsite": {
                    "url": true
                },
                "addPhoneNo": {
                    //"telno": true
                },
                "addSecretKey1": {
                    "required": true,
                },
                "addSecretKey2": {
                    "required": true,
                }, 
                "addTinNumber": {
                    "required": true,
                }, 
                "addJDEIndustryType": {
                    "required": true,
                }, 
                /*addJDEIndustryType*/
                "addJDEBusinessUnitCode": {
                    "required": true,
                }, 
                "addJDECompanyCode": {
                    "required": true,
                }, 
                
                "addCreditorTINNo": {
                    "required": true,
                }, 
                "addJDEEnviroment": {
                    "required": true,
                },
                "addSSTRegistrationNo": {
                    required: function () {
                        // Only require SST if "Yes" is selected
                        return $("input[name='HasSST']:checked").val() === "Yes";
                    }
                },
              
            },
            messages: {
                "addCompanyName": {
                    "required": "Company name is required"
                },
                "addCompanyCode": {
                    "required": "Company code is required"
                },
                "addifcacompany": {
                    "required": "IFCA company is required"
                },
                "addjvcompany": {
                    "required": "JV company is required"
                },
                "addRegNo": {
                    "required": "Registration No is required"
                },
                "addAddr1": {
                    "required": "Address is required"
                },
                "addCountry": {
                    "required": "Country is required"
                },
                "addState": {
                    "required": "State is required"
                },
                "addCity": {
                    "required": "City is required"
                },
                "addDistrict": {
                    "required": "District is required"
                },
                "addPostcode": {
                    "required": "Postcode is required",
                    "digits": "Please enter valid postcode"
                },
                "addEmail": {
                    "email": "Please enter valid email"
                },
                "addWebsite": {
                    "url": "Please enter valid website (http://...)"
                },
                "addSecretKey1": {
                    "required": "Secret Key 1 Required"
                },
                "addSecretKey2": {
                    "required": "Secret Key 2 Required"
                },
                "addCreditorTINNo": {
                    "required": "Tin Number is Required"
                },
                "addJDEEnviroment": {
                    "required": "JDE Envriroment is Required"
                },
                "addSSTRegistrationNo": {
                    "required": "SST is Required"
                },
               // "addMSICCodefoID": { "required": "MSIC Code Required" },
                //"addClassificationCodefoID": { "required": "Classification Code Required" },
                "addeInvoiceStartDate": { "required": "Invoice Start Date Required" },
            }
        }
    },
    SetValidatorMethods: function () {
        //$.validator.addMethod("telno", function (phone_number, element) {
        //    phone_number = phone_number.replace(/\(|\)|\s+|-/g, "");
        //    return this.optional(element) || phone_number.length >= 9 &&
        //        phone_number.match(/^(1)[0-46-9]*[0-9]{7,8}$/);
        //}, "Please specify a valid tel number.");

        $.validator.addMethod("validateTaxRegNo", function (value, element) {
            let prefix = $(element).data("prefix");
            let taxType = $(`#${prefix}TaxType`).val();
            let taxTypeDesc = $(`#${prefix}TaxType option:selected`).text();
            let isValid = true;

            if ((taxType !== "TTYPE-2020-000001" && taxTypeDesc != "N/A" && taxTypeDesc != "NT0") && value === "") {
                isValid = false;
            }

            return isValid;
        }, "SST/GST Registration No is required");

        $.validator.addMethod("code", function (code, element) {
            let isValid = true;
            let listID = $(element).attr("list");
            let currentCodes = [];
            
            //$(`#${listID} option`).each(function () {
            //    currentCodes.push($(this).attr("value"));
            //});

            $('.compCodes').each(function () {
                currentCodes.push($(this).text());
            });

            isValid = $.inArray(code, currentCodes) < 0;

            return isValid;
        }, "Company code already exists. Please enter another company code");
    },
    JVPartnerTeamMembersView: function () {
        var isJVCompany = $('input[name="addjvcompany"]:checked').val();
        if (isJVCompany == "1") {
            $('#AppointedJVPartners').removeClass('hidden');
            var panel = $('a[href="#AppointedJVPartners"]');
            panel.closest('.panel-heading').removeClass('hidden');
        }
        else {
            $('#AppointedJVPartners').addClass('hidden');
            var panel = $('a[href="#AppointedJVPartners"]');
            panel.closest('.panel-heading').addClass('hidden');
        }
    },
    DisableActionButtons: function (isDisable) {
        $('#SaveCompany').prop('disabled', isDisable);
        $('.processWorkflow').prop('disabled', isDisable);
        $('#cancelAction').prop('disabled', isDisable);
    },
};

AddCompany.Handlers = {
    SelectSuggestion_click: function (e) {
        e.preventDefault();
        var prefix = $(this).data("prefix");
        var selected = $("input[name='options']:checked").val();
        $(`#${prefix}CompanyCode`).val(selected);
    },
    DisplaySuggestions_click: function (e) {
        e.preventDefault();
        var prefix = $(this).data("prefix");

        //if ($(`#${prefix}CompanyName`).val() === "") {
        //    return;
        //}

        $.get($("#SuggestCompanyCode").val(), { "companyName": $(`#${prefix}CompanyName`).val() }, function (result) {
            //console.log(result);
            var options = "";
            $("#Container").empty();

            $.each(result, function (index, value) {
                var option = `<div class='col-sm-12'><label class='control-label'><input type='radio' name='options' value='${value}'> ${value}</label></div>`;
                $("#Container").append(option);
            });
        });
    },
    DeleteMember_click: function(e) {
        e.preventDefault();
        var rows = $("#CompanyList tbody tr:visible").length;
        if (rows === 1) {
            Util.alert("Add company", "At lease one row should be visible.", true);
            return;
        }

        $("#CompanyList").DataTable().row($(this).closest("tr")).remove().draw(false);
    },
    SaveCompany_click: function (e) {
        e.preventDefault();
        AddCompany.DisableActionButtons(true);

        if (!$("#AddCompanyForm").valid()) {
            AddCompany.DisableActionButtons(false);
            return;
        }

        var url = $(e.currentTarget).attr("url");
        var details = AddCompany.SetCompanyDetails("add");

        // --- Gather members ---
        var teamMembers = teamMember.RetrieveData("addMem");
        $.map(teamMembers, function (val) {
            val.ReferenceID = $("#CompanyID").val();
            val.TeamMemberTypeID = TeamMemberType.Normal;
            return val;
        });

        var committeeMems = teamMember.RetrieveData("addCom");
        $.map(committeeMems, function (val) {
            val.ReferenceID = $("#CompanyID").val();
            val.TeamMemberTypeID = TeamMemberType.TenderCommittee;
            return val;
        });

        var jvMems = teamMember.RetrieveData("addJV");
        $.map(jvMems, function (val) {
            val.ReferenceID = $("#CompanyID").val();
            val.TeamMemberTypeID = TeamMemberType.TenderCommitteeByJVPartners;
            return val;
        });

        var dirMems = teamMember.RetrieveData("addDir");
        $.map(dirMems, function (val) {
            val.ReferenceID = $("#CompanyID").val();
            val.TeamMemberTypeID = TeamMemberType.DirectorOfCompany;
            return val;
        });

        // --- Attach members into details ---
        details.TeamMembers = teamMembers;
        details.CommitteeMembers = committeeMems;
        details.JVPartnerMembers = jvMems;
        details.Directors = dirMems;

        // --- Build FormData ---
        var data = objectToFormData(details);
        for (var x = 0; x < files.length; x++) {
            data.append("Uploads", files[x]);
        }

        // --- Workflow metadata ---
        var $this = $(e.currentTarget);
        var actionId = $this.data("wfid");
        var requiredComment = $this.data("requiredcomment");
        var actionName = $this.data("actionname");

        // Workflow (Submit, Approve, Update, Reject)
        if (actionId && actionId !== "") {
            data.append("WorkflowActionId", actionId);

            let confirmText = 'Click Yes to ' + actionName + ' the company';
            if (actionName.toLowerCase().includes('update')) {
                confirmText += '<br/> The data will update to IFCA & send email notification to PIC';
            }

            Swal.fire({
                title: 'Are you sure?',
                html: confirmText,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                allowOutsideClick: false
            }).then((result) => {
                if (!result.value) {
                    AddCompany.DisableActionButtons(false);
                    return;
                }

                const sendWorkflow = (comment) => {
                    if (comment) data.append("WorkflowActionComment", comment);

                    $.ajax({
                        type: "POST",
                        url: url,
                        data: data,
                        processData: false,
                        contentType: false,
                        success: function () {
                            Swal.fire({
                                title: 'Success',
                                text: 'Company has been successfully processed.',
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then(() => {
                                window.location.replace($("#CompanyListPage").val());
                            });
                        },
                        error: function (xhr) {
                            console.log(xhr);
                            let errorMsg = xhr.responseText;
                            try {
                                const parsed = $.parseHTML(xhr.responseText);
                                if (parsed && parsed.length > 1) errorMsg = $(parsed[1]).text();
                            } catch (e) { }
                            Swal.fire({
                                title: 'Error',
                                text: `Exception occurred: ${errorMsg}`,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        },
                        complete: function () {
                            AddCompany.DisableActionButtons(false);
                        }
                    });
                };

                if (requiredComment) {
                    Swal.fire({
                        title: 'Comment',
                        input: 'textarea',
                        inputAttributes: { autocapitalize: 'off', id: 'swal-comment' },
                        showCancelButton: true,
                        confirmButtonText: 'Confirm',
                        inputValidator: (value) => !value && 'Please enter a comment',
                        allowOutsideClick: false
                    }).then((res) => {
                        if (res.value) sendWorkflow(res.value);
                        else AddCompany.DisableActionButtons(false);
                    });
                } else {
                    sendWorkflow();
                }
            });
        }

        // Save as Draft (no changes needed)
        else {
            $.ajax({
                type: "POST",
                url: url,
                data: data,
                processData: false,
                contentType: false,
                success: function () {
                    Swal.fire({
                        title: 'Saved as Draft',
                        text: 'Company has been saved successfully as draft.',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        window.location.replace($("#CompanyListPage").val());
                    });
                },
                error: function (xhr) {
                    console.log(xhr);
                    let errorMsg = xhr.responseText;
                    try {
                        const parsed = $.parseHTML(xhr.responseText);
                        if (parsed && parsed.length > 1) errorMsg = $(parsed[1]).text();
                    } catch (e) { }
                    Swal.fire({
                        title: 'Error',
                        text: `Exception occurred: ${errorMsg}`,
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                },
                complete: function () {
                    AddCompany.DisableActionButtons(false);
                }
            });
        };
    }
};

$(document).ready(function () {
    $("#CompanyCode").autocomplete({
        minLength: 0,
        source: function (request, response) {
            $.ajax({
                url: cdUrl.GetCompanyCodeAutoComplete,
                type: "POST",
                dataType: "json",
                data: { prefix: request.term },
                success: function (data) {
                    response($.map(data,
                        function (item) {
                            return { label: item.Label, value: item.Value };
                        }));
                }
            });
        },
        select: function (e, ui) {
            event.preventDefault();
            $(this).val(ui.item.label);
        }
    }).bind('focus', function () {
        $(this).autocomplete("search");
    }).data("ui-autocomplete")._renderItem = function (ul, item) {
        //return $('<li class="ui-state-disabled">' + item.label + '</li>').appendTo(ul);
        return $('<li class="compCodes" style="padding-left:10px;padding-top:5px;padding-bottom:5px;">' + item.label + '</li>').appendTo(ul);
    };


   
});
