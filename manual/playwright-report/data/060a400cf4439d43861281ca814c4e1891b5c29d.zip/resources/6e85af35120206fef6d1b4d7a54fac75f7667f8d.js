var files = [];
var attachmentDropzone = null;

class Attachments {
  _prefix = "";
  _isEnabled = false;
  _downloadUrl = "";

  constructor(prefix) {
    this._prefix = prefix;
  }

  set isEnabled(val) {
    this._isEnabled = val;
  }

  set downloadUrl(val) {
    this._downloadUrl = val;
  }

  init() {
    Util.InitPartialViews(".atch");
  }

  initTable() {
    $(`#${this._prefix}Attachments`).DataTable();
  }

  reload() {
    $(`#${this._prefix}Attachments`)
      .DataTable()
      .ajax.reload();
  }

  // Remove events here
  initAjax(url, dataParam, events) {
    let prefix = this._prefix;
    let enabled = this._isEnabled ? "" : "disabled";
    let downloadUrl = this._downloadUrl;
    $(`#${this._prefix}Upload`).prop("disabled", !this._isEnabled);

    if (!this._isEnabled) {
        //$(`#${this._prefix}divUploadAttachment`).empty();
        $(`#${this._prefix}divUploadAttachment`).css('display', 'none');
    }
    else {
        $(`#${this._prefix}divUploadAttachment`).css('display', 'block');
    }

    $(`#${prefix}Attachments`)
      .DataTable()
      .clear()
      .destroy();
    $(`#${prefix}Attachments`).DataTable({
      autoWidth: true,
      searching: false,
      info: false,
      ordering: false,
      ajax: {
        url: url,
        type: "get",
        data: dataParam
      },
      columnDefs: [
        { className: "center", targets: [1, 2, 3] },
        {
          targets: 3,
          data: "AttachmentID",
          width: "100px",
          searchable: false,
          orderable: false,
          render: function(data, row, type) {
            let deleteButton = `<button data-row="${data}" class="btn btn-danger btn-sm btn-delete" ${enabled}><i class="fa fa-times"></i></button>`;
            let download = `<a href="${downloadUrl}/${data}" class="btn btn-primary btn-sm" target="_blank"><i class="fa fa-download"></i></a>`;
            //return '<button data-row="' + data + '" class="btn btn-danger btn-sm btn-delete" ' + enabled + '><i class="fa fa-times"></i></button>';

            return download + " " + deleteButton;
          }
        }
      ],
      columns: [
        { data: "AttachmentName" },
        { data: "CreatedByName" },
        {
          data: function(row, type, set) {
            return Util.DateString(row.CreatedAt, "DD/MM/YYYY");
          }
        }
      ],
      initComplete: function(settings, json) {
        console.log(json);
        //$(`#${prefix}Attachments tbody td`).on("click", ".btn-delete", events.Delete);
          $(`#${prefix}Attachments tbody td`).on(
              "click",
              ".btn-delete",
              attachEvents.DeleteAttachment_click
        
        );
      }
    });
  }

  initDropzone() {
    InitializeDropzone(this._prefix);
  }

  clearAttachmentTable() {
    $(`#${this._prefix}Upload`).val("");
    $(`#${this._prefix}Attachments`)
      .DataTable()
      .clear()
      .draw();

    if (!this._isEnabled) {
        //$(`#${this._prefix}divUploadAttachment`).empty();
        $(`#${this._prefix}divUploadAttachment`).css('display', 'none');
    }
    else {
        $(`#${this._prefix}divUploadAttachment`).css('display', 'block');
    }
  }

  RetrieveAttachments() {
    let result = $(`#${this._prefix}Attachments`)
      .DataTable()
      .rows()
      .data()
      .toArray();

    return result;
  }
}

//let attachEvents = {
//  DeleteAttachment_click: function(e) {
//    e.preventDefault();
//    let prefix = $(this)
//      .closest("table")
//      .data("prefix");

//    let index = $(this)
//      .closest("tr")
//      .index();

//    Util.confirmAction(
//      "Attachments",
//      "Are you sure you want to delete this attachment?",
//      function(isTrue) {
//        if (isTrue) {
//          let data = $(`#${prefix}Attachments`)
//            .DataTable()
//            .row(index)
//            .data();
//          data.IsDeleted = true;
//          $(`#${prefix}Attachments`)
//            .DataTable()
//            .row(index)
//            .data(data);

//          $(`#${prefix}Attachments tbody tr`)
//            .eq(index)
//            .hide();

//          if ($(`#${prefix}Attachments tbody tr:visible`).length < 1) {
//            $(`#${prefix}Attachments tbody`).append(
//              "<tr role='row' class='odd' style='background-color: #f9f9f9;'><td colspan='4' class='dataTables_empty'>No data available in table</td></tr>"
//            );
//          }
//        }
//      }
//    );
//  }
//};
let attachEvents = {
    DeleteAttachment_click: function (e) {
        e.preventDefault();
        let prefix = $(this).closest("table").data("prefix");
        let table = $(`#${prefix}Attachments`).DataTable();
        let row = table.row($(this).closest("tr"));
        let data = row.data(); // attachment row data

        Swal.fire({
            title: "Delete Attachment?",
            text: "Are you sure you want to delete this attachment?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "Cancel"
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "/Company/DeleteAttachmentRow", // 👈 controller endpoint
                    type: "POST",
                    data: { id: data.AttachmentID },
                    success: function (response) {
                        if (response.success) {
                            row.remove().draw(false);
                            Swal.fire("Deleted!", "Attachment has been removed.", "success");
                        } else {
                            Swal.fire("Error!", response.message, "error");
                        }
                    },
                    error: function () {
                        Swal.fire("Error!", "Server error while deleting attachment.", "error");
                    }
                });
            }
        });
    }
};


//InitializeDropzone();
function InitializeDropzone(prefix) {
  Dropzone.autoDiscover = false;
  attachmentDropzone = new Dropzone(
    "#" + prefix + "divUploadAttachment > #dzAttachment",
    {
      url: "someurl",
      autoProcessQueue: false,
      addRemoveLinks: true,
      maxFilesize: 1024,
    }
  );

  attachmentDropzone.on("addedfile", function(file) {
    files.push(file);
  });

  attachmentDropzone.on("removedfile", function(file) {
    var updatedFiles = $.grep(files, function(e) {
      return e.name != file.name;
    });
    files = updatedFiles;
  });
}
