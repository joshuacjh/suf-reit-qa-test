//#region InternationalPhoneCode
var CPCAOfficeNoCountry = $("#CPCAOfficeNoCountry").val();
CPCAOfficeNoCountry = CPCAOfficeNoCountry != null ? CPCAOfficeNoCountry : "my";
var CPAAOfficeNoCountry = $("#CPAAOfficeNoCountry").val();
CPAAOfficeNoCountry = CPAAOfficeNoCountry != null ? CPAAOfficeNoCountry : "my";


var cpcno_input1 = document.querySelector("#CAOfficeNo");
var cpcno_input2 = document.querySelector("#AAOfficeNo");
var cpcno1_countrycode;
var cpcno2_countrycode;


var iti1 = window.intlTelInput(cpcno_input1, {
    updateHiddenOnChange: false,
    preferredCountries: ['my'],
    separateDialCode: true,
    autoFormat: false,
    autoPlaceholder: "off",
    formatOnDisplay: false,
    //placeholderNumberType: "FIXED_LINE",
    initialCountry: CPCAOfficeNoCountry
});
$(cpcno_input1).attr('style', 'padding-left: 90px;');
$(cpcno_input1).on("change keyup", function (e) {
    $(cpcno_input1).attr('style', 'padding-left: 90px;');
});

var iti2 = window.intlTelInput(cpcno_input2, {
    updateHiddenOnChange: false,
    preferredCountries: ['my'],
    separateDialCode: true,
    autoFormat: false,
    autoPlaceholder: "off",
    //placeholderNumberType: "FIXED_LINE",
    formatOnDisplay: false,
    initialCountry: CPAAOfficeNoCountry
});
$(cpcno_input2).attr('style', 'padding-left: 100px;');
$(cpcno_input2).on("change keyup", function (e) {
    $(cpcno_input2).attr('style', 'padding-left: 100px;');
});

//#endregion

function getCountryList(countryID) {
    $("#loadermain").addClass("hidden");
    $(countryID).select2({
        placeholder: "Select Country",
        width: "100%",
        dropdownAutoWidth: "auto",
        ajax: {
            url: window.ajaxUrl.GetCountryList,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            delay: 250, // debounce
            data: function (params) {
                return JSON.stringify({ search: params.term || "" });
            },
            processResults: function (data) {
                return {
                    results: $.map(data.data, function (item) {
                        return {
                            id: item.CountryIFCAID,
                            text: item.CountryIFCAName
                        };
                    })
                };
            }
        }
    });

    let defaultValue = '70';
    let defaultText = 'Malaysia';
    if (defaultValue && defaultText) {
        var option = new Option(defaultText, defaultValue, true, true);
        $(countryID).append(option).trigger("change");
        let $CAState = $("#CAState");
        let $RAState = $("#RAState");
        let $AAState = $("#AAState");
        getStateData(countryID, $CAState);
        getStateData(countryID, $RAState);
        getStateData(countryID, $AAState);
    }
}

function getStateData(countryID, stateID) {
    
    $(stateID).select2({
        placeholder: "Select State",
        allowClear: false, // no clear button
        width: "100%",
        dropdownAutoWidth: "auto",
        ajax: {
            url: window.ajaxUrl.GetStatesByCountryId,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            delay: 250,
            data: function (params) {
                // Always include selected countryID + search term
                return JSON.stringify({
                    countryID: $(countryID).val(),
                    search: params.term || ""
                });
            },
            processResults: function (data) {
                return {
                    results: $.map(data.data, function (item) {
                        return {
                            id: item.StateIFCAID,
                            text: item.StateIFCAName
                        };
                    })
                };
            }
        }
    });
}

function getCityData(countryID, stateID, cityID) {
    $(cityID).select2({
        placeholder: "Select State",
        allowClear: false, // no clear button
        width: "100%",
        dropdownAutoWidth: "auto",
        ajax: {
            url: window.ajaxUrl.GetCityByCountryStatesId,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            delay: 250,
            data: function (params) {
                // Always include selected countryID + search term
                return JSON.stringify({
                    countryID: countryID.val(),
                    statesID: stateID.val(),
                    search: params.term || ""
                });
            },
            processResults: function (data) {
                return {
                    results: $.map(data.data, function (item) {
                        return {
                            id: item.CityIFCAID,
                            text: item.CityIFCAName
                        };
                    })
                };
            }
        }
    });
}

function getDistrictData(countryID, stateID, cityID, districtID) {
    $(districtID).select2({
        placeholder: "Select State",
        allowClear: false, // no clear button
        width: "100%",
        dropdownAutoWidth: "auto",
        ajax: {
            url: window.ajaxUrl.GetDistrictByCountryStatesCityId,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            delay: 250,
            data: function (params) {
                // Always include selected countryID + search term
                return JSON.stringify({
                    countryID: countryID.val(),
                    statesID: stateID.val(),
                    cityID: cityID.val(),
                    search: params.term || ""
                });
            },
            processResults: function (data) {
                return {
                    results: $.map(data.data, function (item) {
                        return {
                            id: item.DistrictIFCAID,
                            text: item.DistrictIFCAName
                        };
                    })
                };
            }
        }
    });
}



$(document).ready(function () {
    //#region _General
    var parentChildArray = [];
    var directorDesignationArray = [];

    $CACountry = $("#CACountry");
    $RACountry = $("#RACountry");
    $AACountry = $("#AACountry");

    getCountryList($CACountry);
    getCountryList($RACountry);
    getCountryList($AACountry);
    getParentChildCompany();
    getDirDesignation();
    getVendorConsentTxt();
    setTimeout(function () {
        openEditableTableInput();
    }, 100);
    updateAddCompanyIndex();

    setTimeout(function () {
        limitOneParent();
        $('input[name="GeneralInfo.CompanyParticular.CPTypeOFCompany"]:checked').trigger('change');
    }, 500);
    calculateYearOfBusiness();

    var HVendorID = $("#HiddenVendorID").val();
    if (!$("input[name='GeneralInfo.CompanyParticular.CPGSTRegistered']:checked").val()) {
        $("#CPGSTRegistered2").prop("checked", true);
        $("#GSTTextbox").attr("readonly", "readonly");
    }

    if (!$("input[name='GeneralInfo.CompanyParticular.CPSSTRegistered']:checked").val()) {
        $("#CPSSTRegistered2").prop("checked", true);
        $("#SSTTextbox").attr("readonly", "readonly");
    }

    if ($(".GSTdropdown:checked").val() === "No") {
        $("#GSTTextbox").attr("readonly", "readonly");
    }
    if ($(".SSTdropdown:checked").val() === "No") {
        $("#SSTTextbox").attr("readonly", "readonly");
    }

    //#endregion

    //#region _AccordianArrows
    //$(".collapse")
    //  .on("shown.bs.collapse", function () {
    //      $(this)
    //        .parent()
    //        .find(".fa-caret-down")
    //        .removeClass("fa-caret-down")
    //        .addClass("fa-caret-up");
    //  })
    //  .on("hidden.bs.collapse", function () {
    //      $(this)
    //        .parent()
    //        .find(".fa-caret-up")
    //        .removeClass("fa-caret-up")
    //        .addClass("fa-caret-down");
    //  });
    $("body").on("click", ".panel-heading a", function () {
        var Minus = $(this).find(".fa.fa-caret-down");
        var Plus = $(this).find(".fa.fa-caret-up");

        Minus.toggleClass("hidden");
        Plus.toggleClass("hidden");
    })
    //#endregion

    //#region _Initialization
    updateSelect2();
    initializeModalValues();
    initDatepicker();
    updateAddCompanyIndex();
    updateAddDirectorIndex();
    updateAddShareHolderIndex();

    $("#tbodyCompany").find(".CPCompParentChildID").each(function (i, obj) {
        var _this = $(this).closest("tr");
        _this.find(".CPCompParentChild").val($(this).val()).trigger("change");
    });

    //#endregion

    //#region _Functions
    function initDatepicker() {
        $(".CPDDOA").each(function () {
            if (!$(this).hasClass("addedDatepicker")) {
                $(this).datepicker({
                    todayBtn: "linked",
                    autoclose: true,
                    format: "dd/mm/yyyy",
                    endDate: '+0d',
                });

                $(this).addClass("addedDatepicker");
            }
        });

        $(".CPDDOR").each(function () {
            if (!$(this).hasClass("addedDatepicker")) {
                $(this).datepicker({
                    todayBtn: "linked",
                    autoclose: true,
                    format: "dd/mm/yyyy",
                    endDate: '+0d',
                });

                $(this).addClass("addedDatepicker");
            }
        });

        $("#dateEstablished").datepicker({
            todayBtn: "linked",
            autoclose: true,
            format: "dd/mm/yyyy",
            endDate: '+0d',
        });
    }
    function getVendorConsentTxt() {
        
        $.ajax({
            url: window.ajaxUrl.getVendorConsent,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                console.log('result.data')
                $("#consentMsg").text(result.data);
            }
        });
    }

    //function getCountryList(countryID) {
    //    $.ajax({
    //        url: window.ajaxUrl.GetCountryList,
    //        type: "POST",
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        //data: JSON.stringify({ countryID: countryID }),
    //        async: false,
    //        success: function (result) {
    //            $("#loadermain").addClass("hidden");
    //            countryID.empty();
    //            countryID.html('<option value="">Select Country</option>');
    //            $.each(result.data.Result, function (index, item) {
    //                countryID.append(
    //                    $("<option>", {
    //                        value: item.CountryIFCAID,
    //                        text: item.CountryIFCAName
    //                    })
    //                );
    //            });
    //            //setTimeout(function () {
    //                countryID.val("70").trigger("change");
    //            }, 100);
    //        }
    //    });
    //}
    

    //function getStateData(countryID, stateID) {
    //    var countryID = countryID.val();

    //    $.ajax({
    //        url: window.ajaxUrl.GetStatesByCountryId,
    //        type: "POST",
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        data: JSON.stringify({ countryID: countryID }),
    //        async: false,
    //        success: function (result) {
    //            stateID.empty();
    //            stateID.html('<option value="">Select State</option>');
    //            $.each(result.data, function (index, item) {
    //                stateID.append(
    //                    $("<option>", {
    //                        value: item.StateIFCAID,
    //                        text: item.StateIFCAName
    //                    })
    //                );
    //            });
    //        }
    //    });
    //}



    function getParentChildCompany() {
        $.ajax({
            url: window.ajaxUrl.getParentChildCompanyList,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                $.each(result.data, function (index, item) {
                    parentChildArray.push(item);
                });
            }
        });
    }

    function getDirDesignation() {
        $.ajax({
            url: window.ajaxUrl.getDirectorDesignationList,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                $.each(result.data, function (index, item) {
                    directorDesignationArray.push(item);
                });
            }
        });
    }



    function cpValidation() {
        var isValid = false;
        var CPCompanyName = $("#CPCompanyName").val();
        var CPNewCompanyROC_ROB = $("#CPNewCompanyROC_ROB").val();
        var CPTypeOFCompany = $(
            "input[name='GeneralInfo.CompanyParticular.CPTypeOFCompany']:checked"
        ).val();
        var dateEstablished = $("#dateEstablished").val();
        var GSTTextbox = $("#GSTTextbox").val();
        var SSTTextbox = $("#SSTTextbox").val();
        var CPIndustryType = $("#CPIndustryType").val();

        var CPCompanyNameValid = $("#CPCompanyNameValid");
        var CPNewCompanyROC_ROBValid = $("#CPNewCompanyROC_ROBValid");
        var CPTypeOFCompanyValid = $("#CPTypeOFCompanyValid");
        var dateEstablishedValid = $("#dateEstablishedValid");
        var GSTTextboxValid = $("#GSTTextboxValid");
        var SSTTextboxValid = $("#SSTTextboxValid");
        var CPIndustryTypeValid = $("#CPIndustryTypeValid");

        if (CPCompanyName == "") {
            CPCompanyNameValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CPCompanyNameValid.addClass("d-none");
        }

        if (CPNewCompanyROC_ROB == "") {
            CPNewCompanyROC_ROBValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CPNewCompanyROC_ROBValid.addClass("d-none");
        }

        if (CPIndustryType == "") {
            CPIndustryTypeValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CPIndustryTypeValid.addClass("d-none");
        }
        if (typeof CPTypeOFCompany === "undefined") {
            CPTypeOFCompanyValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CPTypeOFCompanyValid.addClass("d-none");
        }

        if (dateEstablished == "") {
            dateEstablishedValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            dateEstablishedValid.addClass("d-none");
        }

        if ($(".GSTdropdown:checked").val() === "Yes") {
            if (GSTTextbox == "") {
                GSTTextboxValid.removeClass("d-none");
                isValid = false;
                return isValid;
            } else {
                isValid = true;
                GSTTextboxValid.addClass("d-none");
            }
        } else {
            isValid = true;
            GSTTextboxValid.addClass("d-none");
        }
        if ($(".SSTdropdown:checked").val() === "Yes") {
            if (SSTTextbox == "") {
                SSTTextboxValid.removeClass("d-none");
                isValid = false;
                return isValid;
            } else {
                isValid = true;
                SSTTextboxValid.addClass("d-none");
            }
        } else {
            isValid = true;
            SSTTextboxValid.addClass("d-none");
        }

        return isValid;
    }

    function regAddValidation() {
        var isValid = false;
        var RAAddr1 = $("#RAAddr1").val();
        var RACountry = $("#RACountry").val();
        var RAState = $("#RAState").val();
        var RACity = $("#RACity").val();
        var RAPostcode = $("#RAPostcode").val();
        var RADistrict = $("#RADistrict").val();

        var RAAddr1Valid = $("#RAAddr1Valid");
        var RACountryValid = $("#RACountryValid");
        var RAStateValid = $("#RAStateValid");
        var RACityValid = $("#RACityValid");
        var RAPostcodeValid = $("#RAPostcodeValid");
        var RADistrictValid = $("#RADistrictValid");
        var regAddDivValid = $("#registeredAddValidation");

        if (RAAddr1 == "") {
            RAAddr1Valid.removeClass("d-none");
            regAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            RAAddr1Valid.addClass("d-none");
            regAddDivValid.addClass("d-none");
        }

        if (RACountry == "") {
            RACountryValid.removeClass("d-none");
            regAddDivValid.removeClass("d-none");

            isValid = false;
            return isValid;
        } else {
            isValid = true;
            RACountryValid.addClass("d-none");
            regAddDivValid.addClass("d-none");
        }

        if (RAState == "") {
            RAStateValid.removeClass("d-none");
            regAddDivValid.removeClass("d-none");

            isValid = false;
            return isValid;
        } else {
            isValid = true;
            RAStateValid.addClass("d-none");
            regAddDivValid.addClass("d-none");
        }

        if (RACity == "") {
            RACityValid.removeClass("d-none");
            regAddDivValid.removeClass("d-none");

            isValid = false;
            return isValid;
        } else {
            isValid = true;
            RACityValid.addClass("d-none");
            regAddDivValid.addClass("d-none");
        }

        if (RADistrict == "") {
            RADistrictValid.removeClass("d-none");
            regAddDivValid.removeClass("d-none");

            isValid = false;
            return isValid;
        } else {
            isValid = true;
            RADistrictValid.addClass("d-none");
            regAddDivValid.addClass("d-none");
        }

        if (RACountry == "70" && RAPostcode == "") {
            RAPostcodeValid.removeClass("d-none");
            regAddDivValid.removeClass("d-none");

            isValid = false;
            return isValid;
        } else {
            isValid = true;
            RAPostcodeValid.addClass("d-none");
            regAddDivValid.addClass("d-none");
        }
        return isValid;
    }

    function corresAddValidation() {
        var isValid = false;
        var CAAddr1 = $("#CAAddr1").val();
        var CACountry = $("#CACountry").val();
        var CAState = $("#CAState").val();
        var CACity = $("#CACity").val();
        var CADistrict = $("#CADistrict").val();
        var CAPostcode = $("#CAPostcode").val();
        var CAWebsite = $("#CAWebsite").val();
        var CAEmail = $("#CAEmail").val();
        var CAOfficeNo = $("#CAOfficeNo").val();

        var CAAddr1Valid = $("#CAAddr1Valid");
        var CACountryValid = $("#CACountryValid");
        var CAStateValid = $("#CAStateValid");
        var CACityValid = $("#CACityValid");
        var CADistrictValid = $("#CADistrictValid");
        var CAPostcodeValid = $("#CAPostcodeValid");
        var CAWebsiteValid = $("#CAWebsiteValid");
        var CAEmailValid = $("#CAEmailValid");
        var CAOfficeNoValid = $("#CAOfficeNoValid");
        var corrAddDivValid = $("#correspondenceAddValidation");

        if (CAAddr1 == "") {
            CAAddr1Valid.removeClass("d-none");
            corrAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CAAddr1Valid.addClass("d-none");
            corrAddDivValid.addClass("d-none");
        }

        if (CACountry == "") {
            CACountryValid.removeClass("d-none");
            corrAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CACountryValid.addClass("d-none");
            corrAddDivValid.addClass("d-none");
        }

        if (CAState == "") {
            CAStateValid.removeClass("d-none");
            corrAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CAStateValid.addClass("d-none");
            corrAddDivValid.addClass("d-none");
        }

        if (CACity == "") {
            CACityValid.removeClass("d-none");
            corrAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CACityValid.addClass("d-none");
            corrAddDivValid.addClass("d-none");
        }

        if (CADistrict == "") {
            CADistrictValid.removeClass("d-none");
            corrAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CADistrictValid.addClass("d-none");
            corrAddDivValid.addClass("d-none");
        }

        if (CACountry == "70" && CAPostcode == "") {
            CAPostcodeValid.removeClass("d-none");
            corrAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CAPostcodeValid.addClass("d-none");
            corrAddDivValid.addClass("d-none");
        }

        if (CAOfficeNo == "") {
            CAOfficeNoValid.removeClass("d-none");
            corrAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CAOfficeNoValid.addClass("d-none");
            corrAddDivValid.addClass("d-none");
        }
        if (CAEmail == "") {
            CAEmailValid.removeClass("d-none");
            corrAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CAEmailValid.addClass("d-none");
            corrAddDivValid.addClass("d-none");
        }
        if (CAWebsite == "") {
            CAWebsiteValid.removeClass("d-none");
            corrAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            CAWebsiteValid.addClass("d-none");
            corrAddDivValid.addClass("d-none");
        }

        return isValid;
    }

    function addTAddValidation() {
        var isValid = false;
        var AAAddr1 = $("#AAAddr1").val();
        var AACountry = $("#AACountry").val();
        var AAState = $("#AAState").val();
        var AACity = $("#AACity").val();
        var AADistrict = $("#AADistrict").val();
        var AAPostcode = $("#AAPostcode").val();
        var AAWebsite = $("#AAWebsite").val();
        var AAEmail = $("#AAEmail").val();
        var AAOfficeNo = $("#AAOfficeNo").val();

        var AAAddr1Valid = $("#AAAddr1Valid");
        var AACountryValid = $("#AACountryValid");
        var AAStateValid = $("#AAStateValid");
        var AACityValid = $("#AACityValid");
        var AADistrictValid = $("#AADistrictValid");
        var AAPostcodeValid = $("#AAPostcodeValid");
        var AAWebsiteValid = $("#AAWebsiteValid");
        var AAEmailValid = $("#AAEmailValid");
        var AAOfficeNoValid = $("#AAOfficeNoValid");

        var addTAddDivValid = $("#additionalAddValidation");

        if (AAAddr1 == "") {
            AAAddr1Valid.removeClass("d-none");
            addTAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            AAAddr1Valid.addClass("d-none");
            addTAddDivValid.addClass("d-none");
        }

        if (AACountry == "") {
            AACountryValid.removeClass("d-none");
            addTAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            AACountryValid.addClass("d-none");
            addTAddDivValid.addClass("d-none");
        }

        if (AAState == "") {
            AAStateValid.removeClass("d-none");
            addTAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            AAStateValid.addClass("d-none");
            addTAddDivValid.addClass("d-none");
        }

        if (AACity == "") {
            AACityValid.removeClass("d-none");
            addTAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            AACityValid.addClass("d-none");
            addTAddDivValid.addClass("d-none");
        }

        if (AADistrict == "") {
            AADistrictValid.removeClass("d-none");
            addTAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            AADistrictValid.addClass("d-none");
            addTAddDivValid.addClass("d-none");
        }

        if (AACountry == "70" && AAPostcode == "") {
            AAPostcodeValid.removeClass("d-none");
            addTAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            AAPostcodeValid.addClass("d-none");
            addTAddDivValid.addClass("d-none");
        }

        if (AAOfficeNo == "") {
            AAOfficeNoValid.removeClass("d-none");
            addTAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            AAOfficeNoValid.addClass("d-none");
            addTAddDivValid.addClass("d-none");
        }
        if (AAEmail == "") {
            AAEmailValid.removeClass("d-none");
            addTAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            AAEmailValid.addClass("d-none");
            addTAddDivValid.addClass("d-none");
        }
        if (AAWebsite == "") {
            AAWebsiteValid.removeClass("d-none");
            addTAddDivValid.removeClass("d-none");
            isValid = false;
            return isValid;
        } else {
            isValid = true;
            AAWebsiteValid.addClass("d-none");
            addTAddDivValid.addClass("d-none");
        }

        return isValid;
    }

    //function getCityData(countryID, stateID, cityID) {
    //    var countryID = countryID.val();
    //    var statesID = stateID.val();

    //    $.ajax({
    //        url: window.ajaxUrl.GetCityByCountryStatesId,
    //        type: "POST",
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        data: JSON.stringify({ countryID: countryID, statesID: statesID }),
    //        async: false,
    //        success: function (result) {
    //            cityID.empty();
    //            cityID.html('<option value="">Select City</option>');
    //            $.each(result.data, function (index, item) {
    //                cityID.append(
    //                    $("<option>", {
    //                        value: item.CityIFCAID,
    //                        text: item.CityIFCAName
    //                    })
    //                );
    //            });
    //        }
    //    });
    //}

    //function getDistrictData(countryID, stateID, cityID, districtID) {
    //    var countryID = countryID.val();
    //    var statesID = stateID.val();
    //    var cityID = cityID.val();

    //    $.ajax({
    //        url: window.ajaxUrl.GetDistrictByCountryStatesCityId,
    //        type: "POST",
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        data: JSON.stringify({
    //            countryID: countryID,
    //            statesID: statesID,
    //            cityID: cityID
    //        }),
    //        async: false,
    //        success: function (result) {
    //            districtID.empty();
    //            districtID.html('<option value="">Select District</option>');
    //            $.each(result.data, function (index, item) {
    //                districtID.append(
    //                    $("<option>", {
    //                        value: item.DistrictIFCAID,
    //                        text: item.DistrictIFCAName
    //                    })
    //                );
    //            });
    //        }
    //    });
    //}

    function initializeModalValues() {
        $("#RAAddr1").val($("#CPAddressLine1").val());
        $("#RAAddr2").val($("#CPAddressLine2").val());
        $("#RAAddr3").val($("#CPAddressLine3").val());

        setTimeout(function () {
            if ($("#CPCountry1").val() != "") {
                let RACountryValue = $("#CPCountry1").val();
                let RACountryText = $("#CPCountry2").html();
                if (RACountryValue && RACountryText) {
                    let RACountryOpt = new Option(RACountryText, RACountryValue, true, true);
                    $("#RACountry").append(RACountryOpt).trigger("change");
                }
            }

            let RAStateOpt = new Option($("#CPState2").html(), $("#CPState1").val(), true, true);
            $("#RAState").append(RAStateOpt).trigger("change");

            let RACityOpt = new Option($("#CPCity2").html(), $("#CPCity1").val(), true, true);
            $("#RACity").append(RACityOpt).trigger("change");

            let RADistrictOpt = new Option($("#CPDistrict2").html(), $("#CPDistrict1").val(), true, true);
            $("#RADistrict").append(RADistrictOpt).trigger("change");

            $("#RAPostcode").val($("#CPPostcode").val());
        }, 1000);

        $("#CAAddr1").val($("#CPCorpAddressLine1").val());
        $("#CAAddr2").val($("#CPCorpAddressLine2").val());
        $("#CAAddr3").val($("#CPCorpAddressLine3").val());
        setTimeout(function () {
            if ($("#CPCorpCountry1").val() != "") {
                let defaultValue = $("#CPCorpCountry1").val();
                let defaultText = $("#CPCorpCountry2").html();
                if (defaultValue && defaultText) {
                    var option = new Option(defaultText, defaultValue, true, true);
                    $("#CACountry").append(option).trigger("change");
                }
            }
            let CAStateOpt = new Option($("#CPCorpState2").html(), $("#CPCorpState1").val(), true, true);
            $("#CAState").append(CAStateOpt).trigger("change");

            let CACityOpt = new Option($("#CPCorpCity2").html(), $("#CPCorpCity1").val(), true, true);
            $("#CACity").append(CACityOpt).trigger("change");

            let CADistrictOpt = new Option($("#CPCorpDistrict2").html(), $("#CPCorpDistrict1").val(), true, true);
            $("#CADistrict").append(CADistrictOpt).trigger("change");

        }, 1000);
        $("#CAPostcode").val($("#CPCorpPostcode").val());
        $("#CAWebsite").val($("#CPCorpWebsite").val());
        $("#CAOfficeNo").val($("#CPCorpOfficeNo").val());

        $("#AAAddr1").val($("#CPAddAddressLine1").val());
        $("#AAAddr2").val($("#CPAddAddressLine2").val());
        $("#AAAddr3").val($("#CPAddAddressLine3").val());
        setTimeout(function () {
            if ($("#CPAddCountry1").val() != "") {
                let defaultValue = $("#CPAddCountry1").val();
                let defaultText = $("#CPAddCountry2").html();
                if (defaultValue && defaultText) {
                    var option = new Option(defaultText, defaultValue, true, true);
                    $("#AACountry").append(option).trigger("change");
                }
            }

            let AAStateOpt = new Option($("#CPAddState2").html(), $("#CPAddState1").val(), true, true);
            $("#AAState").append(AAStateOpt).trigger("change");

            let AACityOpt = new Option($("#CPAddCity2").html(), $("#CPAddCity1").val(), true, true);
            $("#AACity").append(AACityOpt).trigger("change");

            let AADistrictOpt = new Option($("#CPAddDistrict2").html(), $("#CPAddDistrict1").val(), true, true);
            $("#AADistrict").append(AADistrictOpt).trigger("change");

        }, 1000);
        $("#AAPostcode").val($("#CPAddPostcode").val());
        $("#AAWebsite").val($("#CPAddWebsite").val());
        $("#AAOfficeNo").val($("#CPAddOfficeNo").val());

        if ($("#RAAddr1").val() == "") {
            $("#showHideRADiv1").removeClass("d-none");
            $("#showHideRADiv2").addClass("d-none");
        } else {
            $("#showHideRADiv1").addClass("d-none");
            $("#showHideRADiv2").removeClass("d-none");
        }

        if ($("#CAAddr1").val() == "") {
            $("#showHideCADiv1").removeClass("d-none");
            $("#showHideCADiv2").addClass("d-none");
        } else {
            $("#showHideCADiv1").addClass("d-none");
            $("#showHideCADiv2").removeClass("d-none");
        }

        if ($("#AAAddr1").val() == "") {
            $("#showHideAADiv1").removeClass("d-none");
            $("#showHideAADiv2").addClass("d-none");
        } else {
            $("#showHideAADiv1").addClass("d-none");
            $("#showHideAADiv2").removeClass("d-none");
        }
    }

    function saveRAForm() {
        $("#CPAddressLine1").val($("#RAAddr1").val());
        $("#CPAddressLine2").val($("#RAAddr2").val());
        $("#CPAddressLine3").val($("#RAAddr3").val());
        $("#CPCountry1").val($("#RACountry").val());
        $("#CPState1").val($("#RAState").val());
        $("#CPCity1").val($("#RACity").val());
        $("#CPDistrict1").val($("#RADistrict").val());
        $("#CPPostcode").val($("#RAPostcode").val());

        $("#CPAddressLine1Label").text($("#RAAddr1").val().toUpperCase());
        $("#CPAddressLine2Label").text($("#RAAddr2").val().toUpperCase());
        $("#CPAddressLine3Label").text($("#RAAddr3").val().toUpperCase());
        $("#CPCountry2").text($("#RACountry option:selected").text().toUpperCase());
        $("#CPState2").text($("#RAState option:selected").text().toUpperCase());
        $("#CPCity2").text($("#RACity option:selected").text().toUpperCase());
        $("#CPDistrict2").text($("#RADistrict option:selected").text().toUpperCase());
        $("#CPPostcodeLabel").text($("#RAPostcode").val());

        $("#AddEditRegisteredAdd").modal("hide");
        $("#showHideRADiv1").addClass("d-none");
        $("#showHideRADiv2").removeClass("d-none");
    }

    function saveCAForm() {
        $("#CPCorpAddressLine1").val($("#CAAddr1").val());
        $("#CPCorpAddressLine2").val($("#CAAddr2").val());
        $("#CPCorpAddressLine3").val($("#CAAddr3").val());
        $("#CPCorpCountry1").val($("#CACountry").val());
        $("#CPCorpState1").val($("#CAState").val());
        $("#CPCorpCity1").val($("#CACity").val());
        $("#CPCorpDistrict1").val($("#CADistrict").val());
        $("#CPCorpPostcode").val($("#CAPostcode").val());
        $("#CPCorpWebsite").val($("#CAWebsite").val());
        $("#CPCorpEmailAddress").val($("#CAEmail").val());
        $("#CPCorpOfficeNo").val($("#CAOfficeNo").val());

        $("#CPCorpAddressLine1Label").text($("#CAAddr1").val().toUpperCase());
        $("#CPCorpAddressLine2Label").text($("#CAAddr2").val().toUpperCase());
        $("#CPCorpAddressLine3Label").text($("#CAAddr3").val().toUpperCase());
        $("#CPCorpCountry2").text($("#CACountry option:selected").text().toUpperCase());
        $("#CPCorpState2").text($("#CAState option:selected").text().toUpperCase());
        $("#CPCorpCity2").text($("#CACity option:selected").text().toUpperCase());
        $("#CPCorpDistrict2").text($("#CADistrict option:selected").text().toUpperCase());
        $("#CPCorpPostcodeLabel").text($("#CAPostcode").val());
        $("#CPCorpWebsiteLabel").text($("#CAWebsite").val());
        $("#CPCorpEmailAddressLabel").text($("#CAEmail").val());
        cpcno1_countrycode = iti1.getSelectedCountryData();
        $("#CPCorpOfficeNoLabel").text("+" + cpcno1_countrycode.dialCode + " " + $("#CAOfficeNo").val());
        $("#CPCAOfficeNoCountry").val(cpcno1_countrycode.iso2);
        $("#CPCAOfficeNoDialCode").val(cpcno1_countrycode.dialCode);

        $("#AddEditCorrespondenceAdd").modal("hide");
        $("#showHideCADiv1").addClass("d-none");
        $("#showHideCADiv2").removeClass("d-none");
    }

    function saveAAForm() {
        $("#CPAddAddressLine1").val($("#AAAddr1").val());
        $("#CPAddAddressLine2").val($("#AAAddr2").val());
        $("#CPAddAddressLine3").val($("#AAAddr3").val());
        $("#CPAddCountry1").val($("#AACountry").val());
        $("#CPAddState1").val($("#AAState").val());
        $("#CPAddCity1").val($("#AACity").val());
        $("#CPAddDistrict1").val($("#AADistrict").val());
        $("#CPAddPostcode").val($("#AAPostcode").val());
        $("#CPAddWebsite").val($("#AAWebsite").val());
        $("#CPAddEmailAddress").val($("#AAEmail").val());
        $("#CPAddOfficeNo").val($("#AAOfficeNo").val());

        $("#CPAddAddressLine1Label").text($("#AAAddr1").val().toUpperCase());
        $("#CPAddAddressLine2Label").text($("#AAAddr2").val().toUpperCase());
        $("#CPAddAddressLine3Label").text($("#AAAddr3").val().toUpperCase());
        $("#CPAddCountry2").text($("#AACountry option:selected").text().toUpperCase());
        $("#CPAddState2").text($("#AAState option:selected").text().toUpperCase());
        $("#CPAddCity2").text($("#AACity option:selected").text().toUpperCase());
        $("#CPAddDistrict2").text($("#AADistrict option:selected").text().toUpperCase());
        $("#CPAddPostcodeLabel").text($("#AAPostcode").val());
        $("#CPAddWebsiteLabel").text($("#AAWebsite").val());
        $("#CPAddEmailAddressLabel").text($("#AAEmail").val());
        cpcno2_countrycode = iti2.getSelectedCountryData();
        $("#CPAddOfficeNoLabel").text("+" + cpcno2_countrycode.dialCode + " " + $("#AAOfficeNo").val());
        $("#CPAAOfficeNoCountry").val(cpcno2_countrycode.iso2);
        $("#CPAAOfficeNoDialCode").val(cpcno2_countrycode.dialCode);
        $("#AddEditAdditionalAdd").modal("hide");
        $("#showHideAADiv1").addClass("d-none");
        $("#showHideAADiv2").removeClass("d-none");
    }

    function resetRAForm() {
        $("#RAAddr1").val("");
        $("#RAAddr2").val("");
        $("#RAAddr3").val("");
        $RACountry = $("#RACountry");
        $RACountry.empty();
        getCountryList($RACountry);
        $("#RAState").empty();
        $("#RAState").html('<option value="">Select State</option>');
        $("#RACity").empty();
        $("#RACity").html('<option value="">Select City</option>');
        $("#RADistrict").empty();
        $("#RADistrict").html('<option value="">Select District</option>');
        $("#RAPostcode").val("");

        $("#CPAddressLine1Label").text("");
        $("#CPAddressLine2Label").text("");
        $("#CPAddressLine3Label").text("");
        $("#CPCountry2").text("");
        $("#CPState2").text("");
        $("#CPCity2").text("");
        $("#CPDistrict2").text("");
        $("#CPPostcodeLabel").text("");

        $("#CPAddressLine1").val("");
        $("#CPAddressLine2").val("");
        $("#CPAddressLine3").val("");
        $("#CPCountry1").val("");
        $("#CPState1").val("");
        $("#CPCity1").val("");
        $("#CPDistrict1").val("");
        $("#CPPostcode").val("");
    }

    function resetCAForm() {
        $("#CAAddr1").val("");
        $("#CAAddr2").val("");
        $("#CAAddr3").val("");
        $CACountry = $("#CACountry");
        $CACountry.empty();
        getCountryList($CACountry);
        $("#CAState").empty();
        $("#CAState").html('<option value="">Select State</option>');
        $("#CACity").empty();
        $("#CACity").html('<option value="">Select City</option>');
        $("#CADistrict").empty();
        $("#CADistrict").html('<option value="">Select District</option>');
        $("#CAPostcode").val("");
        $("#CAOfficeNo").val("");
        //$("#CAEmail").val("");
        $("#CAWebsite").val("");

        $("#CPCorpAddressLine1Label").text("");
        $("#CPCorpAddressLine2Label").text("");
        $("#CPCorpAddressLine3Label").text("");
        $("#CPCorpCountry2").text("");
        $("#CPCorpState2").text("");
        $("#CPCorpCity2").text("");
        $("#CPCorpDistrict2").text("");
        $("#CPCorpWebsiteLabel").text("");
        $("#CPCorpEmailAddressLabel").text("");
        $("#CPCorpOfficeNoLabel").text("");
        $("#CPCorpPostcodeLabel").text("");

        $("#CPCorpAddressLine1").val("");
        $("#CPCorpAddressLine2").val("");
        $("#CPCorpAddressLine3").val("");
        $("#CPCorpCountry1").val("");
        $("#CPCorpState1").val("");
        $("#CPCorpCity1").val("");
        $("#CPCorpDistrict1").val("");
        $("#CPCorpWebsite").val("");
        $("#CPCorpEmailAddress").val("");
        $("#CPCorpOfficeNo").val("");
        $("#CPCorpPostcode").val("");

        $("#CPCAOfficeNoCountry").val("");
        $("#CPCAOfficeNoDialCode").val("");
    }

    function resetAAForm() {
        $("#AAAddr1").val("");
        $("#AAAddr2").val("");
        $("#AAAddr3").val("");
        $AACountry = $("#AACountry");
        $AACountry.empty();
        getCountryList($AACountry);
        $("#AAState").empty();
        $("#AAState").html('<option value="">Select State</option>');
        $("#AACity").empty();
        $("#AACity").html('<option value="">Select City</option>');
        $("#AADistrict").empty();
        $("#AADistrict").html('<option value="">Select District</option>');
        $("#AAPostcode").val("");
        $("#AAOfficeNo").val("");
        //$("#AAEmail").val("");
        $("#AAWebsite").val("");

        $("#CPAddAddressLine1Label").text("");
        $("#CPAddAddressLine2Label").text("");
        $("#CPAddAddressLine3Label").text("");
        $("#CPAddCountry2").text("");
        $("#CPAddState2").text("");
        $("#CPAddCity2").text("");
        $("#CPAddDistrict2").text("");
        $("#CPAddPostcodeLabel").text("");
        $("#CPAddWebsiteLabel").text("");
        $("#CPAddEmailAddressLabel").text("");
        $("#CPAddOfficeNoLabel").text("");

        $("#CPAddAddressLine1").val("");
        $("#CPAddAddressLine2").val("");
        $("#CPAddAddressLine3").val("");
        $("#CPAddCountry1").val("");
        $("#CPAddState1").val("");
        $("#CPAddCity1").val("");
        $("#CPAddDistrict1").val("");
        $("#CPAddPostcode").val("");
        $("#CPAddWebsite").val("");
        $("#CPAddEmailAddress").val("");
        $("#CPAddOfficeNo").val("");
        $("#CPAAOfficeNoCountry").val("");
        $("#CPAAOfficeNoDialCode").val("");
    }

    function duplicateRAForm() {
        //if (
        //    $("#RAAddr1").valid() &&
        //    $("#RACountry").valid() &&
        //    $("#RAState").valid() &&
        //    $("#RACity").valid() &&
        //    $("#RADistrict").valid() &&
        //    $("#RAPostcode").valid()
        //) {
        $("#CAAddr1").val($("#RAAddr1").val());
        $("#CAAddr2").val($("#RAAddr2").val());
        $("#CAAddr3").val($("#RAAddr3").val());

        if ($("#CPCountry1").val() != "") {
            let RACountryValue = $("#CPCountry1").val();
            let RACountryText = $("#CPCountry2").html();
            if (RACountryValue && RACountryText) {
                let RACountryOpt = new Option(RACountryText, RACountryValue, true, true);
                $("#CACountry").append(RACountryOpt).trigger("change");
            }
        }

        let RAStateOpt = new Option($("#CPState2").html(), $("#CPState1").val(), true, true);
        $("#CAState").append(RAStateOpt).trigger("change");

        let RACityOpt = new Option($("#CPCity2").html(), $("#CPCity1").val(), true, true);
        $("#CACity").append(RACityOpt).trigger("change");

        let RADistrictOpt = new Option($("#CPDistrict2").html(), $("#CPDistrict1").val(), true, true);
        $("#CADistrict").append(RADistrictOpt).trigger("change");

        $("#CAPostcode").val($("#RAPostcode").val());
    }

    function updateSelect2() {
        //$(".countryDropdown").each(function (i, obj) {
        //    if (!$(this).hasClass("addedSelect2")) {
        //        $(this).select2({ placeholder: "Select Country", width: "100%", dropdownAutoWidth: "auto" });
        //        $(this).addClass("addedSelect2");
        //    }
        //});

        $("#tbodyCompany").find(".CPCompParentChild").each(function (i, obj) {
            if (!$(this).hasClass("addedSelect2")) {
                $(this).select2({ placeholder: "Select Parent/Child", width: "100%", dropdownAutoWidth: "auto" });
                $(this).addClass("addedSelect2");
            }
        });

        $(".statesDropdown").each(function (i, obj) {
            if (!$(this).hasClass("addedSelect2")) {
                //$(this).select2({ placeholder: "Select State", width: "100%", dropdownAutoWidth: "auto" });
                $(this).addClass("addedSelect2");
            }
        });

        $(".cityDropdown").each(function (i, obj) {
            if (!$(this).hasClass("addedSelect2")) {
               // $(this).select2({ placeholder: "Select City", width: "100%", dropdownAutoWidth: "auto" });
                $(this).addClass("addedSelect2");
            }
        });

        $(".districtDropdown").each(function (i, obj) {
            if (!$(this).hasClass("addedSelect2")) {
                //$(this).select2({ placeholder: "Select District", width: "100%", dropdownAutoWidth: "auto" });
                $(this).addClass("addedSelect2");
            }
        });

        $("#CPIndustryType").each(function (i, obj) {
            if (!$(this).hasClass("addedSelect2")) {
                $(this).select2({ placeholder: "Select Industry Type", width: "100%", dropdownAutoWidth: "auto" });
                $(this).addClass("addedSelect2");
            }
        });
        $("#CPfoMSICCodefoID").each(function (i, obj) {
            if (!$(this).hasClass("addedSelect2")) {
                $(this).select2({ placeholder: "Select MSIC Code", width: "100%", dropdownAutoWidth: "auto" });
                $(this).addClass("addedSelect2");
            }
        });
        $("#CPfoClassificationCodefoID").each(function (i, obj) {
            if (!$(this).hasClass("addedSelect2")) {
                $(this).select2({ placeholder: "Select Classification Code", width: "100%", dropdownAutoWidth: "auto" });
                $(this).addClass("addedSelect2");
            }
        });

        //$(".countryDropdown")
        //  .val("0")
        //  .trigger("change");
    }

    function calculateShareholder() {
        var i = 0;
        var j = 0;

        var total = 0;
        $("#tbodyShareHolder tr").each(function (index, elem) {
            let td = parseInt(
                $(
                    "input[name='GeneralInfo.CompanyParticular.CPShareholder[" +
                    i +
                    "].CPSHShareholding']"
                ).val().replace(/,/g, '')
            );


            if (isNaN(td)) {
                td = 0;
            }

            total = total + td;
            i++;
        });

        $("#tbodyShareHolder tr").each(function (index, elem) {
            let a = parseInt(
                $(
                    "input[name='GeneralInfo.CompanyParticular.CPShareholder[" +
                    j +
                    "].CPSHShareholding']"
                ).val().replace(/,/g, '')
            );


            if (isNaN(a)) {
                a = 0;
            }

            let b = $(
                "input[name='GeneralInfo.CompanyParticular.CPShareholder[" +
                j +
                "].CPSHShareholdingP']"
            );

            let c = a / total * 100;

            if (isNaN(c)) {
                c = 0;
            }
            c = c.toFixed(2);
            b.val(c);

            j++;
        });
    }
    function limitOneParent() {
        var i = 0;
        var j = 0;
        var isChecked = 0;
        $("#tbodyCompany tr").each(function (index, elem) {
            let td = $('#CPCompParentChild' + i).val();

            if (td == "SLI-0254") {
                isChecked = isChecked + 1;
                $('#CPCompParentChild' + i).addClass('isParent');
                return false;
            } else {
                $('#CPCompParentChild' + i).removeClass('isParent');
            }
            i++;
        });

        if (isChecked > 0) {
            $("#tbodyCompany tr").find('select').each(function (index, elem) {
                if (!$(this).hasClass('isParent')) {
                    $(this).find("option[value='SLI-0254']").attr('disabled', 'disabled');
                }
            });
        } else {
            $("#tbodyCompany tr").find('select').each(function (index, elem) {
                $(this).find("option[value='SLI-0254']").removeAttr("disabled");
            });
        }
    }
    function calculateYearOfBusiness() {
        var now = moment(new Date()); //todays date
        var end = moment($("#dateEstablished").val(), "DD/MM/YYYY"); // another date
        var years = now.diff(end, 'year');
        end.add(years, 'years');

        var months = now.diff(end, 'months');
        end.add(months, 'months');

        var days = now.diff(end, 'days');

        years = years || 0;
        months = months || 0;
        days = days || 0;

        $("#CPYearsInBusiness").val(years + ' years,  ' + months + ' months,  ' + days + ' days');
    }
    function updateCounter() {
        var i = 1;
        var j = 1;
        var k = 1;
        $(".shcounter").each(function (index, elem) {
            $(this).html(i);
            i++;
        });

        $(".drcounter").each(function (index, elem) {
            $(this).html(j);
            j++;
        });

        $(".pccounter").each(function (index, elem) {
            $(this).html(k);
            k++;
        });
    }
    //#endregion
 
    //#region _OnChange
    $("#CACountry").on("change", function (e) {
        $CACountry = $("#CACountry");
        $CAState = $("#CAState");
        getStateData($CACountry, $CAState);

        var $CAPostcode = $("#CAPostcode"); // Assuming you have a "for" attribute on the label
        if ($CACountry.val() == "70") {
            // Country is not selected, remove the "required" class from the Postcode label
            $CAPostcode.siblings("label").addClass("required");
            $CAPostcode.attr("cavalid", "yes");
        } else {
            // Country is selected, add the "required" class to the Postcode label
            $CAPostcode.siblings("label").removeClass("required");
            $CAPostcode.removeAttr("cavalid");
        }
    });

    $("#RACountry").on("change", function (e) {
        $RACountry = $("#RACountry");
        $RAState = $("#RAState");
        getStateData($RACountry, $RAState);

        var $RAPostcode = $("#RAPostcode"); // Assuming you have a "for" attribute on the label
        if ($RACountry.val() == "70") {
            // Country is not selected, remove the "required" class from the Postcode label
            $RAPostcode.siblings("label").addClass("required");
            $RAPostcode.attr("ravalid", "yes");
        } else {
            // Country is selected, add the "required" class to the Postcode label
            $RAPostcode.siblings("label").removeClass("required");
            $RAPostcode.removeAttr("ravalid");
        }
    });

    $("#AACountry").on("change", function (e) {
        $AACountry = $("#AACountry");
        $AAState = $("#AAState");
        getStateData($AACountry, $AAState);

        var $AAPostcode = $("#AAPostcode"); // Assuming you have a "for" attribute on the label
        if ($AACountry.val() == "70") {
            // Country is not selected, remove the "required" class from the Postcode label
            $AAPostcode.siblings("label").addClass("required");
            $AAPostcode.attr("aavalid", "yes");
        } else {
            // Country is selected, add the "required" class to the Postcode label
            $AAPostcode.siblings("label").removeClass("required");
            $AAPostcode.removeAttr("aavalid");
        }
    });

    $("#CAState").on("change", function (e) {
        $CACountry = $("#CACountry");
        $CAState = $("#CAState");
        $CACity = $("#CACity");
        getCityData($CACountry, $CAState, $CACity);
    });

    $("#RAState").on("change", function (e) {
        $RACountry = $("#RACountry");
        $RAState = $("#RAState");
        $RACity = $("#RACity");
        getCityData($RACountry, $RAState, $RACity);
    });

    $("#AAState").on("change", function (e) {
        $AACountry = $("#AACountry");
        $AAState = $("#AAState");
        $AACity = $("#AACity");
        getCityData($AACountry, $AAState, $AACity);
    });

    $("#CACity").on("change", function (e) {
        $CACountry = $("#CACountry");
        $CAState = $("#CAState");
        $CACity = $("#CACity");
        $CADistrict = $("#CADistrict");
        getDistrictData($CACountry, $CAState, $CACity, $CADistrict);
    });

    $("#RACity").on("change", function (e) {
        $RACountry = $("#RACountry");
        $RAState = $("#RAState");
        $RACity = $("#RACity");
        $RADistrict = $("#RADistrict");
        getDistrictData($RACountry, $RAState, $RACity, $RADistrict);
    });

    $("#AACity").on("change", function (e) {
        $AACountry = $("#AACountry");
        $AAState = $("#AAState");
        $AACity = $("#AACity");
        $AADistrict = $("#AADistrict");
        getDistrictData($AACountry, $AAState, $AACity, $AADistrict);
    });

    $('input[name="corresAddRButton"]').change(function () {
        if ($(this).is(":checked") && $(this).val() == "True") {
            $("#AddEditCorrespondenceAdd").modal("show");
            duplicateRAForm();
        } else {
            $("#AddEditCorrespondenceAdd").modal("show");
            resetCAForm();
        }
    });

    $('input[name="corresAddRButton"]').click(function () {
        if ($(this).is(":checked") && $(this).val() == "True") {
            $("#AddEditCorrespondenceAdd").modal("show");
            duplicateRAForm();
        } else {
            $("#AddEditCorrespondenceAdd").modal("show");
            resetCAForm();
        }
    });

    $(".SSTdropdown").change(function () {
        if ($(".SSTdropdown:checked").val() === "No") {
            $("#SSTTextbox").val("");
            $("#SSTTextbox").attr("readonly", "readonly");
            $("#SSTTextboxValid").addClass("d-none");
        } else {
            $("#SSTTextbox").removeAttr("readonly");
            $("#SSTTextboxValid").removeClass("d-none");
        }
    });

    $(".GSTdropdown").change(function () {
        if ($(".GSTdropdown:checked").val() === "No") {
            $("#GSTTextbox").val("");
            $("#GSTTextbox").attr("readonly", "readonly");
            $("#GSTTextboxValid").addClass("d-none");
        } else {
            $("#GSTTextbox").removeAttr("readonly");
            $("#GSTTextboxValid").removeClass("d-none");
        }
    });

    $("#dateEstablished").change(function () {
        var now = moment(new Date()); //todays date
        var end = moment($("#dateEstablished").val(), "DD/MM/YYYY"); // another date
        var years = now.diff(end, 'year');
        end.add(years, 'years');

        var months = now.diff(end, 'months');
        end.add(months, 'months');

        var days = now.diff(end, 'days');

        years = years || 0;
        months = months || 0;
        days = days || 0;

        $("#CPYearsInBusiness").val(years + ' years,  ' + months + ' months,  ' + days + ' days');
    });

    $("#tbodyDirector").on("change", ".CPDDesignationName", function (e) {
        var id = $("option:selected", this).attr("tagID");
        $this = $(this).closest("tr");
        $this.find(".CPDDesignation").val(id);
    });

    $("#tbodyDirector").on("change", ".CPDDOA", function (e) {
        var selectedDate = $(this).val();

        $this = $(this).closest("tr");
        $this.find(".CPDDOR").datepicker("destroy");
        $this.find(".CPDDOR").datepicker({
            autoclose: true,
            format: "dd/mm/yyyy",
            startDate: selectedDate,
            endDate: '+0d'
        });
    });

    $("#tbodyDirector").on("blur", ".CPDNewIDNo", function (e) {
        $this = $(this).closest("tr");
        if ($this.find(".CPDOldICNo_ROC_ROB").val().length > 0) {
            if ($(this).val().length > 0) {
                $(this).val("");
                Swal.fire({
                    title: "<span class='swal-custom-title'>Warning</span>",
                    html: "<span class='swal-custom-text'>You can only key-in New ID or Passport.</span>",
                    confirmButtonColor: "#16a085",
                    confirmButtonText: "OK",
                    icon: "warning",
                })
            }
        }
    });

    $("#tbodyDirector").on("blur", ".CPDOldICNo_ROC_ROB", function (e) {
        if ($(this).val().length > 0) {
            $this = $(this).closest("tr");

            if ($this.find(".CPDNewIDNo").val().length > 0) {
                $this.find(".CPDNewIDNo").val("");
                Swal.fire({
                    title: "<span class='swal-custom-title'>Warning</span>",
                    html: "<span class='swal-custom-text'>You can only key-in New ID or Passport.</span>",
                    confirmButtonColor: "#16a085",
                    confirmButtonText: "OK",
                    icon: "warning",
                })
            }
        }
        $this.find(".CPDNewIDNo").removeClass('smlinputrequired');
    });

    $("#tbodyShareHolder").on("blur", ".CPSHNewIDNo", function (e) {
        $this = $(this).closest("tr");
        if ($this.find(".CPSHOldICNo_ROC_ROB").val().length > 0) {
            if ($(this).val().length > 0) {
                $(this).val("");
                Swal.fire({
                    title: "<span class='swal-custom-title'>Warning</span>",
                    html: "<span class='swal-custom-text'>You can only key-in New ID or Passport.</span>",
                    confirmButtonColor: "#16a085",
                    confirmButtonText: "OK",
                    icon: "warning",
                })
            }
            Swal.fire({
                title: "<span class='swal-custom-title'>Warning</span>",
                html: "<span class='swal-custom-text'>You can only key-in New ID or Passport.</span>",
                confirmButtonColor: "#16a085",
                confirmButtonText: "OK",
                icon: "warning",
            })
        }
    });

    $("#tbodyShareHolder").on("blur", ".CPSHOldICNo_ROC_ROB", function (e) {
        if ($(this).val().length > 0) {
            $this = $(this).closest("tr");

            if ($this.find(".CPSHNewIDNo").val().length > 0) {
                $this.find(".CPSHNewIDNo").val("");
                Swal.fire({
                    title: "<span class='swal-custom-title'>Warning</span>",
                    html: "<span class='swal-custom-text'>You can only key-in New ID or Passport.</span>",
                    confirmButtonColor: "#16a085",
                    confirmButtonText: "OK",
                    icon: "warning",
                })
            }
        }
    });

    $("#tbodyCompany").on("change", ".CPCompParentChild", function (e) {
        limitOneParent();
    });


    $("body").on("click", '.CPSHShareholding', function () {
        var _this = $(this);
        const value = _this.val().replace(/,/g, '');
        if (value == "0.00" || value == "0") {
            _this.val("");
        }
    });

    $("body").on("blur", '.CPSHShareholding', function () {
        var _this = $(this);
        const value = _this.val().replace(/,/g, '');
        var amount = parseFloat(value).toLocaleString('en-US', {
            //style: 'decimal',
            //maximumFractionDigits: 2,
            //minimumFractionDigits: 2
        });

        if (amount != "NaN") {
            _this.val(amount);
        } else {
            var amount = parseFloat(0).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
            _this.val(amount);
        }


    });

    $("body").on("click", "#dateEstablishedbro", function (e) {
        e.preventDefault();
        e.stopPropagation();
        var input = $(this).parent().find('#dateEstablished');
        input.focus();
    })
    //#endregion

    //#region _OnClick
    $("#saveRegisteredAdd").on("click", function () {
        //var retval = regAddValidation();
        if (isRAModalValid()) {
            saveRAForm();
        }
    });

    $("#saveCorresspondenceAdd").on("click", function () {
        if (isCAModalValid()) {
            saveCAForm();
        }
    });

    $("#closeRegisteredAdd").on("click", function () {
        $("#AddEditRegisteredAdd :input.smlinputrequired").each(function (i, obj) {
            $(this).removeClass("smlinputrequired");
        });

        $("#AddEditRegisteredAdd span.smlinputrequired").each(function (i, obj) {
            $(this).removeClass("smlinputrequired");
        });

        $("#AddEditRegisteredAdd span.SMLError:not(.d-none)").each(function (i, obj) {
            $(this).addClass("d-none");
        });

        $("span[errorfor='regAddValid']").addClass("d-none");
        $("span[smltaberr='CompParticular']").addClass("hidden");
    });

    $("#closeCorresspondenceAdd").on("click", function () {
        $("#AddEditCorrespondenceAdd :input.smlinputrequired").each(function (i, obj) {
            $(this).removeClass("smlinputrequired");
        });

        $("#AddEditCorrespondenceAdd span.smlinputrequired").each(function (i, obj) {
            $(this).removeClass("smlinputrequired");
        });

        $("#AddEditCorrespondenceAdd span.SMLError:not(.d-none)").each(function (i, obj) {
            $(this).addClass("d-none");
        });

        $("span[errorfor='corrAddValid']").addClass("d-none");
        $("span[smltaberr='CompParticular']").addClass("hidden");
        $("#corresAddRButton1").prop('checked', false);
        $("#corresAddRButton2").prop('checked', false);
    });

    $("#saveAdditionalAdd").on("click", function () {
        //var retval = addTAddValidation();
        if (isAAModalValid()) {
            saveAAForm();
        }
    });

    $("#resetRAForm").on("click", function () {
        resetRAForm();
        $("#showHideRADiv1").removeClass("d-none");
        $("#showHideRADiv2").addClass("d-none");
    });

    $("#resetCAForm").on("click", function () {
        resetCAForm();
        $("#showHideCADiv1").removeClass("d-none");
        $("#showHideCADiv2").addClass("d-none");
    });

    $("body").on("click", "#resetAAForm", function (e) {
        e.preventDefault();
        e.stopPropagation();
        resetAAForm();
        $("#showHideAADiv1").removeClass("d-none");
        $("#showHideAADiv2").addClass("d-none");
    });

    $("body").on("click", ".clickCPDDOAdate", function (e) {
        e.preventDefault();
        e.stopPropagation();
        var _this = $(this).closest("tr");
        _this.find('.CPDDOA').focus();
    })

    $("body").on("click", ".clickCPDDORdate", function (e) {
        e.preventDefault();
        e.stopPropagation();
        var _this = $(this).closest("tr");
        _this.find('.CPDDOR').focus();
    })
    //#endregion

    //#region _OnKeyup
    $("#tbodyShareHolder").keyup(function () {
        $("#tbodyShareHolder")
            .find(".fa-pencil")
            .trigger("click");
        updateAddShareHolderIndex();
        //checkValidationShareHolder();

        calculateShareholder();
    });

    $("#tbodyDirector").keyup(function () {
        updateAddDirectorIndex();
        //checkValidationDirector();
    });

    $("#tbodyCompany").keyup(function () {
        updateAddCompanyIndex();
        //checkValidationCompany();
    });

    $("#SSTTextbox").keyup(function () {
        _this = $(this);

        if (_this.val().length > 0) {
            $("#SSTTextboxValid").addClass("d-none");
        } else {
            $("#SSTTextboxValid").removeClass("d-none");
        }

    });

    $("#GSTTextbox").keyup(function () {
        _this = $(this);

        if (_this.val().length > 0) {
            $("#GSTTextboxValid").addClass("d-none");
        } else {
            $("#GSTTextboxValid").removeClass("d-none");
        }
    });

    //#endregion

    //#region _ShareHolderTable
    $(".add-row-shareholder").click(function () {
        $("#shareHolderEditableTable")
            .find("tbody tr:last")
            .after(
                `<tr>
                <td class='hidden'>
                    <input type='text' class='form-control d-none CPSHfoVendorProfileID vmsdynamictableinput' name='GeneralInfo.CompanyParticular.CPShareholder.CPSHfoVendorProfileID' value='${HVendorID}' />
                    <input type='text' class='form-control d-none CPSHID vmsdynamictableinput' name='GeneralInfo.CompanyParticular.CPShareholder.CPSHID' />
                </td>
                <td class='text-center actionsWidth'>
                    <b><span class='shcounter'></span></b>
                </td>
                <td>
                    <textarea type='text' class='form-control CPSHName vmsdynamictableinput' name='GeneralInfo.CompanyParticular.CPShareholder.CPSHName' inputfor='shareholderValid' customvalidation='yes' smltabfor='CompParticular' style='pointer-events:visible'></textarea>
                </td>
                <td>
                    <input type='text' class='form-control CPSHNewIDNo vmsdynamictableinput' name='GeneralInfo.CompanyParticular.CPShareholder.CPSHNewIDNo' placeholder='000000-00-0000' style='pointer-events:visible' maxlength="14"  />
                </td>
                <td>
                    <input type='text' class='form-control CPSHOldICNo_ROC_ROB vmsdynamictableinput' name='GeneralInfo.CompanyParticular.CPShareholder.CPSHOldICNo_ROC_ROB' style='pointer-events:visible' />
                </td>
                <td >
                    <input type='text' class='form-control text-center CPSHShareholding vmsdynamictableinput' name='GeneralInfo.CompanyParticular.CPShareholder.CPSHShareholding' inputfor='shareholderValid' customvalidation='yes' smltabfor='CompParticular' style='pointer-events:visible' />
                </td>
                <td>
                    <input type='text' class='form-control text-center CPSHShareholdingP vmsdynamictableinput' name='GeneralInfo.CompanyParticular.CPShareholder.CPSHShareholdingP' readonly />
                <td class='actionsWidth'>
                    <button type='button' class='btn btn-sm btn-alizarin deleteShareHolder'>
                        <i class='fa fa-trash' style='font-size:20px'></i>
                    </button>
                </td>
                "</tr>`
            );
        updateCounter();

        $(".deleteShareHolder").prop("disabled", false);
    });

    $("body").on("click", ".deleteShareHolder", function (e) {
        var $tableID = $("#shareHolderEditableTable");

        if ($tableID.find("tbody tr").length === 1) {
            $(".deleteShareHolder").prop("disabled", true);
        }

        if ($tableID.find("tbody tr").length !== 1) {
            $(this)
                .closest("tr")
                .remove();
            updateCounter();
        }
    });
    //#endregion

    //#region _DirectorTable

    $(".add-row-director").click(function () {
        $("#directorEditableTable")
            .find("tbody")
            .append(
            `<tr>
                <td class="hidden">
                    <input type="hidden" class="CPDfoVendorProfileID" value="${HVendorID}" />
                    <input type="hidden" class="CPDDesignation" value="" />
                    <input type="hidden" class="CPDID" value="" />
                </td>
                <td class="text-center actionsWidth">
                    <b><span class="drcounter">1</span></b>
                </td>
                <td>
                    <textarea type="text" class="form-control CPDName vmsdynamictableinput" name="GeneralInfo.CompanyParticular.CPDirector.CPDName" inputfor="directorValid" customvalidation="yes" smltabfor="CompParticular"></textarea>
                </td>
                <td>
                    <textarea type="text" class="form-control CPDResidentialAdd vmsdynamictableinput" name="GeneralInfo.CompanyParticular.CPDirector.CPDResidentialAdd" inputfor="directorValid" customvalidation="yes" smltabfor="CompParticular"></textarea>
                </td>
                <td class="">
                    <input type="text" class="form-control CPDNewIDNo vmsdynamictableinput2" name="GeneralInfo.CompanyParticular.CPDirector.CPDNewIDNo" placeholder="000000-00-0000" maxlength="14">
                </td>
                <td class="">
                    <input type="text" class="form-control CPDOldICNo_ROC_ROB vmsdynamictableinput2" name="GeneralInfo.CompanyParticular.CPDirector.CPDOldICNo_ROC_ROB">
                </td>
                <td>
                    <div class="input-group date vmsdynamictableinput2">
                        <input type="text" class="form-control CPDDOA" name="GeneralInfo.CompanyParticular.CPDirector.CPDDOA" value="" inputfor="directorValid" customvalidation="yes" smltabfor="CompParticular">
                        <span class="input-group-addon clickCPDDOAdate pointme" style="pointer-events:visible">
                            <i class="fa fa-calendar"></i>
                        </span>
                    </div>
                </td>
                <td class="">
                    <div class="input-group date vmsdynamictableinput2">
                        <input type="text" class="form-control CPDDOR" name="GeneralInfo.CompanyParticular.CPDirector.CPDDOR" value="">
                        <span class="input-group-addon clickCPDDORdate pointme" style="pointer-events:visible">
                            <i class="fa fa-calendar"></i>
                        </span>
                    </div>
                </td>
                <td class="vmsdynamictableinput">
                    <textarea type="text" class="form-control CPDRemarks vmsdynamictableinput" name="GeneralInfo.CompanyParticular.CPDirector.CPDRemarks"></textarea>
                </td>
                <td class="actionsWidth">
                    <button type="button" class="btn btn-sm btn-alizarin DeleteDirector">
                        <i class="fa fa-trash" style="font-size:20px"></i>
                    </button>
                </td>
            </tr>`
            );
        updateCounter();
        initDatepicker();
        $(".DeleteDirector").prop("disabled", false);
    });

    $("body").on("click", ".DeleteDirector", function (e) {
        var $tableID = $("#directorEditableTable");

        if ($tableID.find("tbody tr").length === 1) {
            $(".DeleteDirector").prop("disabled", true);
        }

        if ($tableID.find("tbody tr").length !== 1) {
            $(this)
                .closest("tr")
                .remove();
            updateCounter();
        }
    });
    //#endregion

    //#region _CompanyTable
    $(".add-row-company").click(function () {
        var string = "<option value=''></option>";
        for (var i = 0; i < parentChildArray.length; i++) {
            string = string + "<option value='" + parentChildArray[i].SLItemID + "'>" + parentChildArray[i].SLItemName.toUpperCase() + "</option>"
        }
        $("#AddCompanyEditableTable")
            .find("tbody tr:last")
            .after(
                "<tr>" +
                "<td class='hidden'>" +
                "<input type='text' class='form-control d-none CPCfoVendorProfileID' name='GeneralInfo.CompanyParticular.CPCompany.CPCfoVendorProfileID' value='" + HVendorID + "'/>" +
                "</td>" +
                "<td class='hidden'>" +
                "<input type='text' class='form-control d-none CPCompID' name='GeneralInfo.CompanyParticular.CPCompany.CPCompID'/>" +

                "</td>" +
                "<td class='actionsWidth'>" +
                "<b><span class='pccounter'></span></b>" +
                "</td>" +
                "<td>" +
                "<select class='form-control CPCompParentChild' name='GeneralInfo.CompanyParticular.CPCompany.CPCompParentChild'>" +
                string +
                "</select>" +
                "</td>" +
                "<td>" +
                "<input type='text' class='form-control CPCompName' name='GeneralInfo.CompanyParticular.CPCompany.CPCompName' value=''/>" +
                "</td>" +
                "<td class='actionsWidth'>" +
                "<button type='button' class='btn btn-sm btn-alizarin deleteAC'>" +
                "<i class='fa fa-trash' style='font-size:20px'></i>" +
                "</button>" +
                "</td>" +
                "</tr>"
            );

        updateSelect2();
        updateAddCompanyIndex();
        limitOneParent();
        updateCounter();
        $(".deleteAC").prop("disabled", false);
    });

    $("body").on("click", ".deleteAC", function (e) {
        var $tableID = $("#AddCompanyEditableTable");

        if ($tableID.find("tbody tr").length === 1) {
            $("[id^='CPCompParentChild']").val($("#target option:first").val()).trigger('change');;
            $(".CPCompName").val('');
        }
        else {
            $(this).closest("tr").remove();
            updateCounter();
        }
    });

    $('body').on('click', 'input[name="GeneralInfo.CompanyParticular.CPTypeOFCompany"]:not(:disabled)', function () {
        let _this = $(this);
        let thisCheckedValue = _this.val();
        $.ajax({
            url: window.ajaxUrl.GetCompanyTypeInfo,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            data: JSON.stringify({
                id: thisCheckedValue,
            }),
            success: function (result) {
                let TINNo = result.data[0].TOPDefaultTINNumber;
                let MSICCode = result.data[0].TOPDefaultMSICCode;
                let TOPID = result.data[0].TOPID;
                if (TINNo != null) {
                    $('input[name="GeneralInfo.CompanyParticular.CPCreditorTINNo"]').val(TINNo);
                    $('input[name="GeneralInfo.CompanyParticular.CPCreditorTINNo"]').attr('disabled', 'disabled');
                    $('#CPfoMSICCodefoID').val(MSICCode).trigger("change");
                    $('#CPfoMSICCodefoID').attr('disabled', 'disabled');
                }
                else {
                    $('input[name="GeneralInfo.CompanyParticular.CPCreditorTINNo"]').removeAttr('disabled');
                    $('#CPfoMSICCodefoID').removeAttr('disabled');
                }

                if (TOPID == '5' || TOPID == '6' || TOPID == '7') {
                    $(`input[name="GeneralInfo.CompanyParticular.CPSelfBilledeInvoice"]`).removeAttr('disabled');
                    $('#CPSelfBilledeInvoice1').prop('checked', true);
                   
                    $(`input[name="GeneralInfo.CompanyParticular.CPSelfBilledeInvoice"]`).attr('disabled', 'disabled');
                    $('input[name="GeneralInfo.CompanyParticular.CPSelfBillingExpenseItem"]').removeAttr('disabled', 'disabled');
                }
                else if (TOPID == '8') {
                    $(`input[name="GeneralInfo.CompanyParticular.CPSelfBilledeInvoice"]`).removeAttr('disabled');
                    $(`#CPSelfBilledeInvoice2`).prop("checked", true);
                    $(`input[name="GeneralInfo.CompanyParticular.CPSelfBilledeInvoice"]`).attr('disabled', 'disabled');
                    $(`input[name="GeneralInfo.CompanyParticular.CPSelfBilledeInvoice"]`).attr('disabled', 'disabled');
                }
                else if (TOPID == '1' || TOPID == '2' || TOPID == '3' || TOPID == '4') {
                    $(`input[name="GeneralInfo.CompanyParticular.CPSelfBilledeInvoice"]`).removeAttr('disabled');
                    $(`#CPSelfBilledeInvoice2`).prop("checked", true);
                    $(`input[name="GeneralInfo.CompanyParticular.CPSelfBilledeInvoice"]`).attr('disabled', 'disabled');
                    $('select[name="GeneralInfo.CompanyParticular.CPfoMSICCodefoID"]').val('').trigger('change');
                    $('input[name="GeneralInfo.CompanyParticular.CPSelfBillingExpenseItem"]').attr('disabled', 'disabled');
                    $('input[name="GeneralInfo.CompanyParticular.CPSelfBillingExpenseItem"]').val('');
                }
                else {
                    $(`input[name="GeneralInfo.CompanyParticular.CPSelfBilledeInvoice"]`).removeAttr('disabled');
                    $(`#CPSelfBilledeInvoice2`).prop("checked", true);
                    $(`input[name="GeneralInfo.CompanyParticular.CPSelfBilledeInvoice"]`).attr('disabled', 'disabled');
                }
            }
        });
    })
    //#endregion

    if ($("#isExternal").val() == "True") {
        $("body").on("click", "input[name*='GeneralInfo.CompanyParticular.CPTypeOFCompany']:not(:disabled)", function () {
           // SelfBilledAgent();
        })

        $("body").on("change", "#CPIndustryType:not(:disabled)", function () {
            //SelfBilledAgent();
        })

        function SelfBilledAgent() {
            let TOPAgentList = [1, 2, 3, 4];
            let RealEstateID = $("#CPIndustryType option:contains('Real Estate')").val();
            let SelectedTOPID = $("input[id*='CPTypeOFCompany']:checked").val();
            let SelectedIndustryTypeID = $("#CPIndustryType").val();

            if (SelectedIndustryTypeID == RealEstateID) {
                let isAgent = false;

                for (let TOPAgent of TOPAgentList) {
                    if (TOPAgent == SelectedTOPID) {
                        isAgent = true;
                        break;
                    }
                }

                if (isAgent) {
                    let SelfBilledCCode = $("#CPfoClassificationCodefoID option:contains('037')").val();
                    $("#CPSelfBilledeInvoice1").prop("checked", true);
                    $("#CPfoClassificationCodefoID").val(SelfBilledCCode).trigger("change");
                    $("#divMSICCode").removeClass("hidden");
                    $("#divClassificationCode").removeClass("hidden");
                    $("#CPfoMSICCodefoID").attr("customvalidation", "yes");
                    $("#CPfoMSICCodefoID").val("").trigger("change");
                }
                else {
                    $("#CPSelfBilledeInvoice2").prop("checked", true);
                    $("#CPfoClassificationCodefoID").val("").trigger("change");
                    $("#divMSICCode").addClass("hidden");
                    $("#divClassificationCode").addClass("hidden");
                    $("#CPfoMSICCodefoID").attr("customvalidation", "no");
                    $("#CPfoMSICCodefoID").val("").trigger("change");
                }
            }
            else {
                $("#CPSelfBilledeInvoice2").prop("checked", true);
                $("#CPfoClassificationCodefoID").val("").trigger("change");
                $("#divMSICCode").addClass("hidden");
                $("#divClassificationCode").addClass("hidden");
                $("#CPfoMSICCodefoID").attr("customvalidation", "no");
                $("#CPfoMSICCodefoID").val("").trigger("change");
            }
        }
    }
});
