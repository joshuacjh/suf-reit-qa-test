function PIC() {
    if ($("#CSApproverPIC").length > 0) {
        var vendorProfileId = $("#VendorProfileId").val();
        var vendorProfileType = $("#vendorProfileType").val();
        var key = "PIC";
        var assignee = $("#CSApproverPIC option:selected").val();

        $.ajax({
            url: window.ajaxUrl.DoAssigning,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({
                VendorProfileId: vendorProfileId,
                VendorProfile: vendorProfileType,
                assignee: assignee,
                key: key,
            }),
            async: false,
            success: function (result) {
            }
        });
    }
}

function ADMIN() {
    if ($("#CSApproverADMIN").length > 0) {
        var vendorProfileId = $("#VendorProfileId").val();
        var vendorProfileType = $("#vendorProfileType").val();
        var key = "ADMIN";
        var assignee = $("#CSApproverADMIN option:selected").val();

        $.ajax({
            url: window.ajaxUrl.DoAssigning,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({
                VendorProfileId: vendorProfileId,
                VendorProfile: vendorProfileType,
                assignee: assignee,
                key: key,
            }),
            async: false,
            success: function (result) {
            }
        });
    }
}

$(document).ready(function () {
    var VendorProfileId = $("#VendorProfileId").val();
    var isExternal = $("#isExternal").val();
    isExternal = isExternal.toLowerCase();
    var currentStatus = $("#currentStatus").val();
    var vendorProfileType = $("#vendorProfileType").val();

    //workflow buttons
    $("#divWorkflowActions").empty();

    $("select")
      .not(".AnyOneClaimDataCurrencyID")
      .not(".AggregateDataCurrencyID")
      .not(".DeductibleDataCurrencyID")
      .not(".RetroactiveDataCurrencyID")
      .select2({ destroy: true, width: "100%", dropdownAutoWidth: "auto" });

    $("body").on("click", "#btnViewVersion", function (e) {
        var vendorProfileId = $("#VendorProfileId").val();
        var version = $("#ddlVersions option:selected").val();
        window.open(
          ajaxUrl.ConsultantVersion + "?vendorProfileId=" + vendorProfileId + "&versionId=" + version
        );
    });

    //if (isExternal === "false") {
    //    $(".btnpreview").animatedModal();
    //    $("body").on("click", ".btnpreview", function (e) {
    //        var vendorProfileId = $("#VendorProfileId").val();
    //        var version = $("#ddlVersions option:selected").val();

    //        var url = ajaxUrl.ConsultantVersion + "?vendorProfileId=" + vendorProfileId + "&versionId=" + version + "&ispreview=1";

    //        $('#consultantinfo').attr('src', url);
    //        e.stopPropagation();
    //    })
    //}


    //#region Workflow
    var acts = "";

    $.ajax({
        url: window.ajaxUrl.GetAvailableActions,
        type: "POST",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: JSON.stringify({
            id: VendorProfileId,
            moduleId: 200,
            vendorProfileType: vendorProfileType,
            isExternal: isExternal,
            moduleFlow: 1
        }),
        async: false,
        success: function (response) {
            $("#loadermain").addClass("hidden");
            //disable if no workflow
            if (response.length <= 0) {
                DisableAllField();
            }

            console.log(response);

            for (var i = 0; i < response.length; i++) {
                console.log(response[i].ActionTypeName);
                if (response[i].ActionTypeName == "Submit") {
                    if (currentStatus == 10) {
                        response[i].ActionTypeName = "Resubmit";
                        if (response[i].ShowDraftButton) {
                            acts += "<button class='btn btn-peterriver' id='saveAsDraftID' type='submit'>Save As Draft</button>&nbsp;"
                        }
                    }
                    if (currentStatus != 0 && currentStatus != 1) {
                        if (response[i].ShowDraftButton) {
                            acts += "<button class='btn btn-peterriver' id='saveAsDraftID' type='submit'>Save As Draft</button>&nbsp;"
                        }
                    }
                }

                if (response[i].ActionTypeName == "Resubmit") {
                    if (response[i].ShowDraftButton) {
                        acts += "<button class='btn btn-peterriver' id='saveAsDraftID' type='submit'>Save As Draft</button>&nbsp;"
                    }
                }

                if (response[i].ActionTypeName == "Update" && currentStatus != 1) {
                    if (response[i].ShowDraftButton) {
                        acts += "<button class='btn btn-peterriver' id='saveAsDraftID' type='submit'>Save As Draft</button>&nbsp;"
                    }
                }

                if (isExternal === String(response[i].IsExternalAction)) {
                    acts +=
                      "<button class='btn " +
                      response[i].HtmlButtonColorClass +
                      " processWorkflow dontHide' id='" +
                      response[i].ActionId +
                      "' data-actionname='" +
                      response[i].ActionTypeName +
                      "' data-requiredcomment='" +
                      response[i].RequiredComment +
                      "' data-requiredvalidation='" +
                      response[i].IsRequiredValidation +
                      "'>" +
                      response[i].ActionTypeName +
                      "</button>&nbsp;";
                }

                if (response[i].IsFormEditable == false) {
                    DisableAllField();
                }
            }
        },
        error: function (xhr, textStatus, errorThrown) {
            var error = $($.parseHTML(xhr.responseText)[1]).text();
            alert(error);
        },
        complete: function () { }
    });

    $("#divWorkflowActions").append(acts);

    $(".processWorkflow").on("click", function (e) {
        e.preventDefault();


        let $this = $(e.currentTarget);
        let actionId = $this.attr("id");
        let requiredComment = $this.data("requiredcomment");
        let actionName = $this.data("actionname");
        let requiredvalidation = $this.data("requiredvalidation");
       


        $("#WorkflowActionId").val(actionId);
        $("#WorkflowActionName").val(actionName);
        $("#requiredvalidation").val(requiredvalidation);

        if (!assignValid() && actionName == 'Verify') {
            return false;
        } else {
            $.when(PIC(), ADMIN()).then(function () {
                processWorkflow(requiredComment, actionId, actionName, requiredvalidation);
            })
        }
    });

    function processWorkflow(requiredComment, actionId, actionName, requiredvalidation) {

        if (actionId != "Action-2025-00085") {
            if (actionId && actionId !== "") {
                if (SMLCustomValidator()) {
                    var confirmText = "<span class='swal-custom-text'>Click Yes to " + actionName + " the Consultant profile</span>";
                    if (actionName.toLowerCase().indexOf("update") !== -1) {
                        confirmText = "<span class='swal-custom-text'>Click Yes to update the Consultant profile</span>";
                    }
                    Swal.fire({
                        title: "<span class='swal-custom-title'>Do you wish to proceed?</span>",
                        html: confirmText,
                        showCancelButton: true,
                        confirmButtonColor: "#16a085",
                        cancelButtonColor: "#e74c3c",
                        confirmButtonText: "Yes",
                        allowOutsideClick: false
                    }).then(function (result) {
                        if (result.value) {
                            if (isExternal.toString() == "true" && requiredvalidation.toString() == "true") {
                                var template = $('#vendorconsent-template').html();

                                Swal.fire({
                                    html: template,
                                    inputAttributes:
                                    {
                                        autocapitalize: 'off'
                                    },
                                    showCancelButton: true,
                                    confirmButtonText: 'Accept',
                                    cancelButtonText: 'Cancel',
                                    showLoaderOnConfirm: true,
                                    confirmButtonColor: "#16a085",
                                    cancelButtonColor: "#e74c3c",
                                    customClass: 'swal-wide',
                                    didOpen: function () {
                                        $.ajax({
                                            url: window.ajaxUrl.getVendorConsent,
                                            type: "POST",
                                            contentType: "application/json; charset=utf-8",
                                            dataType: "json",
                                            async: false,
                                            success: function (result) {
                                                console.log(result.data)
                                                $("#consentMsg").append(result.data);
                                            }
                                        });
                                    },
                                    preConfirm: function (remarks) {
                                        $("#WorkflowActionComment").val("Acknowledgement Accepted");
                                    },
                                    allowOutsideClick: false
                                }).then(function (response) {
                                    if (response.value) {
                                        if (requiredComment) {
                                            Swal.fire({
                                                title: "<span class='swal-custom-title'>Comment</span>",
                                                input: "textarea",
                                                inputAttributes: {
                                                    autocapitalize: "off",
                                                    id: "swal-comment"
                                                },
                                                showCancelButton: true,
                                                confirmButtonText: "Confirm",
                                                confirmButtonColor: "#16a085",
                                                cancelButtonColor: "#e74c3c",
                                                showLoaderOnConfirm: true,
                                                allowOutsideClick: false,
                                                inputValidator: function (value) {
                                                    if (value === "") {
                                                        return "Please enter a comment";
                                                    }
                                                },
                                                preConfirm: function (value) {
                                                    $("#WorkflowActionComment").val(value);
                                                    if (requiredvalidation == "false") {
                                                        DisableAllField();
                                                        $("#loadermain").removeClass("hidden");
                                                        $("#frmConsultant").submit();
                                                    } else {
                                                        $("#loadermain").removeClass("hidden");
                                                        $("#frmConsultant").submit();
                                                    }
                                                }
                                            }).then(
                                                function (result) {
                                                    if (result.value) {
                                                    }
                                                },
                                                function (error) {
                                                    Swal.fire({ text: error, type: "error" });
                                                }
                                            );
                                        } else {
                                            if (requiredvalidation == "false") {
                                                DisableAllField();
                                                $("#loadermain").removeClass("hidden");
                                                $("#frmConsultant").submit();
                                            } else {
                                                $("#loadermain").removeClass("hidden");
                                                $("#frmConsultant").submit();
                                            }
                                        }
                                    }
                                })
                            } else {
                                if (requiredComment) {
                                    Swal.fire({
                                        title: "<span class='swal-custom-title'>Comment</span>",
                                        input: "textarea",
                                        inputAttributes: {
                                            autocapitalize: "off",
                                            id: "swal-comment"
                                        },
                                        showCancelButton: true,
                                        confirmButtonText: "Confirm",
                                        confirmButtonColor: "#16a085",
                                        cancelButtonColor: "#e74c3c",
                                        showLoaderOnConfirm: true,
                                        allowOutsideClick: false,
                                        inputValidator: function (value) {
                                            if (value === "") {
                                                return "Please enter a comment";
                                            }
                                        },
                                        preConfirm: function (value) {
                                            $("#WorkflowActionComment").val(value);
                                            if (requiredvalidation == "false") {
                                                DisableAllField();
                                                $("#loadermain").removeClass("hidden");
                                                $("#frmConsultant").submit();
                                            } else {
                                                $("#loadermain").removeClass("hidden");
                                                $("#frmConsultant").submit();
                                            }
                                        }
                                    }).then(
                                        function (result) {
                                            if (result.value) {
                                            }
                                        },
                                        function (error) {
                                            Swal.fire({ text: error, type: "error" });
                                        }
                                    );
                                } else {
                                    if (requiredvalidation == "false") {
                                        DisableAllField();
                                        $("#loadermain").removeClass("hidden");
                                        $("#frmConsultant").submit();
                                    } else {
                                        $("#loadermain").removeClass("hidden");
                                        $("#frmConsultant").submit();
                                    }
                                }
                            }
                        }
                    });
                }
            }
        } else {
            Swal.fire({
                title: "Email sent!",
                type: "success",
            }).then(function (result) {
                $("#loadermain").removeClass("hidden");
                $("#frmConsultant").submit();
                _this.attr('disabled', false);
            });
        }
    }

    //#endregion

    function DisableAllField() {
        $("#frmConsultant").find(':input:not(:disabled)')
                .not('.dontHide')
                .not("[aria-controls='auditTrailDatatable']")
                .not("[aria-controls='SMLApprovalList']")
                .prop('disabled', true);
        $(".mustHide").addClass('hidden');
        $('.mustHide').next(".select2-container").addClass('hidden');
        $("#isFormDisabled").val(true);

        setInterval(function () {
            $("#frmConsultant").find(':input:not(:disabled)')
                .not('.dontHide')
                .not("[aria-controls='auditTrailDatatable']")
                .not("[aria-controls='SMLApprovalList']")
                .prop('disabled', true);
            $(".mustHide").addClass('hidden');
            $('.mustHide').next(".select2-container").addClass('hidden');
            $("#isFormDisabled").val(true);
        }, 1000);
    }

    $("#saveAsDraftID").on("click", function (e) {
        e.preventDefault();
        $("#requiredvalidation").val("false");
        $("#WorkflowActionId").val("");
        $("#WorkflowActionName").val("");
        $("#loadermain").removeClass("hidden");
        $("#frmConsultant").submit();
    });

    $(".viewPA").on("click", function (e) {
        e.preventDefault();
        var vendorID = VendorProfileId;

        $.ajax({
            url: window.ajaxUrl.GetPendingApprovalInfo,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ referenceId: vendorID, subreferenceId: 2, moduleId: 200, moduleFlow: 1 }),
            async: false,
            success: function (response) {
                var tbody = $('#tbodyViewApprovals');
                tbody.empty();
                $.each(response, function (k, v) {
                    var tr = '<tr><td>' + response[k].ApprovalRole + '</td><td>' + response[k].ApprovalUser + '</td><td>' + response[k].Status + '</td></tr>';
                    tbody.append(tr);
                });
            },
            error: function (xhr, textStatus, errorThrown) {
                var error = $($.parseHTML(xhr.responseText)[1]).text();
                Util.alert("Alert", `Exception occurred : ${error}.`, true, function () {
                    return;
                });
            }
        });

    });

    $("#vmspopupview").on("click", function (e) {
        $("#vmspopupmenu").removeClass("hidden");
    });

    $("#vmspopupclose").on("click", function (e) {
        $("#vmspopupmenu").addClass("hidden");
    });

});
