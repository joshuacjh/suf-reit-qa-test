$(document).ready(function () {
    var VendorProfileId = $("#VendorProfileId").val();
    var isExternal = $("#isExternal").val();
    isExternal = isExternal.toLowerCase();
    if (isExternal === "false")
        DisableAllField();

    setInterval(function () {
        $("#CPSelfBilledeInvoice1").attr("disabled", "disabled");
        $("#CPSelfBilledeInvoice2").attr("disabled", "disabled");
    }, 1000);

    $(".processWorkflow").on("click", function (e) {
        e.preventDefault();

        var $this = $(e.currentTarget);
        var actionId = $this.attr("id");
        var requiredComment = $this.data("requiredcomment");
        var actionName = $this.data("actionname");
        var requiredvalidation = $this.data("requiredvalidation");

        $("#WorkflowActionId").val(actionId);
        $("#WorkflowActionName").val(actionName);
        $("#requiredvalidation").val(requiredvalidation);

        if (actionId != "Action-2025-00093") {
            if (actionId && actionId !== "") {
                var confirmText = "Click Yes to " + actionName + " the General profile";

                if (actionName.toLowerCase().indexOf("update") !== -1)
                    confirmText = "Click Yes to update the the General profile";

                Swal.fire({
                    title: "Do you wish to proceed?",
                    html: confirmText,
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Yes",
                    allowOutsideClick: false
                }).then(function (result) {
                    if (result.value) {
                        if (isExternal.toString() == "true" && requiredvalidation.toString() == "true") {
                            console.log("isEntered");
                            var template = $('#vendorconsent-template').html();
                            Swal.fire({
                                html: template,
                                inputAttributes:
                                {
                                    autocapitalize: 'off'
                                },
                                confirmButtonText: 'Accept',
                                showLoaderOnConfirm: true,
                                customClass: 'swal-wide',
                                didOpen: function () {
                                    $.ajax({
                                        url: window.ajaxUrl.getVendorConsent,
                                        type: "POST",
                                        contentType: "application/json; charset=utf-8",
                                        dataType: "json",
                                        async: false,
                                        success: function (result) {
                                            console.log(result.data)
                                            $("#consentMsg").append(result.data);
                                        }
                                    });
                                },
                                allowOutsideClick: false
                            }).then(function (response) {
                                if (requiredComment) {
                                    Swal.fire({
                                        title: "Comment",
                                        input: "textarea",
                                        inputAttributes: {
                                            autocapitalize: "off",
                                            id: "swal-comment"
                                        },
                                        showCancelButton: true,
                                        confirmButtonText: "Confirm",
                                        showLoaderOnConfirm: true,
                                        allowOutsideClick: false,
                                        inputValidator: function (value) {
                                            if (value === "")
                                                return "Please enter a comment";
                                        },
                                        preConfirm: function (value) {
                                            $("#WorkflowActionComment").val(value);
                                            if (requiredvalidation == "false") {
                                                DisableAllField();
                                                $("#frmGeneral").submit();
                                            }
                                            else
                                                $("#frmGeneral").submit();
                                        }
                                    });
                                }
                                else {
                                    if (requiredvalidation == "false") {
                                        DisableAllField();
                                        $("#frmGeneral").submit();
                                    }
                                    else
                                        $("#frmGeneral").submit();
                                }
                            })
                        }
                        else {
                            if (requiredComment) {
                                Swal.fire({
                                    title: "Comment",
                                    input: "textarea",
                                    inputAttributes: {
                                        autocapitalize: "off",
                                        id: "swal-comment"
                                    },
                                    showCancelButton: true,
                                    confirmButtonText: "Confirm",
                                    showLoaderOnConfirm: true,
                                    allowOutsideClick: false,
                                    inputValidator: function (value) {
                                        if (value === "") {
                                            return "Please enter a comment";
                                        }
                                    },
                                    preConfirm: function (value) {
                                        $("#WorkflowActionComment").val(value);
                                        if (requiredvalidation == "false") {
                                            DisableAllField();
                                            $("#frmGeneral").submit();
                                        } else {
                                            $("#frmGeneral").submit();
                                        }
                                    }
                                });
                            }
                            else {
                                if (requiredvalidation == "false") {
                                    DisableAllField();
                                    $("#frmGeneral").submit();
                                }
                                else
                                    $("#frmGeneral").submit();
                            }
                        }
                    }
                });
            }
        }
        else {
            Swal.fire({
                title: "Email sent!",
                icon: "success",
            }).then(function (result) {
                $("#frmGeneral").submit();
                _this.attr('disabled', false);
            });
        }
    });
    //#endregion

    $("#saveAsDraftID").on("click", function (e) {
        e.preventDefault();
        $("#requiredvalidation").val("false");
        $("#WorkflowActionId").val("");
        $("#WorkflowActionName").val("");
        $("#loadermain").removeClass("hidden");
        $("#frmGeneral").submit();
    });

    $("#submitID").on("click", function (e) {
        e.preventDefault();
        var actionName = $(this).data("action");
        $("#requiredvalidation").val("true");
        $("#WorkflowActionId").val(actionName);
        $("#WorkflowActionName").val(actionName);

        if (SMLCustomValidator()) {
            var confirmText = "<span class='swal-custom-text'>Click Yes to " + actionName + " the General profile</span>";
            var requiredvalidation = "true";

            Swal.fire({
                title: "<span class='swal-custom-title'>Do you wish to proceed?</span>",
                html: confirmText,
                showCancelButton: true,
                confirmButtonColor: "#16a085",
                cancelButtonColor: "#e74c3c",
                confirmButtonText: "Yes",
                allowOutsideClick: false,
                icon: "question"
            }).then(function (result) {
                if (result.value) {
                    if (isExternal.toString() == "true" && requiredvalidation.toString() == "true") {
                        var template = $('#vendorconsent-template').html();
                    
                        Swal.fire({
                            html: template,
                            inputAttributes:
                            {
                                autocapitalize: 'off'
                            },
                            showCancelButton: true,
                            confirmButtonText: 'Accept',
                            cancelButtonText: 'Cancel',
                            showLoaderOnConfirm: true,
                            confirmButtonColor: "#16a085",
                            cancelButtonColor: "#e74c3c",
                            customClass: 'swal-wide',
                            didOpen: function () { 
                                $.ajax({
                                    url: window.ajaxUrl.getVendorConsent,
                                    type: "POST",
                                    contentType: "application/json; charset=utf-8",
                                    dataType: "json",
                                    async: false,
                                    success: function (result) {
                                        console.log(result.data)
                                        $("#consentMsg").append(result.data);
                                    }
                                });
                            },
                            allowOutsideClick: false
                        }).then(function (response) {
                            if (response.value) {
                                $("#loadermain").removeClass("hidden");
                                $("#frmGeneral").submit();
                            }
                        })
                    }
                }
            });
        }
    });

    $("#CPNewCompanyROC_ROB").on("keyup change", function (e) {
        $("#CPNewCompanyROC_ROB").val($.trim($("#CPNewCompanyROC_ROB").val()));

        if (!!!$("#CPNewCompanyROC_ROB").val())
            $("#RFVROCNoError").removeClass("d-none");
        else
            $("#RFVROCNoError").addClass("d-none");

        if ($("#CPNewCompanyROC_ROB").val().length < 6)
            $("#RFVROCNoMinLength").removeClass("d-none");
        else
            $("#RFVROCNoMinLength").addClass("d-none");

        if ($("#CPNewCompanyROC_ROB").val().length > 30)
            $("#RFVROCNoMaxLength").removeClass("d-none");
        else
            $("#RFVROCNoMaxLength").addClass("d-none");

        var validROCPattern = /^(?=.*[A-Za-z0-9])[A-Za-z0-9\/\-]{6,30}$/; //alphanumeric mandatory, dash and slash optional
        if (!validROCPattern.test($("#CPNewCompanyROC_ROB").val()))
            $("#RFVROCNoInvalid").removeClass("d-none");
        else
            $("#RFVROCNoInvalid").addClass("d-none");
    });

    $("#btnAdminUpdate").on("click", function (e) {
        e.preventDefault();

        var validROCPattern = /^(?=.*[A-Za-z0-9])[A-Za-z0-9\/\-]{6,30}$/; //alphanumeric mandatory, dash and slash optional
        if ($("#CPNewCompanyROC_ROB").val().length < 6 || $("#CPNewCompanyROC_ROB").val().length > 30 || !validROCPattern.test($("#CPNewCompanyROC_ROB").val())) {
            if ($("#CPNewCompanyROC_ROB").val().length < 6)
                $("#RFVROCNoMinLength").removeClass("d-none");
            else if ($("#CPNewCompanyROC_ROB").val().length > 30)
                $("#RFVROCNoMaxLength").removeClass("d-none");
            else
                $("#RFVROCNoInvalid").removeClass("d-none");

            Swal.fire({
                title: "<span class='swal-custom-title'>Warning!</span>",
                html: "<span class='swal-custom-text'>Invalid ROC No!</span>",
                confirmButtonColor: "#16a085",
                confirmButtonText: "OK",
                icon: "warning",
            })

            return;
        }
        if ($("#CPCompanyName").val().length == 0) {
            $("#CPCompanyNameError").removeClass("d-none");
            return;
        }

        if ($("#CompanyEmail").val().length == 0) {
            $("#VendorEmailAddrError").removeClass("d-none");
            return;
        }

        var confirmText = "<span class='swal-custom-text'>Click Yes to update the General profile</span>";

        var AdminFields = {
            rocNo: $("#CPNewCompanyROC_ROB").val(),
            vpEmailAddress: $("#CompanyEmail").val(),
            vpCompanyName: $("#CPCompanyName").val(),
            CPCreditorTINNo: $('#CPCreditorTINNo').val()
        }

        Swal.fire({
            title: "<span class='swal-custom-title'>Do you wish to proceed?</span>",
            html: confirmText,
            showCancelButton: true,
            confirmButtonColor: "#16a085",
            cancelButtonColor: "#e74c3c",
            confirmButtonText: "Yes",
            allowOutsideClick: false,
            icon: "question"
        }).then(function (result) {
            if (result.value) {
                $.ajax({
                    url: window.ajaxUrl.UpdateAdminFields,
                    type: "post",
                    data: { updateFields: AdminFields, vendorProfileID: VendorProfileId },
                    dataType: "json",
                    success: function (res) {
                        if (res.result) {
                            Swal.fire({
                                title: "<span class='swal-custom-title'>Updated Successfully</span>",
                                html: "<span class='swal-custom-text'>Profile Data updated successfully</span>",
                                confirmButtonColor: "#16a085",
                                confirmButtonText: "OK",
                                icon: "success",
                            })
                        }
                        else {
                            Swal.fire({
                                title: "<span class='swal-custom-title'>Error</span>",
                                html: "<span class='swal-custom-text'>Error: " + res.message + "</span>",
                                confirmButtonColor: "#16a085",
                                confirmButtonText: "OK",
                                icon: "error",
                            })
                        }
                    },
                    error: function (err) {
                        console.log(err);
                    }
                });
            }
        });
    });
    function DisableAllField() {
        var isAdmin = $("#isAdmin").val();
        var isMnSAdminController = $("#isMnSAdminController").val();

        if (isAdmin == "True" || isMnSAdminController == "True") {
            $("#frmGeneral").find(':input:not(:disabled)').not('.dontHide')
                .not("[aria-controls='auditTrailDatatable']")
                .not("[aria-controls='SMLApprovalList']")
                .not('.adminFields')
                .prop('disabled', true);
            $(".mustHide").addClass('hidden');
            $('.mustHide').next(".select2-container").addClass('hidden');
            $("#isFormDisabled").val(true);

            $("#frmGeneral").find(':input').not(':not(.adminFields)')
                .prop('disabled', false)
                .prop("readonly", false);
        }
        else {
            $("#frmGeneral").find(':input:not(:disabled)').not('.dontHide')
                .not("[aria-controls='auditTrailDatatable']")
                .not("[aria-controls='SMLApprovalList']")
                .prop('disabled', true);
            $(".mustHide").addClass('hidden');
            $('.mustHide').next(".select2-container").addClass('hidden');
            $("#isFormDisabled").val(true);
        }

        setInterval(function () {
            if (isAdmin == "True" || isMnSAdminController == "True") {
                $("#frmGeneral").find(':input:not(:disabled)').not('.dontHide')
                    .not("[aria-controls='auditTrailDatatable']")
                    .not("[aria-controls='SMLApprovalList']")
                    .not('.adminFields')
                    .prop('disabled', true);
                $(".mustHide").addClass('hidden');
                $('.mustHide').next(".select2-container").addClass('hidden');
                $("#isFormDisabled").val(true);

                $("#frmGeneral").find(':input').not(':not(.adminFields)')
                    .prop('disabled', false)
                    .prop("readonly", false);
            }
            else {
                $("#frmGeneral").find(':input:not(:disabled)').not('.dontHide')
                    .not("[aria-controls='auditTrailDatatable']")
                    .not("[aria-controls='SMLApprovalList']")
                    .prop('disabled', true);
                $(".mustHide").addClass('hidden');
                $('.mustHide').next(".select2-container").addClass('hidden');
                $("#isFormDisabled").val(true);
            }
        }, 1000);
    }

    $(".viewPA").on("click", function (e) {
        e.preventDefault();
        var vendorID = VendorProfileId;

        $.ajax({
            url: window.ajaxUrl.GetPendingApprovalInfo,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ referenceId: vendorID, subreferenceId: 3, moduleId: 200, moduleFlow: 2 }),
            async: false,
            success: function (response) {
                var tbody = $('#tbodyViewApprovals');
                tbody.empty();
                $.each(response, function (k, v) {
                    var tr = '<tr><td>' + response[k].ApprovalRole + '</td><td>' + response[k].ApprovalUser + '</td><td>' + response[k].Status + '</td></tr>';
                    tbody.append(tr);
                });
            },
            error: function (xhr, textStatus, errorThrown) {
                var error = $($.parseHTML(xhr.responseText)[1]).text();
                Util.alert("Alert", `Exception occurred : ${error}.`, true, function () {
                    return;
                });
            }
        });

    });

    $(".rqttoupdate").on("click", function (e) {
        e.preventDefault();
        var _this = $(this);
        _this.attr('disabled', true);

        var vendorID = VendorProfileId;
        var vendorType = $(this).data('id');

        console.log(vendorID);

        $.ajax({
            url: window.ajaxUrl.UpdateVendorProfileNSendEmail,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ VendorProfileID: vendorID, vendorProfileType: vendorType }),
            async: false,
            success: function (response) {
                Swal.fire({
                    title: "Email sent!",
                    icon: "success",
                }).then(function (result) {
                    _this.attr('disabled', false);
                });
            },
            error: function (xhr, textStatus, errorThrown) {
                var error = $($.parseHTML(xhr.responseText)[1]).text();
                Util.alert("Alert", `Exception occurred : ${error}.`, true, function () {
                    return;
                });
            }
        });


    });

    $("#VCID").select2({ width: "100%", dropdownAutoWidth: "auto" });
    $("#btnApplyVCat").on("click", function (e) {
        e.preventDefault();
        var _this = $(this);

        var val = $("#VCID option:selected").val();
        var text = $("#VCID option:selected").text();

        $("#vcatName").html(text + "&nbsp;<i class='fa fa-pencil'></i>");

        console.log(val, text);

        $.ajax({
            url: window.ajaxUrl.UpdateVendorCategory,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ VendorProfileID: VendorProfileId, VCat: val }),
            async: false,
            success: function (response) {
                Swal.fire({
                    title: "Applied",
                    icon: "success",
                    confirmButtonColor: "#16a085",
                    confirmButtonText: "OK",
                    allowOutsideClick: true,
                }).then(function (result) {
                    _this.attr('disabled', false);
                    $("#vmspopupmenu").addClass("hidden");
                });
            },
            error: function (xhr, textStatus, errorThrown) {
                var error = $($.parseHTML(xhr.responseText)[1]).text();
                Util.alert("Alert", `Exception occurred : ${error}.`, true, function () {
                    return;
                });
            }
        });
    });
});
