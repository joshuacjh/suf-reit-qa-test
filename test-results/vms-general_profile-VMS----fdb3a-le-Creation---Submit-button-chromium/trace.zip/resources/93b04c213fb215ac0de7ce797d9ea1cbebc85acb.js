$('body').on('click', '.HistoryLogTab', function () {
    AuditTrailTableInitialize();
})

$(document).ready(function () {
    $("body").on('click', '#auditTrailDatatable tr', function () {
        var VendorID = $("#VendorProfileId").val();
        var ProfileID = $("#audittrail").val();
        var ActionType = $(this).find(".changesBtn").attr('data-actiontype');
        var AuditTime = $(this).find(".changesBtn").attr('data-audittime');
       
        $.ajax({
            url: window.ajaxUrl.GetAuditTrailDetailDTTable,  
            type: "POST",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({
                vendorID: VendorID,
                profile: ProfileID,
                actionType: ActionType,
                auditTime: AuditTime   // must be in ISO 8601 format
            }),               
            success: function (response) {
                console.log(response);
                const actionNames = [...new Set(response.data.map(x => x.ActionTypeName))];
                const tabHeader = $("#auditTab");
                const tabContent = $("#auditTabContent");
                tabHeader.empty();
                tabContent.empty();

                $.each(actionNames, function (index, actionName) {
                    const tabId = "tab" + index;

                    // Create tab header
                    tabHeader.append(`<li class="nav-item">
                                <a class="nav-link ${index === 0 ? "active" : ""}" data-bs-toggle="tab" href="#${tabId}">
                                    ${actionName}
                                </a>
                            </li>
                        `);
                    // Filter data for this tab
                    const group = response.data.filter(x => x.ActionTypeName === actionName);
                    // Build table for this tab
                    let tableHtml = `
                        <table class="table table-bordered table-striped mt-3">
                            <thead>
                                <tr>
                                    <th>Field Name</th>
                                    <th>Before Value</th>
                                    <th>After Value</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;
                    $.each(group, function (i, v) {
                                    tableHtml += `<tr>
                            <td>${v.FieldName}</td>
                            <td>${v.BeforeValue}</td>
                            <td>${v.AfterValue}</td>
                        </tr>`;
                    });

                    tableHtml += `</tbody></table>`;
                    tabContent.append(`
                        <div class="tab-pane in fade ${index === 0 ? "show active" : ""}" id="${tabId}">
                            ${tableHtml}
                        </div>
                    `);
                });

                //var tbody = $('#bodyhistorylog');
                //tbody.empty();
                //$.each(response.data, function (i, v) {
                //    var tr = `<tr><td>${v.FieldName}</td><td>${v.BeforeValue}</td><td>${v.AfterValue}</td></tr>`
                //    tbody.append(tr);
                //})
            },
            error: function (xhr, status, error) {
                console.error("Error:", error);
            }
        });

        //var before_value = $(this).find(".changesBtn").data('before_value');
        //var after_value = $(this).find(".changesBtn").data('after_value');
        //var fieldname = $(this).find(".changesBtn").data('fieldname');
        //var title = $('#historylogtitle');
        //var tbody = $('#bodyhistorylog');
        //title.empty();
        //title.html("<b>" + fieldname + "</b>");
        //tbody.empty();
        //var tr = '<tr style="cursor: pointer;">' +
        //              '<td class="text-center wmswrap"><p>' + before_value + '</p></td>' +
        //              '<td class="text-center wmswrap"><p>' + after_value + '</p></td>' +
        //         '</tr>'
        //tbody.append(tr);

        //tbody.find(".AUDITAMOUNT").each(function (index, elem) {
        //    var amount = $(this).text();
        //    const value = amount.replace(/,/g, '');
        //    var amount = parseFloat(value).toLocaleString('en-US', {
        //        style: 'decimal',
        //        maximumFractionDigits: 2,
        //        minimumFractionDigits: 2
        //    });

        //    if (amount != "NaN") {
        //        $(this).html(amount);
        //    } else {
        //        var amount = parseFloat(0).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
        //        $(this).html(amount);
        //    }
        //});
        //tbody.find(".AUDITAMOUNTNODECIMAL").each(function (index, elem) {
        //    var amount = $(this).text();
        //    const value = amount.replace(/,/g, '');
        //    var amount = parseFloat(value).toLocaleString('en-US', {});
        //    if (amount != "NaN") {
        //        $(this).html(amount);
        //    } else {
        //        var amount = parseFloat(0).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
        //        $(this).html(amount);
        //    }
        //});
    });

});

var AuditTrailTable = null;

function AuditTrailTableInitialize() {
    if ($.fn.DataTable.isDataTable("#auditTrailDatatable")) {
        $("#auditTrailDatatable").DataTable().clear().destroy();
    }

    AuditTrailTable = $("#auditTrailDatatable").DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "lengthMenu": [[50, 100, 200, -1], [50, 100, 200]],
        "scrollX": true,
        "order": [[0, "desc"]],
        "ajax": {
            "url": window.ajaxUrl.GetAuditTrailDTTable,
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.vendorID = $("#VendorProfileId").val();
                d.isExternal = $("#isExternal").val();
                d.profile = $("#audittrail").val();
            },
        },
        columnDefs: [
        { className: "text-center", targets: "_all" },
        {
            targets: 0,
            data: "CreatedAt",
            render: function (data, row, type) {
                return moment(data).format("DD/MM/YYYY hh:mm:ss A");
            }
        }
        ],
        "columns": [
            { "data": "CreatedAt", "name": "Log Date" },
            //{ "data": "FieldName", "name": "Field Name" },
            //{ "data": "ActionTypeName", "name": "Actions" },
            { "data": "CreatedByName", "name": "Action Taken By" },
            {
                "data": "FieldName",
                "name": "Action Taken By",
                "visible": false
            },
            {
                "data": "BeforeValue",
                "name": "Action Taken By",
                "visible": false
            },
            {
                "data": "AfterValue",
                "name": "Action Taken By",
                "visible": false
            },
            {
                "data": "Remark",
                "name": "Remark",
                orderable: false,
                "render": function (data, type, row, meta) {
                    if (row.CreatedAt) {
                        var timestamp = parseInt(row.CreatedAt.replace(/\/Date\((\d+)\)\//, "$1"), 10);
                        var date = new Date(timestamp);

                        // format to yyyy-MM-dd HH:mm:ss.fff
                        var auditTime = date.getFullYear() + "-" +
                            ("0" + (date.getMonth() + 1)).slice(-2) + "-" +
                            ("0" + date.getDate()).slice(-2) + " " +
                            ("0" + date.getHours()).slice(-2) + ":" +
                            ("0" + date.getMinutes()).slice(-2) + ":" +
                            ("0" + date.getSeconds()).slice(-2) + "." +
                            ("00" + date.getMilliseconds()).slice(-3);
                    }
                    var result = data.split(';');
                    return "<a class='changesBtn' data-bs-toggle='modal' data-bs-target='#BeforeAfterModal' data-bs-backdrop='static' data-bs-keyboard='false'  data-actiontype='" + row.ActionType + "' data-audittime='" + auditTime + "'>Changes</a>";
                }
            },
        ]
    });

    $('#auditTrailDatatable').on('draw.dt', function () {
        AuditTrailTable.columns.adjust();
    });
}

function AuditTrailTableRefresh() {
    if (AuditTrailTable) {
        AuditTrailTable.clear();
        AuditTrailTable.ajax.reload();
        AuditTrailTable.draw();
        AuditTrailTable.columns.adjust();
    }
}