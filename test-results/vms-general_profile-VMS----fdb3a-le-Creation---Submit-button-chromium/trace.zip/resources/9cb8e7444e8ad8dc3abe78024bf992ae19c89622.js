var Util = {
    InitPartialViews: function (className) {
        $(className).each(function (i, obj) {
            var prefix = $(obj).data("prefix");
            var id = $(obj).attr("id");
            var newId = prefix + id;
            if ($(obj).attr("type") === "radio") {
                var name = $(obj).attr("name");
                $(obj).attr("name", prefix + name);
            }
            else {
                $(obj).attr("id", newId);
                $(obj).attr("name", newId);
            }
        });

        return this;
    },
    DateString: function (dt, format) {
        var date = moment(dt);
        if (!date.isValid()) return "-";

        if (format === undefined) {
            format = "DD MMM YYYY";
        }
        return date.format(format);
    },

    JSONDate: function (dateString) {
        var date = moment(dateString, "DD MMM YYYY");

        if (!date.isValid()) {
            return null;
        }

        var month = date.month();
        var day = date.date();
        var year = date.year();

        return new Date(Date.UTC(year, month, day)).toJSON();
    },

    Date: function (dateString, format) {
        if (format !== undefined)
            format = "DD/MM/YYYY HH:MM:SS";
        var date = moment(dateString, format);

        if (!date.isValid()) {
            return null;
        }

        return date.toDate();
    },

    LongDate: function (dateString) {
        let date = moment(dateString).format("DD/MM/YYYY");
        let longDate = moment(date, "DD/MM/YYYY").format("DD MMM YYYY");

        return longDate;
    },

    DateAndTime: function (dateString) {
        //let date = moment(dateString).format("DD MMM YYYY, hh:mm:ss A"); 
        let date = moment(dateString).format("DD/MM/YYYY hh:mm:ss A");
        return date;
    },

    ToDate: function (dateString, format) {
        if (!format || format === undefined)
            format = "DD/MM/YYYY";
        var date = moment(dateString).format(format);
        return date;
    },

    alert: function (title, body, isError, onSuccess, isCloseSameAction) {
        title = title || "";
        body = body || "";
        isError = isError || false;

        $("#ModalTitle").text(title);
        $("#ModalBody").html(body);

        $("#ModalBody").toggleClass("text-danger", isError);

        //$("#commonModal").modal({ backdrop: 'static', keyboard: false });
        const modalEl = document.getElementById("commonModal");
        const modal = new bootstrap.Modal(modalEl, {
            backdrop: 'static',
            keyboard: false
        });
        modal.show();

        if (typeof onSuccess === "function") {
            $("#commonModal button.btn").off('click').on('click', function (e) {
                e.preventDefault();
                onSuccess();
            });

            if (isCloseSameAction) {
                $("#commonModal button.close").off('click').on('click', function (e) {
                    e.preventDefault();
                    onSuccess();
                });
            }
        }
    },
    sweetalert: function (title, body, type) {
        Swal.fire({
            title: "<span class='swal-custom-title'>" + title + "</span>",
            html: "<span class='swal-custom-text'>" + body + "</span>",
            confirmButtonColor: "#16a085",
            confirmButtonText: "OK",
            allowOutsideClick: true,
            type: type,
            //onOpen: function (ele) {
            //    $(ele).find('span.select2.select2-container').addClass('d-none');
            //    $(ele).find('select.swal2-select').empty();
            //    $(ele).find('span.select2.select2-container').empty();

            //}
        }).then(function (result) {
        });
    },
    confirmAction: function (title, body, callback) {
        title = title || "";
        body = body || "";

        $("#confirmTitle").text(title);
        $("#confirmBody").html(body);

        //$("#confirmModal").modal("show");
        //$("#confirmModal").modal({ backdrop: 'static', keyboard: false });
        const modalEl = document.getElementById("confirmModal");
        const modal = new bootstrap.Modal(modalEl, {
            backdrop: 'static',
            keyboard: false
        });
        modal.show();

        $("#btnConfirmYes").off("click");
        $("#btnConfirmYes").on("click", function () {
            callback(true);
        });

        $("#btnConfirmNo").off("click");
        $("#btnConfirmNo").on("click", function () {
            callback(false);
        });
    },

    initFormValidator: function (formId, rulesCallback) {
        var valRules = rulesCallback.rules;
        var valMessages = rulesCallback.messages;
        $(formId).validate({
            rules: valRules,
            messages: valMessages,
            //ignore: ":hidden",
            ignore: [],
            highlight: function (element, errorClass) {
                if ($(element).siblings("span").hasClass("select2")) {
                    $(element).removeClass("error");
                    $(element).siblings("span").addClass("error");
                }
                else if ($(element).closest("span.k-widget").hasClass("k-dropdown")) {
                    $(element).removeClass("error");
                    $(element).siblings("span").addClass("error");
                }
                else {
                    $(element).addClass("error");
                }

            },
            unhighlight: function (element, errorClass) {
                if ($(element).siblings("span").hasClass("select2")) {
                    $(element).siblings("span").removeClass("error");
                }
                else if ($(element).closest("span.k-widget").hasClass("k-dropdown")) {
                    $(element).siblings("span").removeClass("error");
                }
                else {
                    $(element).removeClass("error");
                }

            },
            errorPlacement: function (error, element) {

                if ($(element).is(":radio") || $(element).data("provider") === "datepicker") {
                    $(error).insertAfter($(element).closest("div"));
                }
                else if ($(element).closest("div").hasClass("input-group")) {
                    $(error).insertAfter("div.input-group");
                }
                else if ($(element).siblings("span").hasClass("select2")) {
                    $(error).appendTo($(element).siblings(".select2-error"));
                }
                else {
                    $(error).insertAfter($(element));
                }
            },
        });
    },
    GetSingleSelectedIDFromSelect2: function (id) {
        if ($(id).select2("data").length < 1) {
            $(id).get(0).selectedIndex = 0;
            $(id).change();
        }

        return $(id).select2("data")[0].id;
    },
    GetNumber: function (value) {
        if (value == NaN || value == 'NaN' || !value || value == null || value == '') {
            return 0;
        }
        return parseFloat(value.toString().replaceAll(',', ''));
    },
    FormatNumber: function (value) {
        if (value == NaN || value == 'NaN' || !value || value == null || value == '') {
            value = 0;
        }
        return value.toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    },
    FormatNumber4d: function (value) {
        if (value == NaN || value == 'NaN' || !value || value == null || value == '') {
            return 0;
        }
        return value.toLocaleString(undefined, {
            minimumFractionDigits: 4,
            maximumFractionDigits: 4
        });
    },
    DeformatNumber: function (x) {
        if (x.toString().substring(0, 1) == '(' && x.toString().substring(x.toString().length - 1) != ')') x = x.toString().replace(/[(]/g, '');
        x = x.toString().replace(/,/g, '').replace(/[(]/g, '-').replace(/[)]/g, '');
        if (x != '-') x = parseFloat(parseFloat(x).toFixed(2));
        return x;
    },
    GetUUIDv4: function () {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    },
    Loading: function () {
        $('#DefaultLoader').show();
    },
    UnLoading: function () {
        $('#DefaultLoader').hide();
    },
    UpdateTableRowIndices: function (tableBodySelector, namePrefix, namePartsIndex, elementSelector) {
        if (!tableBodySelector || !namePrefix) {
            console.error('UpdateTableRowIndices: tableBodySelector and namePrefix are required');
            return;
        }

        namePartsIndex = namePartsIndex || 2;
        elementSelector = elementSelector || 'td > input, td > select, td > textarea';

        var i = 0;
        $(tableBodySelector + ' > tr').each(function (index, elem) {
            var _this = $(this);
            $(_this.find(elementSelector + '[name^="' + namePrefix + '"]')).each(function () {
                var inputName = $(this).attr("name");
                if (inputName) {
                    // Extract the property name (e.g., 'AttachmentID' from 'ListofITQ.ITQAttachment[0].AttachmentID')
                    var nameParts = inputName.split('.');
                    var propertyName = nameParts[namePartsIndex] || nameParts[nameParts.length - 1];

                    // Rebuild the name with new index
                    inputName = namePrefix + "[" + i + "]." + propertyName;
                    $(this).attr("name", inputName);
                }
            });
            i++;
        });
    },
};

var objectToFormData = function (obj, form, namespace) {

    var fd = form || new FormData();
    var formKey;

    for (var property in obj) {
        if (obj.hasOwnProperty(property)) {

            if (namespace) {
                formKey = namespace + '[' + property + ']';
            } else {
                formKey = property;
            }

            // if the property is an object, but not a File,
            // use recursivity.
            if (typeof obj[property] === 'object' && !(obj[property] instanceof File)) {

                //objectToFormData(obj[property], fd, property);
                objectToFormData(obj[property], fd, formKey);
            } else {

                // if it's a string or a File object
                fd.append(formKey, obj[property]);
            }

        }
    }

    return fd;

};