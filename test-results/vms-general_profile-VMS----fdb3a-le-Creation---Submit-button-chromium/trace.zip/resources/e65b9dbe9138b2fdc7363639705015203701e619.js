$(document).ready(function() {
  updateATCIndex();
  var AtcHiddenVendorID = $("#AttachTabHiddenVendorID").val();
  var AtcHiddenTabID = $("#AttachTabHiddenTabId").val();

  $(".AtcTabFileCat").each(function (i, obj) {
      if (!$(this).hasClass("addedATCSelect2")) {
          $(this).select2({
              placeholder: "Select File Category",
              width: '100%',
              dropdownAutoWidth: "auto" 
          });
          $(this).addClass("addedATCSelect2");
      }
  });

  $(".AtcTabFileCat").each(function() {
      var _this = $(this);
      var _thisoption = _this.find("option");
      $(_thisoption).each(function() {
          var _anotherthis = $(this);
          if (!!_this.attr("value")) {
              $.each(_this.attr("value").split(","), function (i, e) {
                  if (_anotherthis.val() == e)
                      _anotherthis.attr("selected", "selected");
              });
          }
      });
  }).trigger("change");



  $(".openAttachForm").click(function() {
    attachDZ.removeAllFiles(true);
    AttachFiles = [];
    AttachFilesUrl = [];
    $("#AddAttachmentTab").modal('show');
    //$("#showHideAttachForm").removeClass("d-none");
  });

  $("#saveAttachForm").click(function(e) {
    for (var i = 0; i < AttachFiles.length; i++) {
      appendDataToTable(AttachFiles[i].name, AttachFilesUrl[i].url);
    }

    //$("#showHideAttachForm").addClass("d-none");
    $("#AddAttachmentTab").modal('hide');

  });

  $("#closeAttachForm").click(function() {
    attachDZ.removeAllFiles(true);
    AttachFiles = [];
    AttachFilesUrl = [];

    //$("#showHideAttachForm").addClass("d-none");
    $("#AddAttachmentTab").modal('hide');

  });

  $("body").on("click", ".deleteAtc", function (e) {
      var thisRow = $(this).closest("tr");

      var deleteAttachmentIDs = $(`#DeletedAttachmentIDs`).val();
      var attachmentID = thisRow.find('.AtcTabAtcID').val();
      deleteAttachmentIDs += deleteAttachmentIDs !== '' ? `,${attachmentID}` : `${attachmentID}`;
      $(`#DeletedAttachmentIDs`).val(deleteAttachmentIDs);

      thisRow.remove();
      updateATCIndex();
  });

  $("body").on('click', '.vmsdownloadme', function () {
      var url = encodeURIComponent($(this).data('url'));
      var filename = encodeURIComponent($(this).data('filename'));
      $.ajax({
          url: "/manage/AttachmentParameterEncryp",
          type: "POST",
          dataType: "json",
          data: addAntiForgeryToken({ UserName: "a", ModuleID: "b", url: url, filename: filename }),
          success: function (result) {
              window.open(
                  ajaxUrl.DownloadAttachment + "?data=" + result
                );
          }
      }); 

  });

  //#region Attachment Table
  //(function($, window, document, undefined) {
  //  var pluginName = "atcEditableTable",
  //    defaults = {
  //      maintainWidth: true
  //    };

  //  $.fn[pluginName] = function(options) {
  //    return this.each(function() {
  //      if (!$.data(this, "plugin_" + pluginName)) {
  //        $.data(this, "plugin_" + pluginName, new editableKMS(this, options));
  //      }
  //    });
  //  };
  //})(jQuery, window, document);

  function appendDataToTable(filename, url) {
    var templateSource = $("#addAttachmentRow-template").html();

    var _template = Handlebars.compile(templateSource);
    var data = {
      filename: filename,
      url: url,
      AtcHiddenVendorID: AtcHiddenVendorID,
      AtcHiddenTabID: AtcHiddenTabID
    };
    var $NewRow = _template(data);

    if ($("#atcEditableTable").find("tbody tr:last").length != 0) {
      $("#atcEditableTable")
        .find("tbody tr:last")
        .after($NewRow);
    } else {
        $("#atcEditableTable")
        .find("#tbodyATC")
        .append($NewRow);
    }

    updateATCIndex();

    $(".AtcTabFileCat").each(function (i, obj) {
        if (!$(this).hasClass("addedATCSelect2")) {
            $(this).select2({ placeholder: "Select File Category", width: "100%", dropdownAutoWidth: "auto" });
            $(this).addClass("addedATCSelect2");
        }
    });

    AttachmentAutoSave();
  }
  //#endregion
});
function updateATCIndex() {
    var i = 0;
    $("#tbodyATC tr").each(function (index, elem) {
        var AtcTabAtcID = $(this).find(".AtcTabAtcID");
        var AtcTabRefNo = $(this).find(".AtcTabRefNo");
        var AtcTabURL = $(this).find(".AtcTabURL");
        var AtcTabName = $(this).find(".AtcTabName");
        var AtcTabID = $(this).find(".AtcTabID");
        var AtcUploadBy = $(this).find(".AtcUploadBy");
        var AtcTabCreatedAt = $(this).find(".AtcTabCreatedAt");
        var AtcTabFileCat = $(this).find(".AtcTabFileCat");
        var AtcTabFileCatV = $(this).find(".AtcTabFileCatV");

        var AtcTabNameLabel = $(this).find(".AtcTabNameLabel");
        var AtcTabIDLabel = $(this).find(".AtcTabIDLabel");
        var AtcUploadByLabel = $(this).find(".AtcUploadByLabel");
        var AtcTabCreatedAtLabel = $(this).find(".AtcTabCreatedAtLabel");

        if (AtcTabFileCatV) {
            AtcTabFileCatV.attr("id", "AtcTabFileCatV" + i);
        }

        if (AtcTabFileCat) {
            AtcTabFileCat.attr("id", "AtcTabFileCat" + i);
            AtcTabFileCat.attr(
              "name",
              "GeneralInfo.Attachment[" + i + "].AttachmentFileCategory"
            );
        }

        $("#AtcTabFileCat" + i).val($("#AtcTabFileCat" + i).val()).trigger("change");

        if (AtcTabAtcID) {
            AtcTabAtcID.attr("id", "AtcTabAtcID" + i);
            AtcTabAtcID.attr(
              "name",
              "GeneralInfo.Attachment[" + i + "].AttachmentID"
            );
        }

        if (AtcTabRefNo) {
            AtcTabRefNo.attr("id", "AtcTabRefNo" + i);
            AtcTabRefNo.attr(
              "name",
              "GeneralInfo.Attachment[" + i + "].AttachmentfoRefNo"
            );
        }
        if (AtcTabURL) {
            AtcTabURL.attr("id", "AtcTabURL" + i);
            AtcTabURL.attr(
              "name",
              "GeneralInfo.Attachment[" + i + "].AttachmentURL"
            );
        }
        if (AtcTabName) {
            AtcTabName.attr("id", "AtcTabName" + i);
            AtcTabName.attr(
              "name",
              "GeneralInfo.Attachment[" + i + "].AttachmentName"
            );
        }
        if (AtcTabID) {
            AtcTabID.attr("id", "AtcTabID" + i);
            AtcTabID.attr(
              "name",
              "GeneralInfo.Attachment[" + i + "].AttachmentTabID"
            );
        }
        if (AtcUploadBy) {
            AtcUploadBy.attr("id", "AtcUploadBy" + i);
            AtcUploadBy.attr("name", "GeneralInfo.Attachment[" + i + "].CreatedBy");
        }
        if (AtcTabCreatedAt) {
            AtcTabCreatedAt.attr("id", "AtcTabCreatedAt" + i);
            AtcTabCreatedAt.attr(
              "name",
              "GeneralInfo.Attachment[" + i + "].CreatedAt"
            );
        }
        if (AtcTabNameLabel) {
            AtcTabNameLabel.attr("id", "AtcTabNameLabel" + i);
        }
        if (AtcTabIDLabel) {
            AtcTabIDLabel.attr("id", "AtcTabIDLabel" + i);
        }
        if (AtcUploadByLabel) {
            AtcUploadByLabel.attr("id", "AtcUploadByLabel" + i);
        }
        if (AtcUploadByLabel) {
            AtcUploadByLabel.attr("id", "AtcUploadByLabel" + i);
        }
        if (AtcTabCreatedAtLabel) {
            AtcTabCreatedAtLabel.attr("id", "AtcTabCreatedAtLabel" + i);
        }

        i++;
    });
}