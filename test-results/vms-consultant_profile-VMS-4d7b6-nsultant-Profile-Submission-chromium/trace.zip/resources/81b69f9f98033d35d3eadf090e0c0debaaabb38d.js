$(document).ready(function () {
    var VendorProfileID = $("#VendorProfileId").val();
    var isExternal = $("#isExternal").val();
    isExternal = isExternal.toLowerCase();
    hideCSEifExternal();

    //#region On Click
    $("body").on("click", "#addItem", function (e) {
        $("#ProjectReferenceForm").removeClass("hidden");
        $("#addProjectReference").removeClass("hidden");
        $("#closeProjectRefForm").removeClass("hidden");
        ClearTheForm();
        $(this).addClass("hidden");
    });
    $("body").on("click", ".deleteProjectRef", function (e) {
        e.stopPropagation();
        var thisRow = $(this).closest("tr");
        thisRow.remove();
        updateProjectReference();
        updateCounter();
    });

    $("body").on("click", ".editProjectRef", function (e) {
        e.stopPropagation();
        $("#ProjectReferenceForm").removeClass("hidden");
        $("#addItem").addClass("hidden");
        $("#addProjectReference").removeClass("hidden");
        $("#closeProjectRefForm").removeClass("hidden");
        var _thisrow = $(this).closest("tr");
        OpenFormWithData(_thisrow, "Edit");

        $('html, body').animate({
            scrollTop: $("#ProjectReferenceForm").offset().top - 270
        }, 2000);
    });

    $("body").on("click", "#closeProjectRefForm", function (e) {
        $("#ProjectReferenceForm").addClass("hidden");
        $("#addItem").removeClass("hidden");
        $("#addProjectReference").addClass("hidden");
        $("#editProjectReference").addClass("hidden");
        $("#closeProjectRefForm").addClass("hidden");
    });

    $("body").on("click", "#addProjectReference", function (e) {
        if (isProjRefFormValid()) {
            var PRfoVendorProfileID = $("#VendorProfileId").val();
            var PRYearofAgreementReceived = $(
              "#ProjectReferenceForm .PRYearofAgreementReceived"
            ).val();
            var PRYearofDevelopmentCompleted = $(
              "#ProjectReferenceForm .PRYearofDevelopmentCompleted"
            ).val();

            var PRContractAmount = $("#ProjectReferenceForm .PRContractAmount").val();
            var PRContractAmountWithoutComma = $("#ProjectReferenceForm .PRContractAmount").val().replace(/,/g, "");

            var PRProjectComplexity = $(
              '#ProjectReferenceForm input[name="PRProjectComplexity"]:checked'
            ).val();
            var PRSunwayProject = $(
              '#ProjectReferenceForm input[name="PRSunwayProject"]:checked'
            ).val();
            var PRSunwayProjectText = PRSunwayProject == "True" ? "Yes" : "No";


            var PREmployer = $("#ProjectReferenceForm .PREmployer").val();
            var PRMainContractor = $("#ProjectReferenceForm .PRMainContractor").val();
            var totalItem = $("table > #projectReferenceBody > tr").length + 1;
            var PRProjectTitle = $("#ProjectReferenceForm  .PRProjectTitle").val();
            var PRID = $("#ProjectReferenceForm .PRID").val();
            var PRCSERef = $("#ProjectReferenceForm .PRCSERef").val() != undefined
            ? $("#ProjectReferenceForm .PRCSERef").val()
            : "";

            //#region Type of Development
            var PRTypeofDevelopment = "";
            $("#ProjectReferenceForm .PRTypeofDevelopment option:selected").each(
              function () {
                  var _this = $(this);
                  if (_this.length) {
                      PRTypeofDevelopment =
                        PRTypeofDevelopment +
                        `<tr>
                                            <td>
                                                <div style="white-space: pre-wrap;white-space: -moz-pre-wrap;white-space: -pre-wrap;white-space: -o-pre-wrap;word-wrap: break-word;min-width:200px;"> ` +
                        _this.text().toUpperCase() +
                        ` </div>
                                                <input type="hidden" class ="TypeofDevName" name="Consultant.ProjectReference[0].TypeofDevelopment[0].TypeofDevName" value= "` + _this.text() + `" >
                                                <input type="hidden" class ="TDfoSLIItemID" name="Consultant.ProjectReference[0].TypeofDevelopment[0].TDfoSLIItemID" value= "` + _this.val() + `" >

                                            </td>
                                        </tr>`;
                  }
              }
            );
            //#endregion

            //#region Work Type
            var CSTable = $("#ProjectReferenceForm .PRCSTable table tbody tr");
            var PRCS = "";
            $(CSTable).each(function () {
                var _this = $(this);
                PRCS =
                  PRCS +
                  `<tr>
                        <td>
                            <div class ="wtypename" style="white-space: pre-wrap;white-space: -moz-pre-wrap;white-space: -pre-wrap;white-space: -o-pre-wrap;word-wrap: break-word;min-width:200px;"> ` +
                  _this.find(".wtypename").html().toUpperCase() +
                  ` </div>
                            <input class ="prCSinput prCSinputid PRCSfoSLItemID" name="Consultant.ProjectReference[0].PRCSs[0].PRCSfoSLItemID"  value= '` +
                  _this.find(".prCSinputid").val() +
                  `' type="hidden" />
                            <input class ="prCSinput" name="Consultant.ProjectReference[0].PRCSs[0].PRCSfoPRID" value= '` +
                  PRID +
                  `' type="hidden" />
                        </td>
                </tr>`;
            });
            //#endregion

            //#region Location
            var PRLocation = "";
            $(".PRLocation option:selected").each(function () {
                var _this = $(this);
                if (_this.length) {
                    PRLocation =
                      PRLocation +
                      `<tr>
                        <td align="center">
                            <span> ` +
                      _this.text().toUpperCase() +
                      ` </span>
                            <input type="hidden" class ="PRLfoLocationID" name="Consultant.ProjectReference[0].PRLocation[0].PRLfoLocationID" value= "` +
                      _this.val() +
                      `" >
                        </td>
                    </tr>`;
                }
            });

            //#endregion

            if ($(".rowindex").val() != "new") {
                totalItem = totalItem - 1;
            }

            //#region New Row
            var newRow =
              `<tr>
                            <td rowspan= "1" class ="text-center actionsWidth"><span class ="prcounter">
                                `+totalItem +`
                            </span></td>
                            <td rowspan= "1">
                                `+PRYearofAgreementReceived +`
                                <input type="hidden" class ="form-control PRYearofAgreementReceived" name="Consultant.ProjectReference[0].PRYearofAgreementReceived" value= "`+PRYearofAgreementReceived +`" />
                                <input type="hidden" class ="form-control PRfoVendorProfileID" name="Consultant.ProjectReference[0].PRfoVendorProfileID" value= "` +PRfoVendorProfileID +`" />
                                <input type="hidden" class ="form-control PRID" name="Consultant.ProjectReference[0].PRID" value="`+PRID +`" />
                            </td>
                            <td rowspan= "1">
                                `+PRYearofDevelopmentCompleted+`
                                <input type="hidden" class ="form-control PRYearofDevelopmentCompleted" name="Consultant.ProjectReference[0].PRYearofDevelopmentCompleted" value="`+PRYearofDevelopmentCompleted +`" />
                            </td>
                            <td rowspan= "1">
                                <table class ="TableProjectCS" style="margin:auto">
                                    <tbody>
                                        ` +PRCS +`
                                    </tbody>
                                </table>
	                        </td>
	                         <td rowspan= "1">
                                 <table class ="prtypeofdevelopmenttable" style="margin:auto;">
                                    <tbody>
                                        `+PRTypeofDevelopment+`
                                    </tbody>
                                </table>
	                        </td>
	                        <td rowspan= "1">`+PRContractAmount+`
		                        <input type="hidden" class ="form-control PRContractAmount" name="Consultant.ProjectReference[0].PRContractAmount" value="`+PRContractAmountWithoutComma+`" />
	                        </td>
                            <td rowspan= "1">
		                        `+PRProjectComplexity.toUpperCase() +`
		                        <input type="hidden" class ="form-control PRProjectComplexity" name="Consultant.ProjectReference[0].PRProjectComplexity" value="`+PRProjectComplexity +`"/>
	                        </td>
	                        <td rowspan= "1">
		                        `+PRSunwayProjectText.toUpperCase() +`
		                        <input type="hidden" class ="form-control PRSunwayProject" name="Consultant.ProjectReference[0].PRSunwayProject" value= "`+PRSunwayProject +`" />
	                        </td>
	                        <td rowspan= "1">
		                        <div style="white-space: pre-wrap;white-space: -moz-pre-wrap;white-space: -pre-wrap;white-space: -o-pre-wrap;word-wrap: break-word;min-width:200px;"> `+$.trim(PREmployer) +` </div>
		                        <input type="hidden" class ="form-control PREmployer" name="Consultant.ProjectReference[0].PREmployer" value= "`+PREmployer.toUpperCase() +`" />
	                        </td>
	                        <td rowspan= "1">
		                        <div style="white-space: pre-wrap;white-space: -moz-pre-wrap;white-space: -pre-wrap;white-space: -o-pre-wrap;word-wrap: break-word;min-width:200px;"> `+$.trim(PRMainContractor) +` </div>
                                <input type="hidden" class ="form-control PRMainContractor" name="Consultant.ProjectReference[0].PRMainContractor" value= "`+ PRMainContractor.toUpperCase() + `" />
	                        </td>
	                          <td rowspan= "1">
                              <table class ="TableProjectofLocation" style="width:100%;">
                                    <tbody>
                                        `+ PRLocation +`
                                    </tbody>
                                </table>
	                        </td>
	                         <td rowspan= "1"><div class ="wmswrap vmsfixwidthtbl">
		                        `+PRProjectTitle.toUpperCase() +` </div>
		                        <input type="hidden" class ="form-control PRProjectTitle" name="Consultant.ProjectReference[0].PRProjectTitle" value= "`+PRProjectTitle +`" />
	                        </td>
	                        <td rowspan= "1" class ="PRCSERefIsHide">
		                        ` +PRCSERef.toUpperCase() +`
		                        <input type="hidden" class ="form-control PRCSERef" name="Consultant.ProjectReference[0].PRCSERef" value= "` +PRCSERef +`" />
	                        </td>
                           <td rowspan= "1" class ="text-center actionsWidth" style="vertical-align:middle">
                                <button type="button" class ="btn btn-sm btn-sunway editProjectRef">
                                    <i class ="fa fa-pencil"></i>
                                </button>
                            </td>
                            <td rowspan= "1" class="text-center actionsWidth" style="vertical-align:middle">
                                <button type="button" class ="btn btn-sm btn-alizarin deleteProjectRef">
                                    <i class ="fa fa-trash"></i>
                                </button>
                            </td>
                         </tr>`;
            //#endregion

            //Insert new if roindex is new or update if row index got value
            if ($(".rowindex").val() == "new") {
                $("#projectReferenceBody").append(newRow);
            } else {
                $("#projectReferenceBody > tr")
                  .eq($(".rowindex").val())
                  .replaceWith(newRow);
            }
            //Update Model index no for server side processing
            updateProjectReference();
            //Show Hide Form and button after finish action
            $("#ProjectReferenceForm").addClass("hidden");
            $("#addItem").removeClass("hidden");
            $("#addProjectReference").addClass("hidden");
            $("#closeProjectRefForm").addClass("hidden");
            ClearTheForm();
            hideCSEifExternal();
            updateCounter();
        }
    });

    $("body").on("click", "table.projrefTableList > tbody > tr", function () {
        $("#ProjectReferenceForm").removeClass("hidden");
        var _thisrow = $(this);
        OpenFormWithData(_thisrow, "View");
        $("#editProjectReference").data('this', _thisrow);

        $('html, body').animate({
            scrollTop: $("#ProjectReferenceForm").offset().top - 270
        }, 2000);
    });

    $("body").on("click", "#editProjectReference", function () {
        $("#ProjectReferenceForm").removeClass("hidden");
        var _thisrow = $(this).data('this');
        OpenFormWithData(_thisrow, "Edit");
    });
    //#endregion

    function OpenFormWithData(_thisrow, action) {
        $("#ProjectReferenceForm .PRID").val(_thisrow.find("td > .PRID").val());
        $("#ProjectReferenceForm .PRYearofAgreementReceived")
          .val(_thisrow.find("td > .PRYearofAgreementReceived").val())
          .datepicker("update");
        $("#ProjectReferenceForm .PRYearofDevelopmentCompleted").datepicker("destroy");
        $("#ProjectReferenceForm .PRYearofDevelopmentCompleted").datepicker({
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years",
            autoclose: true,
            startDate: $("#ProjectReferenceForm .PRYearofAgreementReceived").val()
        });
        $("#ProjectReferenceForm .PRYearofDevelopmentCompleted")
          .val(_thisrow.find("td > .PRYearofDevelopmentCompleted").val())
          .datepicker("update");
        $("#ProjectReferenceForm .PREmployer").val(
          _thisrow.find("td > .PREmployer").val()
        );
        $("#ProjectReferenceForm .PRMainContractor").val(
          _thisrow.find("td > .PRMainContractor").val()
        );
        
        var amount = _thisrow.find("td > .PRContractAmount").val();
        const value = amount.replace(/,/g, '');
        var amount = parseFloat(value).toLocaleString('en-US', {
            //style: 'decimal',
            //maximumFractionDigits: 2,
            //minimumFractionDigits: 2
        });

        if (amount != "NaN") {
            amount = amount;
        } else {
            var amount = 0;
            amount = amount;
        }

        $("#ProjectReferenceForm .PRContractAmount").val(
          amount
        );
        $("#ProjectReferenceForm .PRProjectTitle").val(
          _thisrow.find("td > .PRProjectTitle").val()
        );
        $("#ProjectReferenceForm .PRCSERef").val(
          _thisrow.find("td > .PRCSERef").val()
        );
        $(
          '#ProjectReferenceForm input[name="PRProjectComplexity"][value="' +
            _thisrow.find("td > .PRProjectComplexity").val() +
            '"]'
        ).prop("checked", true);


        //#region Sunway Project Radio Button
        $(
          '#ProjectReferenceForm input[name="PRSunwayProject"][value="' +
            _thisrow.find("td > .PRSunwayProject").val() +
            '"]'
        ).prop("checked", true);
        var projDev = _thisrow.find("td > .prtypeofdevelopmenttable tbody tr");
        $(projDev).each(function () {
            $(
              "#ProjectReferenceForm .PRTypeofDevelopment option[value='" +
                $(this)
                  .find(".TDfoSLIItemID")
                  .val() +
                "']"
            ).prop("selected", true);
        });
        $("#ProjectReferenceForm .PRTypeofDevelopment").trigger("change");
        //#endregion

        //#region Location
        var projLocation = _thisrow.find("td > .TableProjectofLocation tbody tr");
        $("#ProjectReferenceForm .PRLocation").val("").trigger("change");
        $(projLocation).each(function () {
            $("#ProjectReferenceForm .PRLocation option[value='" + $(this).find(".PRLfoLocationID").val() + "']").prop("selected", true);
        });
        $("#ProjectReferenceForm .PRLocation").trigger("change");
        //#endregion

        //#region TypeofDevelopment
        var typeofDev = _thisrow.find("td > .prtypeofdevelopmenttable tbody tr");
        $("#ProjectReferenceForm .PRTypeofDevelopment").val("").trigger("change");
        $(typeofDev).each(function () {
            $("#ProjectReferenceForm .PRTypeofDevelopment option[value='" + $(this).find(".TDfoSLIItemID").val() + "']").prop("selected", true);
        });
        $("#ProjectReferenceForm .PRTypeofDevelopment").trigger("change");
        //#endregion

        //#region  Work Type
        var CS = _thisrow.find("td > .TableProjectCS tbody tr");
        var CSList = "";
        $(CS).each(function () {
            var button = `<td class ="center"  style="vertical-align:middle;width: 4em;">
                <button type="button" class ="btn btn-sm btn-alizarin removeCIDBCategory">
                                    <i class="fa fa-trash"></i>
                                </button>
                </td>`;
            if (action === "View") {
                button = `<td class ="center"  style="vertical-align:middle;width: 4em;"></td>`;
            }
            CSList =
              CSList +
              `<tr><td class ="hidden"><input class ="prCSinputid" name="Consultant.ProjectReference[0].PRCSs[0].PRCSfoSLItemID"  value= '` +
              $(this)
                .find(".PRCSfoSLItemID")
                .val() +
              `' /></td><td><span class ="wtypename"> ` +
              $(this)
                .find(".wtypename")
                .html() +
              ` </span></td>` +
              button +
              `</tr>`;
        });
        $("#ProjectReferenceForm #CSBody").html(CSList);
        //#endregion

        //#region Date Picker Registering
        //Set Date picker for Site Visit
        $("#SiteVisitsbody .input-group.date input")
          .datepicker({
              todayBtn: "linked",
              autoclose: true,
              format: "dd/mm/yyyy",
              endDate: '+0d'
          })
          .on("input change", function (e) {
              var _this = $(this);
              _this
                .parent()
                .siblings(".sitevisitlabel")
                .html(e.target.value);
              $(_this).attr("value", _this.val());
          });
        //#endregion

        $(".rowindex").val(_thisrow.index());
        var isView = false;
        if (action === "View") {
            isView = true;
            $(".addSiteVisit").addClass("hidden");
            $("#addProjectReference").addClass("hidden");
            $("#addItem").addClass("hidden");
            $("#editProjectReference").removeClass("hidden");
            $("#closeProjectRefForm").removeClass("hidden");
            $(".wokrtypeDialogOpener").addClass("hidden");
        } else {
            $(".addSiteVisit").removeClass("hidden");
            $("#addItem").addClass("hidden");
            $("#editProjectReference").addClass("hidden");
            $("#addProjectReference").removeClass("hidden");
            $("#closeProjectRefForm").removeClass("hidden");
            $(".wokrtypeDialogOpener").removeClass("hidden");
        }
        $("#ProjectReferenceForm .PRYearofAgreementReceived").prop(
          "disabled",
          isView
        );
        $("#ProjectReferenceForm .PRYearofDevelopmentCompleted").prop(
          "disabled",
          isView
        );
        $("#ProjectReferenceForm .PREmployer").prop("disabled", isView);
        $("#ProjectReferenceForm .PRMainContractor").prop("disabled", isView);
        $("#ProjectReferenceForm .PRContractAmount").prop("disabled", isView);
        $("#ProjectReferenceForm .PRProjectTitle").prop("disabled", isView);
        $("#ProjectReferenceForm .PRCSERef").prop("disabled", isView);
        $('#ProjectReferenceForm input[name="PRProjectComplexity"]').prop(
          "disabled",
          isView
        );
        $('#ProjectReferenceForm input[name="PRSunwayProject"]').prop(
          "disabled",
          isView
        );
        $("#ProjectReferenceForm .PRTypeofDevelopment").prop("disabled", isView);
        $("#ProjectReferenceForm .PRLocation").prop("disabled", isView);
    }
    function ClearTheForm() {
        //#region Clear Value
        $("#ProjectReferenceForm .PRID").val("");
        $("#ProjectReferenceForm .PRYearofAgreementReceived")
          .val("")
          .datepicker("update");
        $("#ProjectReferenceForm .PRYearofDevelopmentCompleted")
          .val("")
          .datepicker("update");
        $("#ProjectReferenceForm .PREmployer").val("");
        $("#ProjectReferenceForm .PRMainContractor").val("");
        //$("#ProjectReferenceForm .PRConquasScore").val("");
        //$("#ProjectReferenceForm .PRQlassicScore").val("");
        $("#ProjectReferenceForm .PRContractAmount").val("");
        $("#ProjectReferenceForm .PRProjectTitle").val("");
        $("#ProjectReferenceForm .PRCSERef").val("");
        $(
          '#ProjectReferenceForm input[name="PRProjectComplexity"][value="Simple"]'
        ).prop("checked", true);

        $("#ProjectReferenceForm #CSBody").html("");
        $("#ProjectReferenceForm .rowindex").val("new");
        //#endregion

        //#region Enabled Form
        $("#ProjectReferenceForm .PRYearofAgreementReceived").prop(
          "disabled",
          false
        );
        $("#ProjectReferenceForm .PRYearofDevelopmentCompleted").prop(
          "disabled",
          false
        );
        $("#ProjectReferenceForm .PREmployer").prop("disabled", false);
        $("#ProjectReferenceForm .PRMainContractor").prop("disabled", false);
        //$("#ProjectReferenceForm .PRConquasScore").prop("disabled", false);
        //$("#ProjectReferenceForm .PRQlassicScore").prop("disabled", false);
        $("#ProjectReferenceForm .PRContractAmount").prop("disabled", false);
        $("#ProjectReferenceForm .PRProjectTitle").prop("disabled", false);
        $("#ProjectReferenceForm .PRCSERef").prop("disabled", false);
        $('#ProjectReferenceForm input[name="PRProjectComplexity"]').prop(
          "disabled",
          false
        );
        $('#ProjectReferenceForm input[name="PRSunwayProject"]').prop(
          "disabled",
          false
        );
        $("#ProjectReferenceForm .PRTypeofDevelopment").prop("disabled", false);
        $("#ProjectReferenceForm .PRLocation").prop("disabled", false);
        $(".addSiteVisit").removeClass("hidden");
        //$("#addProjectReference").removeClass("hidden");
        $(".wokrtypeDialogOpener").removeClass("hidden");
        $("#ProjectReferenceForm .PRTypeofDevelopment").val("").trigger("change");
        $("#ProjectReferenceForm .PRLocation").val("").trigger("change");
        //#endregion
    }
    function updateProjectReference() {
        var i = 0;
        var j = 0;
        var k = 0;
        var l = 0;
        var m = 0;
        var n = 0;
        var o = 0;
        $("#projectReferenceBody > tr").each(function (index, elem) {
            //var input = $(this).find('td[name^="Consultant.ProjectReference"]');
            $(this)
              .find("td > input[name^='Consultant.ProjectReference']")
              .each(function () {
                  var inputName = $(this).attr("name");
                  //GET THE LAST NAME OF NAME OF THE INPUT
                  if (inputName.split(".")[4] != undefined) {
                      inputName =
                        "Consultant.ProjectReference[" +
                        i +
                        "]." +
                        inputName.split(".")[2] +
                        "." +
                        inputName.split(".")[3] +
                        "." +
                        inputName.split(".")[4];
                  } else if (inputName.split(".")[3] != undefined) {
                      inputName =
                        "Consultant.ProjectReference[" +
                        i +
                        "]." +
                        inputName.split(".")[2] +
                        "." +
                        inputName.split(".")[3];
                  } else {
                      inputName =
                        "Consultant.ProjectReference[" +
                        i +
                        "]." +
                        inputName.split(".")[2];
                  }
                  $(this).attr("name", inputName);
              });

            j = 0;
            k = 0;
            l = 0;
            m = 0;
            n = 0;
            o = 0;

            var prtypeofdevelopmenttable = $(this).find(
              "table.prtypeofdevelopmenttable > tbody > tr"
            );
            $(prtypeofdevelopmenttable).each(function () {
                var _tlthis = $(this).find(".TDfoSLIItemID");
                var _tlthis2 = $(this).find(".TypeofDevName");

                $(_tlthis).each(function () {
                    var inputName = $(this).attr("name");

                    inputName =
                      "Consultant.ProjectReference[" +
                      i +
                      "].TypeofDevelopment[" +
                      n +
                      "]." +
                      inputName.split(".")[3];
                    $(this).attr("name", inputName);
                });

                $(_tlthis2).each(function () {
                    var inputName = $(this).attr("name");

                    inputName =
                      "Consultant.ProjectReference[" +
                      i +
                      "].TypeofDevelopment[" +
                      n +
                      "]." +
                      inputName.split(".")[3];
                    $(this).attr("name", inputName);
                });
                n++;
            });

            var prCStable = $(this).find("table.TableProjectCS > tbody > tr");
            $(prCStable).each(function () {
                var _tlthis = $(this).find(".prCSinput");
                $(_tlthis).each(function () {
                    var inputName = $(this).attr("name");
                    inputName =
                      "Consultant.ProjectReference[" +
                      i +
                      "].PRCSs[" +
                      l +
                      "]." +
                      inputName.split(".")[3];
                    $(this).attr("name", inputName);
                });
                l++;
            });

            var prsitevisit = $(this).find("table.prsitevisittable > tbody > tr");
            $(prsitevisit).each(function () {
                var _tlthis = $(this).find(".sitevisitinput");
                $(_tlthis).each(function () {
                    var inputName = $(this).attr("name");
                    inputName =
                      "Consultant.ProjectReference[" +
                      i +
                      "].SiteVisits[" +
                      m +
                      "]." +
                      inputName.split(".")[3];
                    $(this).attr("name", inputName);
                });
                m++;
            });

            var TableProjectofLocation = $(this).find("table.TableProjectofLocation > tbody > tr");
            $(TableProjectofLocation).each(function () {
                var _tlthis = $(this).find(".PRLfoLocationID");
                $(_tlthis).each(function () {
                    var inputName = $(this).attr("name");
                    inputName =
                      "Consultant.ProjectReference[" +
                      i +
                      "].PRLocation[" +
                      o +
                      "]." +
                      inputName.split(".")[3];
                    $(this).attr("name", inputName);
                });
                o++;
            });

            i++;
        });
    }

    //#region ConsultancyService
    $("body").on("click", "#AddCS", function (e) {
        addCS();
        isProjRefFormValid();
        $("#CSModal .close").click();
    });

    function addCS() {
        var text = "";
        var _TableBody = "#ProjectReferenceForm #CSBody";
        $('#CSBody').empty();
        var _this = $("#CS input[type=radio].check-with-label:checked");
            //if (this.checked) {
                var isSelected = false;
                var CategoryID = _this.val();
                var CategoryText = _this.attr("title");
                //$(_TableBody + " > tr").each(function (index, tr) {
                //    var cb = $(this).find(".prCSinputid");
                //    var selectedCategoryid = $(cb).val();
                //    if (CategoryID === selectedCategoryid) {
                //        isSelected = true;
                //    }
                //});

                //if (!isSelected) {
                    text = 
                      `<tr>
                                        <td class ="hidden">
                                            <input class ="prCSinputid" value= '` +
                      CategoryID +
                      `' type="hidden" />
                                        </td>
                                        <td>
                                            <span class ="wtypename"> ` +
                      CategoryText +
                      ` </span>
                                        </td>
                                        <td class ="center" style='vertical-align:middle;width: 4em;'>
                                            <button type="button" class ="btn btn-sm btn-alizarin removeCIDBCategory">
                                                <i class ="fa fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>`;
                //}
            //}

        $(_TableBody).append(text);
    }

    //when dialog is open
    $("body").on("click", ".wokrtypeDialogOpener", function (e) {
        //REFRESH SELETION WHEN REOPEN THE PAGE
        $("#CS input[type=radio]").each(function (index, tr) {
            var checbox = $(this);
            var CategoryID = $(this).val();
            var isSelected = false;
            $("#projectReference #CSBody > tr").each(function (index, tr) {
                var cb = $(this).find(".prCSinputid");
                var selectedCategoryid = $(cb).val();
                if (CategoryID == selectedCategoryid) {
                    checbox.checked = true;
                    checbox.parent().addClass("checked");
                    isSelected = true;
                }
            });

            if (!isSelected) {
                checbox.checked = false;
                checbox.prop("checked", false);
                checbox.parent().removeClass("checked");
            }
        });

        $(".mixerSearcerSingle").val("").trigger("keyup");

    });
    //#endregion

    $("body").on("click", ".removeCIDBCategory", function (e) {
        var thisRow = $(this).closest("tr");
        thisRow.remove();
    });

    //#region calender query
    //$(".yearpicker").datepicker({
    //    format: "yyyy",
    //    viewMode: "years",
    //    minViewMode: "years",
    //    autoclose: true,
    //    //endDate: '+0d'
    //});

    $("#ProjectReferenceForm .PRYearofAgreementReceived").datepicker({
        format: "yyyy",
        viewMode: "years",
        minViewMode: "years",
        autoclose: true,
        endDate: '+0d'
    });

    $("#ProjectReferenceForm .PRYearofDevelopmentCompleted").datepicker({
        format: "yyyy",
        viewMode: "years",
        minViewMode: "years",
        autoclose: true,
        //endDate: '+0d'
    });

    $(".Award_Year").datepicker({
        format: "yyyy",
        viewMode: "years",
        minViewMode: "years",
        autoclose: true,
        //endDate: '+0d'
    });

    
    //#endregion

    $("body").on("click", '.PRContractAmount, .autoHidezero', function () {
        var _this = $(this);
        const value = _this.val().replace(/,/g, '');
        if (value == "0.00" || value == "0") {
            _this.val("");
        }
    });

    $("body").on("keyup", '.PRContractAmount, .autoHidezero', function (e) {
        var code = e.keyCode || e.which;
        console.log(code);
        if (code == '9') {
            var _this = $(this);
            const value = _this.val().replace(/,/g, '');
            if (value == "0.00" || value == "0") {
                _this.val("");
            }
        }
    });

    $("body").on("blur", '.PRContractAmount', function () {
        var _this = $(this);
        const value = _this.val().replace(/,/g, '');
        var amount = parseFloat(value).toLocaleString('en-US', {
            style: 'decimal',
            maximumFractionDigits: 0,
            minimumFractionDigits: 0
        });

        if (amount != "NaN") {
            _this.val(amount);
        } else {
            var amount = 0;
            _this.val(amount);
        }


    });

    $("#projectReferenceBody tr td").each(function (index, elem) {
        var amount = $(this).find('.formatContractAmount').text();
        const value = amount.replace(/,/g, '');
        var amount = parseFloat(value).toLocaleString('en-US', {
            style: 'decimal',
            maximumFractionDigits: 0,
            minimumFractionDigits: 0
        });

        if (amount != "NaN") {
            $(this).find('.formatContractAmount').text(amount);
        } else {
            var amount = 0;
            $(this).find('.formatContractAmount').text(amount);
        }
    });

    function hideCSEifExternal() {
        if (isExternal == "true") {
            $(".PRCSERefIsHide").each(function (index, elem) {
                //$(this).remove();
                $(this).addClass('hidden');
            });
        }
    }

    function updateCounter() {
        var i = 1;
            $(".prcounter").each(function (index, elem) {
                $(this).html("<b>" + i + "</b>");
                i++;
            });
    }

    $("body").on("click", ".clickyearinput1", function (e) {
        e.preventDefault();
        e.stopPropagation();
        $("#ProjectReferenceForm .PRYearofAgreementReceived").focus();
    })

    $("body").on("click", ".clickyearinput2", function (e) {
        e.preventDefault();
        e.stopPropagation();
        $("#ProjectReferenceForm .PRYearofDevelopmentCompleted").focus();
    })

    $("body").on("click", ".datepickerbro", function (e) {
        e.preventDefault();
        e.stopPropagation();
        var input = $(this).parent().find('.yearpicker');
        console.log(input);
        input.focus();
    })

    $("body").on("change", "#ProjectReferenceForm .PRYearofAgreementReceived", function (e) {
        var selectedDate = $(this).val();
        console.log(selectedDate);
        $("#ProjectReferenceForm .PRYearofDevelopmentCompleted").datepicker("destroy");
        $("#ProjectReferenceForm .PRYearofDevelopmentCompleted").datepicker({
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years",
            autoclose: true,
            startDate: selectedDate
        });
    });

    $("body").on("click", "#projRefExport", function (e) {
        //submitting = true;
        e.preventDefault();
        $.ajax({
            url: window.ajaxUrl.ExportConsultantProjRef,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ vendorProfileId: VendorProfileID }),
            async: false,
            success: function (data) {
                window.location = window.ajaxUrl.DownloadExcelConsultantProjRef;
            },
            error: function (data) {
            }
        });
    });
});
