$(document).ready(function () {
    var VendorProfileID = $("#VendorProfileId").val();
    var CSPRTestimonialLetters = $("#CSPRTestimonialLetters").val();
    var CSPRAward = $("#CSPRAward").val();


    if (CSPRTestimonialLetters === "True") {
        $("#PRTestimonialLetters1").prop("checked", true);
        $("#TestimonialLetterTable").removeClass("hidden");
        $("#TestimonialLetterTable table").removeClass("hidden");
    } else if (CSPRTestimonialLetters === "False") {
        $("#PRTestimonialLetters2").prop("checked", true);
        $("#TestimonialLetterTable").addClass("hidden");
        $("#TestimonialLetterTable table").addClass("hidden");
        

    }

    if (CSPRAward === "True") {
        $("#PRAward1").prop("checked", true);
        $("#AwardTable").removeClass("hidden");
        $("#AwardTable table").removeClass("hidden");
    } else if (CSPRAward === "False") {
        $("#PRAward2").prop("checked", true);
        $("#AwardTable").addClass("hidden");
        $("#AwardTable table").addClass("hidden");
        
    }


    TestimonialIndex();
    AwardIndex();

    //#region Testimonial Letter
    $("input[type=radio][name='Consultant.TestimonialnAwards.PRTestimonialLetters']").change(function () {
        if (this.value === "True") {
            $("#TestimonialLetterTable").removeClass("hidden");
            $("#TestimonialLetterTable table").removeClass("hidden");
            ClearTestimonialForm();
            $("#addTestimonialLetter").click();
        }
        else if (this.value === "False") {
            $("#TestimonialLetterTable").addClass("hidden");
            $("#TestimonialLetterTable table").addClass("hidden");
            $("#TestimonialLetterBody").empty();
            $('span[errorfor="TLTable"]').addClass("d-none");
        }
    });

    $("input[type=radio][name='Consultant.TestimonialnAwards.PRTestimonialLetters']").click(function () {
        if ($("#ProjectReferenceForm").length > 0) {
            if (!$("#ProjectReferenceForm").hasClass("hidden")) {
                $("#addProjectReference").trigger("click");
                $('html, body').animate({
                    scrollTop: $("#ProjectReferenceForm").offset().top - 270
                }, 2000);
                return false;
            } else {
                return true;
            }
        }
    });

    $("body").on("click", "#SaveandAddMoreTestimonialLetter", function (e) {
        if (TLFormValid()) {
            addTestimonial();
        }
    });
    $("body").on("click", "#SaveTestimonialLetter", function (e) {
        if (TLFormValid()) {
            addTestimonial();
            $("#TestimonialLetterModal .close").click();
        }
    });
    $("body").on("click", ".removeTestimonialLetter", function (e) {
        if ($("#ProjectReferenceForm").length > 0) {
            if (!$("#ProjectReferenceForm").hasClass("hidden")) {
                $("#addProjectReference").trigger("click");
                $('html, body').animate({
                    scrollTop: $("#ProjectReferenceForm").offset().top - 270
                }, 2000);
                return false;
            } else {
                e.stopPropagation();
                var thisRow = $(this).closest("tr");
                thisRow.remove();
                TestimonialIndex();
                return true;
            }
        }
    });

    $("body").on("click", ".closeTLAW", function (e) {
        $("#tbodyTLAtc").empty();
		$("#tbodyAWAtc").empty();
    });
    
    $("body").on("click","#TestimonialLetterTable > table > tbody > tr",function (e) {
		    e.stopPropagation();
		    ClearTestimonialForm();
		    $("#addTestimonialLetter").click();
		    var _this = $(this);
		    $("#TestimonialLetterModal .Testimonial_Description").val(
				_this.find(".TLDescription").val()
			);
		    $("#TestimonialLetterModal .Testimonial_TLVendorProfileID").val(
				_this.find(".TLVendorProfileID").val()
			);
		    $("#TestimonialLetterModal .Testimonial_TLVendorProfileType").val(
               _this.find(".TLVendorProfileType").val()
           );
		    $("#TestimonialLetterModal .Testimonial_TLID").val(
				_this.find(".TLID").val()
			);
		    $(".TestimonialRow").val(_this.index());

		    var $clone = _this.find("table tbody tr").clone();
		    $clone.find(".actionstd").each(function (index, elem) {
		        $(this).removeClass('hidden');
		    });

		    $("#tbodyTLAtc").empty();
		    $("#tbodyTLAtc").append($clone);

		    TestimonialIndex();
    });

    $("body").on("click", "#addTestimonialLetter", function () {
        if ($("#ProjectReferenceForm").length > 0) {
            if (!$("#ProjectReferenceForm").hasClass("hidden")) {
                $("#addProjectReference").trigger("click");
                $('html, body').animate({
                    scrollTop: $("#ProjectReferenceForm").offset().top - 270
                }, 2000);
                return false;
            } else {
                ClearTestimonialForm();
                $(".TestimonialRow").val("new");
                return true;
            }
        }
    });
    $("body").on("click", ".removeAttachment", function (e) {
        e.stopPropagation();
        var _this = $(this);
        var _thisrow = _this.closest("tr");
        _thisrow.remove();
        $("body").on("click", ".removeAttachment", function (e) {
            e.stopPropagation();
            var _this = $(this);
            var _thisrow = _this.closest("tr");
            _thisrow.remove();
        });

        TestimonialIndex();
        AwardIndex();
    });

    $("body").on("click", "#TestimonialLetterBody a", function (e) {
        e.stopPropagation();
    });

    function addTestimonial() {
        var text = "";
        var description = $(".Testimonial_Description").val();
        var TLID = $(".Testimonial_TLID").val();
        var AttachmentList = "";
        
        var $clone = $('#tbodyTLAtc tr').clone();
        $clone.find(".actionstd").each(function (index, elem) {
            $(this).addClass('hidden');
        });


        text =
			text +
			`<tr>
                <td> ` +  description + `
                        <input type="hidden" name="Consultant.TestimonialnAwards.TestimonialLetters[0].TLDescription" class ="TLDescription" value= "` + description + `" >
                        <input type="hidden" name="Consultant.TestimonialnAwards.TestimonialLetters[0].TLVendorProfileID" class ="TLVendorProfileID" value= "` + VendorProfileID + `" >
                        <input type="hidden" name="Consultant.TestimonialnAwards.TestimonialLetters[0].TLVendorProfileType" class ="TLVendorProfileType" value= "0" >
                        <input type="hidden" name="Consultant.TestimonialnAwards.TestimonialLetters[0].TLID" class ="TLID" value= "` + TLID + `" >
                </td>
                <td>
                    <table>
                        <tbody id="TestimonialLetterAtcBody"> `+$('<tbody>').append($clone).html() +`
                        </tbody>
                    </table>
                </td>
                <td class ="center actionsWidth">
                    <button type='button' class ='btn btn-sm btn-alizarin removeTestimonialLetter'>
                        <i class ="fa fa-trash" style="font-size:20px"></i>
                    </button>
                 </td>
               </tr>`;
        if ($(".TestimonialRow").val() == "new") {
            $("#TestimonialLetterBody").append(text);
        }
        else {
            $("#TestimonialLetterBody > tr")
				.eq($(".TestimonialRow").val())
				.replaceWith(text);
        }

        ClearTestimonialForm();
        TestimonialIndex();
        $('#tbodyTLAtc').empty();
    }

    function ClearTestimonialForm() {
        ProjRefTLAttachFiles = [];
        $("#TestimonialLetterModal input").val("");
        $(".dz-preview").remove();
        $(".TestimonialRow").val("new");
    }

    $("body").on("click", ".deleteTLAtc", function (e) {
        e.stopPropagation();
        var thisRow = $(this).closest("tr");
        thisRow.remove();
        TestimonialIndex();
    });

    //#endregion

    //#region Award
    $("input[type=radio][name='Consultant.TestimonialnAwards.PRAward']").change(function () {
        if (this.value === "True") {
            $("#AwardTable").removeClass("hidden");
            $("#AwardTable table").removeClass("hidden");
            $("#addAward").click();
        }
        else if (this.value === "False") {
            $("#AwardTable").addClass("hidden");
            $("#AwardTable table").addClass("hidden");
            $("#AwardBody").empty();
            $('span[errorfor="AwardTable"]').addClass("d-none");
        }
    });

    $("input[type=radio][name='Consultant.TestimonialnAwards.PRAward']").click(function () {
        if ($("#ProjectReferenceForm").length > 0) {
            if (!$("#ProjectReferenceForm").hasClass("hidden")) {
                $("#addProjectReference").trigger("click");
                $('html, body').animate({
                    scrollTop: $("#ProjectReferenceForm").offset().top - 270
                }, 2000);
                return false;
            } else {
                return true;
            }
        }
    });

    $("body").on("click", "#SaveandAddMoreAward", function (e) {
        if (AwardFormValid()) {
            addAward();
        }
    });

    $("body").on("click", "#SaveAward", function (e) {
        if (AwardFormValid()) {
            addAward();
            $("#AwardModal .close").click();
        }
    });

    $("body").on("click", ".removeAward", function (e) {
        if ($("#ProjectReferenceForm").length > 0) {
            if (!$("#ProjectReferenceForm").hasClass("hidden")) {
                $("#addProjectReference").trigger("click");
                $('html, body').animate({
                    scrollTop: $("#ProjectReferenceForm").offset().top - 270
                }, 2000);
                return false;
            } else {
                e.stopPropagation();
                var thisRow = $(this).closest("tr");
                thisRow.remove();
                AwardIndex();
                return true;
            }
        }
    });


    $("body").on("click", "#AwardTable > table > tbody > tr", function (e) {
        e.stopPropagation();
        $("#addAward").click();
        var _this = $(this);
        $("#AwardModal .Award_Description").val(
			_this.find(".awardinput.ADescription").val()
		);
        $("#AwardModal .Award_AVendorProfileID").val(_this.find(".AVendorProfileID").val());
        $("#AwardModal .Award_AVendorProfileType").val(_this.find(".AVendorProfileType").val());
        $("#AwardModal .Award_AID").val(_this.find(".AID").val());
        $("#AwardModal .Award_Year").val(_this.find(".awardinput.AYear").val());
        $("#AwardModal .Award_Row").val(_this.index());

        var $clone = _this.find("table tbody tr").clone();
        $clone.find(".actionstd").each(function (index, elem) {
            $(this).removeClass('hidden');
        });

        $("#tbodyAWAtc").empty();
        $("#tbodyAWAtc").append($clone);

        AwardIndex();
    });
    $("body").on("click", "#addAward", function () {
        if ($("#ProjectReferenceForm").length > 0) {
            if (!$("#ProjectReferenceForm").hasClass("hidden")) {
                $("#addProjectReference").trigger("click");
                $('html, body').animate({
                    scrollTop: $("#ProjectReferenceForm").offset().top - 270
                }, 2000);
                return false;
            } else {
                ClearAwardForm();
                return true;
            }
        }
    });

    $("body").on("click", "#AwardBody a", function (e) {
        e.stopPropagation();
    });
    function addAward() {
        var text = "";
        var description = $(".Award_Description").val();
        var AID = $(".Award_AID").val();
        var year = $(".Award_Year").val();
        var AttachmentList = "";
        
        var $clone = $('#tbodyAWAtc tr').clone();
        $clone.find(".actionstd").each(function (index, elem) {
            $(this).addClass('hidden');
        });

        text =
			text +
			`<tr>
                            <td>
                                ` +
			description +
			`
                                <input type="hidden" name="Consultant.TestimonialnAwards.Awards[0].ADescription" class ="awardinput ADescription" value= "` +
			description +
			`" >
                                <input type="hidden" name="Consultant.TestimonialnAwards.Awards[0].AVendorProfileID" class ="awardinput  AVendorProfileID" value= "` +
			VendorProfileID +
			`" >
                        <input type="hidden" name="Consultant.TestimonialnAwards.Awards[0].AVendorProfileType" class ="awardinput  AVendorProfileType" value= "0" >
                                <input type="hidden" name="Consultant.TestimonialnAwards.Awards[0].AID" class ="awardinput  AID" value= "` +
			AID +
			`" >
                            </td>
                             <td>
                                ` +
			year +
			`
                                <input type="hidden" name="Consultant.TestimonialnAwards.Awards[0].AYear" class ="awardinput AYear" value= "` +
			year +
			`" >
                            </td>
                            <td>
                                <table><tbody id="AwardAtcBody"> `+$('<tbody>').append($clone).html() +` </tbody></table>
                            </td>
                            <td class ="center actionsWidth">
                                <button type='button' class ='btn btn-sm btn-alizarin removeAward'>
                        <i class ="fa fa-trash" style="font-size:20px"></i>
                    </button>
                            </td>
                         </tr>`;
        if ($(".Award_Row").val() == "new") {
            $("#AwardBody").append(text);
        }
        else {
            $("#AwardBody > tr")
				.eq($(".Award_Row").val())
				.replaceWith(text);
        }
        ClearAwardForm();
        AwardIndex();
        $('#tbodyAWAtc').empty();

    }

    function ClearAwardForm() {
        ProjRefAwardAttachFiles = [];
        $("#AwardModal input").val("");
        $(".dz-preview").remove();
        $(".Award_Row").val("new");
    }

    $("body").on("click", ".deleteAWAtc", function (e) {
        e.stopPropagation();
        var thisRow = $(this).closest("tr");
        thisRow.remove();
        AwardIndex();
    });
    //#endregion

    //#region CheckIndex

    function TestimonialIndex() {

        var i = 0;
       
        $("#TestimonialLetterBody > tr").each(function (index, elem) {
            var TLDescription = $(this).find(".TLDescription");
            if (TLDescription) {
                TLDescription.attr(
                  "name",
                  "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].TLDescription"
                );
            }

            var TLVendorProfileID = $(this).find(".TLVendorProfileID");
            if (TLVendorProfileID) {
                TLVendorProfileID.attr(
                  "name",
                  "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].TLVendorProfileID"
                );
            }

            var TLVendorProfileType = $(this).find(".TLVendorProfileType");
            if (TLVendorProfileType) {
                TLVendorProfileType.attr(
                  "name",
                  "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].TLVendorProfileType"
                );
            }

            var TLID = $(this).find(".TLID");
            if (TLID) {
                TLID.attr(
                  "name",
                  "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].TLID"
                );
            }

            var CreatedBy = $(this).find(".CreatedBy");
            if (CreatedBy) {
                CreatedBy.attr(
                  "name",
                  "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].CreatedBy"
                );
            }

            var CreatedOn = $(this).find(".CreatedOn");
            if (CreatedOn) {
                CreatedOn.attr(
                  "name",
                  "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].CreatedOn"
                );
            }

            var ModifiedBy = $(this).find(".ModifiedBy");
            if (ModifiedBy) {
                ModifiedBy.attr(
                  "name",
                  "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].ModifiedBy"
                );
            }

            var ModifiedAt = $(this).find(".ModifiedAt");
            if (ModifiedAt) {
                ModifiedAt.attr(
                  "name",
                  "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].ModifiedAt"
                );
            }
            var j = 0;
            $(this).find("#TestimonialLetterAtcBody > tr").each(function (index, elem) {
                var AttachmentID = $(this).find(".AttachmentID");
                if (AttachmentID) {
                    AttachmentID.attr(
                      "name",
                      "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].Attachment[" + j + "].AttachmentID"
                    );
                }

                var AttachmentfoRefNo = $(this).find(".AttachmentfoRefNo");
                if (AttachmentfoRefNo) {
                    AttachmentfoRefNo.attr(
                      "name",
                      "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].Attachment[" + j + "].AttachmentfoRefNo"
                    );
                }

                var AttachmentURL = $(this).find(".AttachmentURL");
                if (AttachmentURL) {
                    AttachmentURL.attr(
                      "name",
                      "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].Attachment[" + j + "].AttachmentURL"
                    );
                }

                var AttachmentName = $(this).find(".AttachmentName");
                if (AttachmentName) {
                    AttachmentName.attr(
                      "name",
                      "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].Attachment[" + j + "].AttachmentName"
                    );
                }

                var AttachmentTabID = $(this).find(".AttachmentTabID");
                if (AttachmentTabID) {
                    AttachmentTabID.attr(
                      "name",
                      "Consultant.TestimonialnAwards.TestimonialLetters[" + i + "].Attachment[" + j + "].AttachmentTabID"
                    );
                }

                j++;
            });
            i++;


        });

        
    }
    function AwardIndex() {

        var i = 0;

        $("#AwardBody > tr").each(function (index, elem) {
            var ADescription = $(this).find(".ADescription");
            if (ADescription) {
                ADescription.attr(
                  "name",
                  "Consultant.TestimonialnAwards.Awards[" + i + "].ADescription"
                );
            }

            var AVendorProfileID = $(this).find(".AVendorProfileID");
            if (AVendorProfileID) {
                AVendorProfileID.attr(
                  "name",
                  "Consultant.TestimonialnAwards.Awards[" + i + "].AVendorProfileID"
                );
            }

            var AVendorProfileType = $(this).find(".AVendorProfileType");
            if (AVendorProfileType) {
                AVendorProfileType.attr(
                  "name",
                  "Consultant.TestimonialnAwards.Awards[" + i + "].AVendorProfileType"
                );
            }

            var AID = $(this).find(".AID");
            if (AID) {
                AID.attr(
                  "name",
                  "Consultant.TestimonialnAwards.Awards[" + i + "].AID"
                );
            }

            var AYear = $(this).find(".AYear");
            if (AYear) {
                AYear.attr(
                  "name",
                  "Consultant.TestimonialnAwards.Awards[" + i + "].AYear"
                );
            }

            var CreatedBy = $(this).find(".CreatedBy");
            if (CreatedBy) {
                CreatedBy.attr(
                  "name",
                  "Consultant.TestimonialnAwards.Awards[" + i + "].CreatedBy"
                );
            }

            var CreatedOn = $(this).find(".CreatedOn");
            if (CreatedOn) {
                CreatedOn.attr(
                  "name",
                  "Consultant.TestimonialnAwards.Awards[" + i + "].CreatedOn"
                );
            }

            var ModifiedBy = $(this).find(".ModifiedBy");
            if (ModifiedBy) {
                ModifiedBy.attr(
                  "name",
                  "Consultant.TestimonialnAwards.Awards[" + i + "].ModifiedBy"
                );
            }

            var ModifiedAt = $(this).find(".ModifiedAt");
            if (ModifiedAt) {
                ModifiedAt.attr(
                  "name",
                  "Consultant.TestimonialnAwards.Awards[" + i + "].ModifiedAt"
                );
            }

            var j = 0;
            $(this).find("#AwardAtcBody > tr").each(function (index, elem) {
                var AttachmentID = $(this).find(".AttachmentID");
                if (AttachmentID) {
                    AttachmentID.attr(
                      "name",
                      "Consultant.TestimonialnAwards.Awards[" + i + "].Attachment[" + j + "].AttachmentID"
                    );
                }

                var AttachmentfoRefNo = $(this).find(".AttachmentfoRefNo");
                if (AttachmentfoRefNo) {
                    AttachmentfoRefNo.attr(
                      "name",
                      "Consultant.TestimonialnAwards.Awards[" + i + "].Attachment[" + j + "].AttachmentfoRefNo"
                    );
                }

                var AttachmentURL = $(this).find(".AttachmentURL");
                if (AttachmentURL) {
                    AttachmentURL.attr(
                      "name",
                      "Consultant.TestimonialnAwards.Awards[" + i + "].Attachment[" + j + "].AttachmentURL"
                    );
                }

                var AttachmentName = $(this).find(".AttachmentName");
                if (AttachmentName) {
                    AttachmentName.attr(
                      "name",
                      "Consultant.TestimonialnAwards.Awards[" + i + "].Attachment[" + j + "].AttachmentName"
                    );
                }

                var AttachmentTabID = $(this).find(".AttachmentTabID");
                if (AttachmentTabID) {
                    AttachmentTabID.attr(
                      "name",
                      "Consultant.TestimonialnAwards.Awards[" + i + "].Attachment[" + j + "].AttachmentTabID"
                    );
                }

                j++;
            });
            i++;


        });


    }
    //#endregion
});