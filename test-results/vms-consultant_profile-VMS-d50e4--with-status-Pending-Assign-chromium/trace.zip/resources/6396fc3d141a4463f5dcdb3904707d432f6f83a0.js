$(document).ready(function () {
    $("#select_eabmc_environment").each(function (i, obj) {
        if (!$(this).hasClass("addedSelect2")) {
            $(this).select2({ placeholder: "Select Environment", width: "100%", dropdownAutoWidth: "auto" });
            $(this).addClass("addedSelect2");
        }
    });

    $("#select_eabmc_sunway_company").each(function (i, obj) {
        if (!$(this).hasClass("addedSelect2")) {
            $(this).select2({ placeholder: "Select Sunway Company", width: "100%", dropdownAutoWidth: "auto" });
            $(this).addClass("addedSelect2");
        }
    });

    $("#SMLViewEABMCBtn").on("click", function (e) {
        setTimeout(function () {
            Environment_Dropdown();
        }, 150);
    });

    $("#Create_eABMC").on("click", function (e) {
        $('#loadermain').removeClass('hidden');
        e.preventDefault();

        setTimeout(function () {
            $.ajax({
                url: window.ajaxUrl.Create_eABMC_SupplierMaster_C,
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({
                    dto: {
                        ErpSystem: $('#input_eabmc_erp_system').val(),
                        Environment: $('#select_eabmc_environment').val(),
                        SunwayCompany: $('#select_eabmc_sunway_company').val(),
                        IndustryType: $('#input_eabmc_industry_type').val(),
                        CompanyCode: $('#input_eabmc_company_code').val(),
                        BusinessUnitCode: $('#input_eabmc_business_unit_code').val(),
                        VendorProfileID: $('#VendorProfileId').val(),
                        VendorName: $('#CPCompanyName').val(),
                        VendorProfileType: $('#SMLViewEABMCModal').attr('data-profile-type')
                    }
                }),
                async: false,
                success: function (result) {
                    var swalIcon = result.result ? 'success' : 'error';
                    var swalTitle = result.result ? 'Success!' : 'Error!';
                    var swalText = result.result ? 'EABMC synced successfully' : 'Failed to sync EABMC record';
                    Swal.fire({
                        icon: swalIcon,
                        title: swalTitle,
                        text: swalText
                    });
                },
                error: function () {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: 'Failed to sync EABMC record'
                    });
                },
                complete: function () {
                    $('#SMLViewEABMCModal').modal('hide');
                    $("#loadermain").addClass("hidden");
                }
            });
        }, 150);
    });

    $("#Update_eABMC").on("click", function (e) {
        $('#loadermain').removeClass('hidden');
        e.preventDefault();
        var typeOfChanges = $('input[name="input_eabmc_type_of_change"]:checked').map(function () { return this.value; }).get();
        if (typeOfChanges.length === 0) {
            Swal.fire({
                title: "<span class='swal-custom-title'>Warning!</span>",
                html: `<span class='swal-custom-text'>No columns selected</span>`,
                confirmButtonColor: "#16a085",
                confirmButtonText: "OK",
                icon: "warning",
            })
            return;
        }

        setTimeout(function () {
            $.ajax({
                url: window.ajaxUrl.Update_eABMC_SupplierMaster_U,
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({
                    dto: {
                        ErpSystem: $('#input_eabmc_erp_system').val(),
                        Environment: $('#select_eabmc_environment').val(),
                        SunwayCompany: $('#select_eabmc_sunway_company').val(),
                        IndustryType: $('#input_eabmc_industry_type').val(),
                        CompanyCode: $('#input_eabmc_company_code').val(),
                        BusinessUnitCode: $('#input_eabmc_business_unit_code').val(),
                        VendorProfileID: $('#VendorProfileId').val(),
                        VendorName: $('#CPCompanyName').val(),
                        VendorProfileType: $('#SMLViewEABMCModal').attr('data-profile-type'),
                        TypeOfChanges: typeOfChanges
                    }
                }),
                async: false,
                success: function (result) {
                    var swalIcon = result.result ? 'success' : 'error';
                    var swalTitle = result.result ? 'Success!' : 'Error!';
                    var swalText = result.result ? 'EABMC synced successfully' : 'Failed to sync EABMC record';
                    Swal.fire({
                        icon: swalIcon,
                        title: swalTitle,
                        text: swalText
                    });
                },
                error: function () {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: 'Failed to sync EABMC record'
                    });
                },
                complete: function () {
                    $('#SMLViewEABMCModal').modal('hide');
                    $("#loadermain").addClass("hidden");
                }
            });
        }, 150);
    });

    $("#select_eabmc_environment").on("change", function (e) {
        e.preventDefault();
        e.stopPropagation();
        $('#input_eabmc_industry_type').val('');
        $('#input_eabmc_company_code').val('');
        $('#input_eabmc_business_unit_code').val('');
        if ($(this).val() !== "") Company_Dropdown($(this).val());
    });

    $("#select_eabmc_sunway_company").change(function () {
        var selectedOption = $(this).find('option:selected');
        $('#input_eabmc_industry_type').val(selectedOption.attr('data-eabmc-industryType'));
        $('#input_eabmc_company_code').val(selectedOption.attr('data-eabmc-companyCode'));
        $('#input_eabmc_business_unit_code').val(selectedOption.attr('data-eabmc-businessUnitCode'));
        isVendorExistInEABMC();
    });

    function Environment_Dropdown() {
        $.ajax({
            url: window.ajaxUrl.getEABMCEnvironment,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                if (result.data.length > 0) {
                    $("#select_eabmc_environment").empty();
                    $("#select_eabmc_environment").html('<option value="">Select Environment</option>');
                    $.each(result.data, function (index, item) {
                        $("#select_eabmc_environment").append(
                            $("<option>", {
                                value: item,
                                text: item
                            })
                        );
                    });
                }
            }
        });
    }

    function Company_Dropdown(environment) {
        $.ajax({
            url: window.ajaxUrl.getEABMCCompany,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ environment: environment }),
            async: false,
            success: function (result) {
                if (result.data.length > 0) {
                    $('#div_eabmc_type_of_changes').addClass('hidden');
                    const checkboxes = document.querySelectorAll('input[name="input_eabmc_type_of_change"]');
                    checkboxes.forEach(function (checkbox) {
                        checkbox.checked = false;
                    });
                    $("#select_eabmc_sunway_company").empty();
                    $("#select_eabmc_sunway_company").html('<option value="">Select Sunway Company</option>');
                    $.each(result.data, function (index, item) {
                        $("#select_eabmc_sunway_company").append(
                            $("<option>", {
                                value: item.Company,
                                text: item.Company,
                                "data-eabmc-environment": item.Environment,
                                "data-eabmc-company": item.Company,
                                "data-eabmc-industryType": item.IndustryType,
                                "data-eabmc-companyCode": item.CompanyCode,
                                "data-eabmc-businessUnitCode": item.BusinessUnitCode,
                                "data-eabmc-companyGroup": item.CompanyGroup
                            })
                        );
                    });
                }
            }
        });
    }

    function isVendorExistInEABMC() {
        $('#div_eabmc_type_of_changes').addClass('hidden');

        const checkboxes = document.querySelectorAll('input[name="input_eabmc_type_of_change"]');
        checkboxes.forEach(function (checkbox) {
            checkbox.checked = false;
        });

        $.ajax({
            url: window.ajaxUrl.isVendorExistInEABMC,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({
                dto: {
                    ErpSystem: $('#input_eabmc_erp_system').val(),
                    Environment: $('#select_eabmc_environment').val(),
                    SunwayCompany: $('#select_eabmc_sunway_company').val(),
                    IndustryType: $('#input_eabmc_industry_type').val(),
                    CompanyCode: $('#input_eabmc_company_code').val(),
                    BusinessUnitCode: $('#input_eabmc_business_unit_code').val(),
                    VendorProfileID: $('#VendorProfileId').val(),
                    VendorName: $('#CPCompanyName').val(),
                    VendorProfileType: $('#SMLViewEABMCModal').attr('data-profile-type')
                }
            }),
            async: false,
            success: function (result) {
                if (!result.data) {
                    $('#Create_eABMC').removeClass('hidden');
                    $('#Update_eABMC').addClass('hidden');
                }
                else {
                    $('#Create_eABMC').addClass('hidden');
                    $('#Update_eABMC').removeClass('hidden');
                    $('#div_eabmc_type_of_changes').removeClass('hidden');
                }
            }
        })
    }

    $('#SMLViewEABMCModal').on('hidden.bs.modal', function () {
        $('#select_eabmc_environment').val(null).trigger('change');
        $('#select_eabmc_sunway_company').val(null).trigger('change');

        $('#select_eabmc_environment').empty();
        $('#select_eabmc_sunway_company').empty();

        $('#input_eabmc_industry_type').val('');
        $('#input_eabmc_company_code').val('');
        $('#input_eabmc_business_unit_code').val('');

        $('#Create_eABMC').addClass('hidden');
        $('#Update_eABMC').addClass('hidden');
        $('#div_eabmc_type_of_changes').addClass('hidden');

        const checkboxes = document.querySelectorAll('input[name="input_eabmc_type_of_change"]');
        checkboxes.forEach(function (checkbox) {
            checkbox.checked = false;
        });
    });
});