class ApprovalLog {
    _prefix = "";
    constructor(prefix) {
        this._prefix = prefix;
    }

    initApprovalLog(url, params) {
        $(`#SMLApprovalList`)
            .DataTable()
            .clear()
            .destroy();

        $(`#SMLApprovalList`).DataTable({
            "paging": true,
            "ordering": false,
            "info": false,
            "searching": false,
            "lengthChange": false,
            order: [[2, "asc"]],
            ajax: {
                url: url,
                data: params,
                type: "POST"
            },
            "aoColumns": [
                {
                    mData: "RoleName",
                    className: "dt-center wordWrap15PctBrk",
                    defaultContent: "-",
                },
                {
                    mData: "UserName",
                    className: "dt-center wordWrap15PctBrk",
                    defaultContent: "-",
                },
                {
                    mData: "CreatedAt",
                    className: "dt-center wordWrap15PctBrk",
                    defaultContent: "-",
                    render: function (data, row, type) {
                        return moment(data).format("DD/MM/YYYY hh:mm:ss A");
                    }
                },
                {
                    mData: "ActionType",
                    className: "dt-center wordWrap15PctBrk",
                    defaultContent: "-",
                },
                {
                    mData: "ApprovalRemark",
                    className: "dt-center valign-middle wordWrap40PctBrk",
                    defaultContent: "-",
                    render: function (data, type, row) {
                        var res = "-";

                        if (!!data) {
                            try {
                                res = JSON.stringify(JSON.parse(data), null, 4);
                            }
                            catch (e) {
                                res = data;
                            }
                        }

                        return "<pre>" + res + "</pre>";
                    }
                },
            ],
            initComplete: function (settings, json) {
                $("th").removeClass('sorting_asc');
            }
        });
    }
}
