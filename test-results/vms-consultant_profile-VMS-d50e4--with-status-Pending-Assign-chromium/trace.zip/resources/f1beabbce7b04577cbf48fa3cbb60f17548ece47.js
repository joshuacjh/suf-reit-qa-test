$(document).ready(function () {
    var isAllowedToAssign = $("#isAllowedToAssign").val();
    isAllowedToAssign = isAllowedToAssign.toLowerCase() == "true" ? true : false;
    var AccessGUID = $("#AccessGUID").val();

    $(".spacious-container").floatingScroll();

    //#region Select2
    $("#typeofdev").select2({ width: "100%", dropdownAutoWidth: "auto", allowClear: true, placeholder: "-SELECT-" });
    $("#worktype").select2({ width: "100%", dropdownAutoWidth: "auto", allowClear: true, placeholder: "-SELECT-" });
    $('#worktype').val(null).trigger('change');
    $("#gradeList").select2({ width: "100%", dropdownAutoWidth: "auto", allowClear: true, placeholder: "-SELECT-" });
    $('#gradeList').val(null).trigger('change');
    $("#gradeRCMDList").select2({ width: "100%", dropdownAutoWidth: "auto" });
    $('#gradeRCMDList').val(null).trigger('change');
    $("#statusList").select2({ width: "100%", dropdownAutoWidth: "auto", allowClear: true, placeholder: "-SELECT-" });
    $('#statusList').val(null).trigger('change');

    $("#typeofdev2").select2({ width: "100%", dropdownAutoWidth: "auto", allowClear: true, placeholder: "-SELECT-" });
    $("#worktype2").select2({ width: "100%", dropdownAutoWidth: "auto", allowClear: true, placeholder: "-SELECT-" });
    $('#worktype2').val(null).trigger('change');
    $("#gradeList2").select2({ width: "100%", dropdownAutoWidth: "auto", allowClear: true, placeholder: "-SELECT-" });
    $('#gradeList2').val(null).trigger('change');
    $("#gradeRCMDList2").select2({ width: "100%", dropdownAutoWidth: "auto" });
    $('#gradeRCMDList2').val(null).trigger('change');
    $("#statusList2").select2({ width: "100%", dropdownAutoWidth: "auto", allowClear: true, placeholder: "-SELECT-" });
    $('#statusList2').val(null).trigger('change');

    $("#sendInviteExistingVendorList1").each(function (i, obj) {
        if (!$(this).hasClass("addedSelect2")) {
            $(this).select2({ width: "100%", dropdownAutoWidth: "auto" });
            $(this).addClass("addedSelect2");
        }
    });

    $("#sendInviteExistingVendorList2").each(function (i, obj) {
        if (!$(this).hasClass("addedSelect2")) {
            $(this).select2({ width: "100%", dropdownAutoWidth: "auto" });
            $(this).addClass("addedSelect2");
        }
    });

    $("#sendInviteExistingVendorList3").each(function (i, obj) {
        if (!$(this).hasClass("addedSelect2")) {
            $(this).select2({ width: "100%", dropdownAutoWidth: "auto" });
            $(this).addClass("addedSelect2");
        }
    });

    $("#sendInviteExistingVendorList4").each(function (i, obj) {
        if (!$(this).hasClass("addedSelect2")) {
            $(this).select2({ width: "100%", dropdownAutoWidth: "auto" });
            $(this).addClass("addedSelect2");
        }
    });

    //#endregion

    //#region Filter Table
    $("#clearTblFilter").on("click", function () {
        $('#worktype').val(null).trigger('change');
        $('#typeofdev').val(null).trigger('change');

        $('#worktype2').val(null).trigger('change');
        $('#typeofdev2').val(null).trigger('change');

        $('#statusList').val(null).trigger('change');
        $('#statusList2').val(null).trigger('change');

        table.clear();
        table.ajax.reload();
        table.draw();
    });

    $("#clearTblFilter2").on("click", function () {
        $('#worktype2').val(null).trigger('change');
        $('#typeofdev2').val(null).trigger('change');
        $('#statusList').val(null).trigger('change');

        table2.clear();
        table2.ajax.reload();
        table2.draw();
    });

    $("#filterTbl").on("click", function () {
        table.clear();
        table.ajax.reload();
        table.draw();
    });

    $("#filterTbl2").on("click", function () {
        table2.clear();
        table2.ajax.reload();
        table2.draw();
    });
    //#endregion

    //#region Consultant Table
    var table = $("#listOfConsultantTable").DataTable({
        //dom: 'Blfrtip',
        dom: "<'row'<'col-sm-12 text-left'B>><'row'<'col-sm-6'l><'col-sm-6 text-right'f>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row dt-bottompagger'<'col-sm-5'i><'col-sm-7'p>>",
        buttons: [
            {
                extend: 'excelHtml5',
                title: 'Consultants',
                exportOptions: {
                    columns: ':visible'
                }
            },
        ],
        "processing": true,
        "serverSide": true,
        "searching": true,
        "lengthMenu": [[50, 100, 200, -1], [50, 100, 200, "All"]],
        "scrollX": true,
        "scrollCollapse": true,
        "fixedHeader": true, // optional but helps header alignment
        "oLanguage": { sProcessing: "<div id='loadermain' class=''><div id='loader'><div class='app-header__logo'><div class='logo-src-loader'></div><div role='status' class='spinner spinner-border text-danger'><span class='sr-only'></span></div></div></div></div>" },
        "ajax": {
            "url": window.ajaxUrl.GetConsultantIndexTable,
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.typeofdev = $("#typeofdev").val() != null ? $("#typeofdev").val().join(", ") : "";
                //d.worktype = $("#worktype").val();
                d.worktype = $("#worktype").val() != null ? $("#worktype").val().join(", ") : "";
                d.statusList = $("#statusList").val() != null ? $("#statusList").val().join(", ") : "";

            },
        },
        "aoColumns": [
            {
                className: 'select-checkbox excludeClick',
                targets: 0,
                visible: isAllowedToAssign,
                orderable: false,
                defaultContent: ""
            },
            {
                mData: "ExpiredIndicator",
                targets: 1,
                defaultContent: "",
                orderable: false,
                render: function (data, type, row, meta) {
                    if (data != "") {
                        return '<span style="margin-left: 5px;">' +
                                    '<i class="fa fa-exclamation-circle text-danger text-left" style="font-size:15px" data-container="body" data-html="true" data-bs-toggle="tooltip" title="' + data + '"></i>' +
                               '</span>';
                    }
                }
            },
            {
                className: "left compName",
                mData: "CompanyName",
                defaultContent: "",
                targets: 2,
            },
            {
                mData: "ROCNo",
                defaultContent: "",
                targets: 3,
            },
            {
                mData: "Location",
                defaultContent: "",
                targets: 4,
            },
            {
                mData: "PrincipleName",
                defaultContent: "",
                targets: 5,
            },
            {
                mData: "OfficeNo",
                defaultContent: "",
                targets: 6,
            },
            {
                mData: "CompanyEmail",
                defaultContent: "",
                targets: 7,
            },
            {
                mData: "PreQScore",
                defaultContent: "",
                targets: 8,
            },
            {
                mData: "Status",
                targets: 9,
                defaultContent: "",
                className: "excludeClick sipufstatus",
                render: function (data, type, row, meta) {
                    if (row.ShowPendingApproval) {
                        return '<span class="' + row.HtmlTextColorClass + ' viewPendingApprovals" style="cursor:pointer" data-bs-toggle="modal" data-bs-target="#SMLViewApprovalsModal" data-bs-backdrop="static" data-bs-keyboard="false"><u>' + row.StatusName + '</u></span>'
                    }
                    else {
                        return '<span class="' + row.HtmlTextColorClass + '">' + row.StatusName + '</span>'
                    }
                }
            },
            {
                mData: "CompanyCategory",
                defaultContent: "",
                targets: 10,
            },
            {
                mData: "isRequestedToUpdate",
                defaultContent: "",
                targets: 11,
            },
            {
                mData: "LastUpdatedAt",
                defaultContent: "",
                targets: 12,
                render: function (data, type, row, meta) {
                    if (data != null && data != '') {
                        return moment(data).format("DD/MM/YYYY hh:mm:ss A");
                    }
                }
            },
            {
                className: "key",
                mData: "WFAppKey",
                defaultContent: "",
                targets: 13,
                visible: false,
            },
            {
                className: "status",
                mData: "Status",
                defaultContent: "",
                targets: 14,
                visible: false,
                render: function (data, type, row, meta) {
                    return row.StatusName
                }
            },
            {
                className: "id",
                mData: "VendorProfileId",
                defaultContent: "",
                targets: 15,
                visible: false,
                orderable: false
            },
        ],
        "infoCallback": function (settings, start, end, max, total, pre) {
            var api = this.api();
            var pageInfo = api.page.info();

            if (total > 0)
                return 'Showing ' + start + " to " + end + ' of ' + total + ' entries';
            else
                return 'Showing 0 entries';
        },
        //"sScrollX": true,
    });

    table.on("click", "th.select-checkbox", function () {
        if ($("th.select-checkbox").hasClass("selected")) {
            table.rows().deselect();
            $("th.select-checkbox").removeClass("selected");
        } else {
            table.rows().select();
            $("th.select-checkbox").addClass("selected");
        }
    }).on("select deselect", function () {
        ("Some selection or deselection going on")
        if (table.rows({
            selected: true
        }).count() !== table.rows().count()) {
            $("th.select-checkbox").removeClass("selected");
        } else {
            $("th.select-checkbox").addClass("selected");
        }
    });
    table.on('click', 'tbody tr', function (e) {
        e.currentTarget.classList.toggle('selected');
    });
    $('#listOfConsultantTable tbody').on('click', 'tr', function (e) {
        if (!$(e.target).parents().addBack().hasClass('excludeClick')) {
            var data = table.row(this).data();
            window.location.href = "/SML/Consultant/Consultant?id=" + data.VendorProfileId + "&AccessMode=" + AccessGUID;
        }
    });

    $('#listOfConsultantTable tbody').on('click', '.viewPendingApprovals', function () {
        var data = table.row($(this).parents('tr')).data();
        getPendingApproval(data.VendorProfileId);
    });
    //#endregion

    //#region Pending Task Table
    var table2 = $("#listOfPendingTask").DataTable({
        //dom: 'Blfrtip',
        dom: "<'row'<'col-sm-12 text-left'B>><'row'<'col-sm-6'l><'col-sm-6 text-right'f>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row dt-bottompagger'<'col-sm-5'i><'col-sm-7'p>>",
        buttons: [
            {
                extend: 'excelHtml5',
                title: 'Consultants - Pending Task',
                exportOptions: {
                    columns: ':visible'
                }
            },
        ],
        "processing": true,
        "serverSide": true,
        "searching": true,
        "lengthMenu": [[50, 100, 200, -1], [50, 100, 200, "All"]],
        //"scrollX": true,
        "oLanguage": { sProcessing: "<div id='loadermain' class=''><div id='loader'><div class='app-header__logo'><div class='logo-src-loader'></div><div role='status' class='spinner spinner-border text-danger'><span class='sr-only'></span></div></div></div></div>" },
        "ajax": {
            "url": window.ajaxUrl.GetConsultantPendingTaskTable,
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.typeofdev = $("#typeofdev2").val() != null ? $("#typeofdev2").val().join(", ") : "";
                //d.worktype = $("#worktype2").val();
                d.worktype = $("#worktype2").val() != null ? $("#worktype2").val().join(", ") : "";
                d.statusList = $("#statusList2").val() != null ? $("#statusList2").val().join(", ") : "";
            },
        },
        "aoColumns": [
            {
                className: 'select-checkbox excludeClick',
                targets: 0,
                visible: isAllowedToAssign,
                orderable: false,
                defaultContent: ""
            },
            {
                mData: "ExpiredIndicator",
                targets: 1,
                defaultContent: "",
                orderable: false,
                render: function (data, type, row, meta) {
                    if (data != "") {
                        return '<span style="margin-left: 5px;">' +
                            '<i class="fa fa-exclamation-circle text-danger text-left" style="font-size:15px" data-container="body" data-html="true" data-bs-toggle="tooltip" title="' + data + '"></i>' +
                            '</span>';
                    }
                }
            },
            {
                className: "left compName",
                mData: "CompanyName",
                defaultContent: "",
                targets: 2,
            },
            {
                mData: "ROCNo",
                defaultContent: "",
                targets: 3,
            },
            {
                mData: "Location",
                defaultContent: "",
                targets: 4,
            },
            {
                mData: "PrincipleName",
                defaultContent: "",
                targets: 5,
            },
            {
                mData: "OfficeNo",
                defaultContent: "",
                targets: 6,
            },
            {
                mData: "CompanyEmail",
                defaultContent: "",
                targets: 7,
            },
            {
                mData: "PreQScore",
                defaultContent: "",
                targets: 8,
            },
            {
                mData: "Status",
                targets: 9,
                defaultContent: "",
                className: "excludeClick sipufstatus",
                render: function (data, type, row, meta) {
                    if (row.ShowPendingApproval) {
                        return '<span class="' + row.HtmlTextColorClass + ' viewPendingApprovals" style="cursor:pointer" data-bs-toggle="modal" data-bs-target="#SMLViewApprovalsModal" data-bs-backdrop="static" data-bs-keyboard="false"><u>' + row.StatusName + '</u></span>'
                    }
                    else {
                        return '<span class="' + row.HtmlTextColorClass + '">' + row.StatusName + '</span>'
                    }
                }
            },
            {
                mData: "CompanyCategory",
                defaultContent: "",
                targets: 10,
            },
            {
                mData: "isRequestedToUpdate",
                defaultContent: "",
                targets: 11,
            },
            {
                mData: "LastUpdatedAt",
                defaultContent: "",
                targets: 12,
                render: function (data, type, row, meta) {
                    if (data != null && data != '') {
                        return moment(data).format("DD/MM/YYYY hh:mm:ss A");
                    }
                }
            },
            {
                className: "key",
                mData: "WFAppKey",
                defaultContent: "",
                targets: 13,
                visible: false,
            },
            {
                className: "status",
                mData: "Status",
                defaultContent: "",
                targets: 14,
                visible: false,
                render: function (data, type, row, meta) {
                    return row.StatusName
                }
            },
            {
                className: "id",
                mData: "VendorProfileId",
                defaultContent: "",
                targets: 15,
                visible: false,
                orderable: false
            },
        ],
        select: {
            style: 'multi',
        },
        //"sScrollX": true,
    });

    table2.on("click", "th.select-checkbox", function () {
        if ($("th.select-checkbox").hasClass("selected")) {
            table2.rows().deselect();
            $("th.select-checkbox").removeClass("selected");
        } else {
            table2.rows().select();
            $("th.select-checkbox").addClass("selected");
        }
    }).on("select deselect", function () {
        ("Some selection or deselection going on")
        if (table2.rows({
            selected: true
        }).count() !== table2.rows().count()) {
            $("th.select-checkbox").removeClass("selected");
        } else {
            $("th.select-checkbox").addClass("selected");
        }
    });
    table2.on('click', 'tbody tr', function (e) {
        e.currentTarget.classList.toggle('selected');
    });
    $('#listOfPendingTask tbody').on('click', 'tr', function (e) {
        if (!$(e.target).parents().addBack().hasClass('excludeClick')) {
            var data = table2.row(this).data();
            window.location.href = "/SML/Consultant/Consultant?id=" + data.VendorProfileId + "&AccessMode=" + AccessGUID;
        }
    });

    $('#listOfPendingTask tbody').on('click', '.viewPendingApprovals', function () {
        var data = table2.row($(this).parents('tr')).data();
        getPendingApproval(data.VendorProfileId);
    });
    //#endregion

    //#region Pending Approval
    function getPendingApproval(vendorID) {
         $.ajax({
            url: window.ajaxUrl.GetPendingApprovalInfo,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ referenceId: vendorID, subreferenceId: 2, moduleId: 200, moduleFlow: 1 }),
            async: false,
            success: function (response) {
                var tbody = $('#tbodyViewApprovals');
                tbody.empty();
                $.each(response, function (k, v) {
                    var tr = '<tr><td>' + response[k].ApprovalRole + '</td><td>' + response[k].ApprovalUser + '</td><td>' + response[k].Status + '</td></tr>';
                    tbody.append(tr);
                });
            },
            error: function (xhr, textStatus, errorThrown) {
                var error = $($.parseHTML(xhr.responseText)[1]).text();
                Util.alert("Alert", `Exception occurred : ${error}.`, true, function () {
                    return;
                });
            }
        });
    }
    //#endregion

    //#region Invitation/RequestToUpdate
    var vendortype = 0;

    $('input[type=radio][name=sendInviteRadio]').change(function () {
        var selectBoxID = "sendInviteExistingVendorList";
        if (this.value == '1') {
            getExistingVendorList(`${selectBoxID}${this.value}`,3);
            vendortype = 3;
            $("#showHideSelectBox1").removeClass("hidden");
            $("#showHideSelectBox2").addClass("hidden");
            $("#showHideSelectBox3").addClass("hidden");
            $("#showHideSelectBox4").addClass("hidden");
            $("#newuserBtn").addClass("hidden");
            $("#rqtoupdateBtn").removeClass("hidden");
            $("#showHideTextBox").addClass("hidden");
            $(".sendEmailtoVendor").each(function (i, obj) {
                $(this).val("").trigger("change");
            });

        }
        else if (this.value == '2') {
            getExistingVendorList(`${selectBoxID}${this.value}`,1);
            vendortype = 1;
            $("#showHideSelectBox1").addClass("hidden");
            $("#showHideSelectBox2").removeClass("hidden");
            $("#showHideSelectBox3").addClass("hidden");
            $("#showHideSelectBox4").addClass("hidden");
            $("#newuserBtn").addClass("hidden");
            $("#rqtoupdateBtn").removeClass("hidden");
            $("#showHideTextBox").addClass("hidden");
            $(".sendEmailtoVendor").each(function (i, obj) {
                $(this).val("").trigger("change");
            });
        }
        else if (this.value == '3') {
            getExistingVendorList(`${selectBoxID}${this.value}`,2);
            vendortype = 2;
            $("#showHideSelectBox1").addClass("hidden");
            $("#showHideSelectBox2").addClass("hidden");
            $("#showHideSelectBox3").removeClass("hidden");
            $("#showHideSelectBox4").addClass("hidden");
            $("#newuserBtn").addClass("hidden");
            $("#rqtoupdateBtn").removeClass("hidden");
            $("#showHideTextBox").addClass("hidden");
            $(".sendEmailtoVendor").each(function (i, obj) {
                $(this).val("").trigger("change");
            });
        }
        else if (this.value == '4') {
            getExistingVendorList(`${selectBoxID}${this.value}`,4);
            vendortype = 4;
            $("#showHideSelectBox1").addClass("hidden");
            $("#showHideSelectBox2").addClass("hidden");
            $("#showHideSelectBox3").addClass("hidden");
            $("#showHideSelectBox4").removeClass("hidden");
            $("#newuserBtn").addClass("hidden");
            $("#rqtoupdateBtn").removeClass("hidden");
            $("#showHideTextBox").addClass("hidden");
            $(".sendEmailtoVendor").each(function (i, obj) {
                $(this).val("").trigger("change");
            });
           $("#allMS").attr("checked", false);
            $("#sendInviteExistingVendorList4").attr("disabled", false);
        }
        else if (this.value == '5') {
            vendortype = 3;
            $("#showHideSelectBox1").addClass("hidden");
            $("#showHideSelectBox2").addClass("hidden");
            $("#showHideSelectBox3").addClass("hidden");
            $("#showHideSelectBox4").addClass("hidden");
            $("#newuserBtn").removeClass("hidden");
            $("#rqtoupdateBtn").addClass("hidden");
            $("#showHideTextBox").removeClass("hidden");
            $(".sendEmailtoVendor").each(function (i, obj) {
                $(this).val("").trigger("change");
            });
        }
    });

    $("#sendEmailBtn").on("click", function () {
        var selectBoxID = "sendInviteExistingVendorList";
        $("input[name='sendInviteRadio'][value='1']").prop("checked", true).trigger("change");
        $("#showHideSelectBox1").removeClass("hidden");
        $("#showHideSelectBox2").addClass("hidden");
        $("#showHideSelectBox3").addClass("hidden");
        $("#showHideSelectBox4").addClass("hidden");
        $(".sendEmailtoVendor").each(function (i, obj) {
            $(this).val("").trigger("change");
        });

        getExistingVendorList(`${selectBoxID}${this.value}`,3);
    });

    $("#newuserBtn").on("click", function () {
        if (isSEFormValid()) {
            $(".sendEmailtoVendor").filter(':visible').each(function (i, obj) {
                if (!$(this).hasClass("hidden")) {
                    let errorMessagefield = $(this).attr('inputfor');
                    if (!$(`span[errorfor=${errorMessagefield}]`).hasClass('d-none')) {
                        return false;
                    }
                    var vendor = $(this).val();
                    $.ajax({
                        url: window.ajaxUrl.SendEmailToVendorNewUser,
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        data: JSON.stringify({ vendor, vendorType: vendortype }),
                        async: false,
                        success: function (result) {
                            Swal.fire({
                                title: "Email sent!",
                                type: "success",
                            }).then(function (result) {
                                $("#SMLSendInviteModal").modal("hide");
                            });
                        }
                    });
                }
            });
        }
    });

    $("body").on("change", "#allMS", function () {
        $(".SMLError").each(function (i, obj) {
            if (!$(this).hasClass("d-none"))
                $(this).addClass("d-none");
        });

        if ($("#sendInviteExistingVendorList4").hasClass("smlinputrequired")) {
            $("#sendInviteExistingVendorList4").removeClass("smlinputrequired");
            $("#sendInviteExistingVendorList4").closest("div").find("span.smlinputrequired").removeClass("smlinputrequired");
        }

        if (document.getElementById("allMS").checked)
            $("#sendInviteExistingVendorList4").attr("disabled", true);
        else
            $("#sendInviteExistingVendorList4").attr("disabled", false);
    })

    $("#rqtoupdateBtn").on("click", function () {
        if (document.getElementById("allMS").checked && vendortype == 4) {
            Swal.fire({
                title: "<span class='swal-custom-title'>Comment</span>",
                input: "textarea",
                inputAttributes: {
                    autocapitalize: "off",
                    id: "swal-comment"
                },
                showCancelButton: true,
                confirmButtonText: "Confirm",
                confirmButtonColor: "#16a085",
                cancelButtonColor: "#e74c3c",
                showLoaderOnConfirm: true,
                allowOutsideClick: false,
                inputValidator: function (value) {
                    if (value === "")
                        return "Please enter a comment";
                },
                preConfirm: function (value) {
                    $(".sendEmailtoVendor").filter(':visible').each(function (i, obj) {
                        if (!$(this).hasClass("hidden")) {
                            $.ajax({
                                url: window.ajaxUrl.SendEmailReqUpdate2AllVendorByType,
                                type: "POST",
                                contentType: "application/json; charset=utf-8",
                                dataType: "json",
                                data: JSON.stringify({ vendor: "all", vendorType: vendortype, comment: value }),
                                async: false,
                                success: function (result) {
                                    Swal.fire({
                                        title: "Email sent!",
                                        icon: "success",
                                    }).then(function (result) {
                                        $("#SMLSendInviteModal").modal("hide");
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
        else if (isSEFormValid()) {
            Swal.fire({
                title: "<span class='swal-custom-title'>Comment</span>",
                input: "textarea",
                inputAttributes: {
                    autocapitalize: "off",
                    id: "swal-comment"
                },
                showCancelButton: true,
                confirmButtonText: "Confirm",
                confirmButtonColor: "#16a085",
                cancelButtonColor: "#e74c3c",
                showLoaderOnConfirm: true,
                allowOutsideClick: false,
                inputValidator: function (value) {
                    if (value === "")
                        return "Please enter a comment";
                },
                preConfirm: function (value) {
                    $(".sendEmailtoVendor").filter(':visible').each(function (i, obj) {
                        if (!$(this).hasClass("hidden")) {
                            var vendor = $(this).val();
                            vendor = JSON.stringify(vendor);

                            $.ajax({
                                url: window.ajaxUrl.SendEmailToVendorReq2Update,
                                type: "POST",
                                contentType: "application/json; charset=utf-8",
                                dataType: "json",
                                data: JSON.stringify({ vendor, vendorType: vendortype, comment: value }),
                                async: false,
                                success: function (result) {
                                    Swal.fire({
                                        title: "Email sent!",
                                        icon: "success",
                                    }).then(function (result) {
                                        $("#SMLSendInviteModal").modal("hide");
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
    });

    $("#ptBtn").on("click", function () {
        $(".badge").css({ "color": "black", "background-color": "white" });
        $(this).addClass('active');
        $("#allBtn").removeClass('active');

        $("#listOfConsultantTableDiv").addClass('hidden');
        $("#listOfPendingTaskTableDiv").removeClass('hidden');

        //table2.clear();
        //table2.ajax.reload();
        //table2.draw();
        table2.columns.adjust();

    });

    $("#allBtn").on("click", function () {
        $(".badge").css({ "color": "white", "background-color": "#1976D2" });
        $(this).addClass('active');
        $("#ptBtn").removeClass('active');

        $("#listOfConsultantTableDiv").removeClass('hidden');
        $("#listOfPendingTaskTableDiv").addClass('hidden');

        table.clear();
        table.ajax.reload();
        table.draw();
        table.columns.adjust();

    });
    //#endregion

    //#region Dropdowns
    function getExistingVendorList(selectBoxID, vendortype) {
        $(`#${selectBoxID}`).select2({
            width: "100%",
            dropdownAutoWidth: "auto",
            minimumInputLength: 2,
            ajax: {
                url: window.ajaxUrl.DDgetSendInviteVendorList,
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                delay: 250,
                data: function (params) {
                    return JSON.stringify({
                        vendorType: vendortype,
                        search: params.term
                    });
                },
                processResults: function (response) {
                    return {
                        results: response.results.map(function (item) {
                            return {
                                id: item.id,
                                text: item.text
                            };
                        })
                    };
                }
            }
        });
        //$.ajax({
        //    url: window.ajaxUrl.getSendInviteVendorList,
        //    type: "POST",
        //    contentType: "application/json; charset=utf-8",
        //    dataType: "json",
        //    data: JSON.stringify({ vendorType: vendortype }),
        //    async: false,
        //    success: function (result) {
        //        $(".sendEmailtoVendor").empty();
        //        //$(".sendEmailtoVendor").html('<option value="">Select Company</option>');
        //        console.log(result.data);
        //        $.each(result.data, function (index, item) {
        //            $(".sendEmailtoVendor").append(
        //                $("<option>", {
        //                    value: item.VendorProfileID,
        //                    text: item.VendorCompanyName
        //                })
        //            );
        //        });
        //    }
        //});
    }
    //#endregion

    //#region Assigning
    var picdata = [];
    var admindata = [];
    var hodupcmdata = [];
    var pooldata = [];
    $("body").on("click", "#assignBulkBtn", function (e) {
        picdata = [];
        admindata = [];
        hodupcmdata = [];
        pooldata = [];

        compNameIndex = "";
        idIndex = "";
        keyIndex = "";
        statusIndex = "";

        if ($("#listOfConsultantTableDiv").hasClass('hidden')) {
            var data = table2.rows('.selected').data();

            compNameIndex = table2.cell('.compName').index().column;
            idIndex = table2.cell('.id').index().column;
            keyIndex = table2.cell('.key').index().column;
            statusIndex = table2.cell('.status').index().column;

        } else if ($("#listOfPendingTaskTableDiv").hasClass('hidden')) {
            var data = table.rows('.selected').data();

            compNameIndex = table.cell('.compName').index().column;
            idIndex = table.cell('.id').index().column;
            keyIndex = table.cell('.key').index().column;
            statusIndex = table.cell('.status').index().column;
        }

        if (data.length == 0) {
            confirmText = "<span class='swal-custom-text'>Please select at least one profile.</span>";
            Swal.fire({
                title: "<span class='swal-custom-title'>Oops!</span>",
                html: confirmText,
                showCancelButton: false,
                confirmButtonColor: "#16a085",
                confirmButtonText: "Okay",
                type:"error"
            }).then(function (result) {

            });
        } else {
            $("#SMLAssignModal").modal("show");

            for (var i = 0; i < data.length; i++) {
                if (data[i].WFAppKey == "HODUPCM") {
                    var obj = {
                        id: data[i].VendorProfileId,
                        compName: data[i].CompanyName.replace('&amp;', '&'),
                        key: data[i][keyIndex],
                        status: data[i].StatusName
                    };
                    hodupcmdata.push(obj);
                } else if (data[i].WFAppKey == "ADMIN") {
                    var obj = {
                        id: data[i].VendorProfileId,
                        compName: data[i].CompanyName.replace('&amp;', '&'),
                        key: data[i][keyIndex],
                        status: data[i].StatusName
                    };
                    admindata.push(obj);
                } else if (data[i].WFAppKey == "PIC") {
                    var obj = {
                        id: data[i].VendorProfileId,
                        compName: data[i].CompanyName.replace('&amp;', '&'),
                        key: data[i][keyIndex],
                        status: data[i].StatusName
                    };
                    picdata.push(obj);
                } else if (data[i].WFAppKey == "SUNWAYPOOL") {
                    var obj = {
                        id: data[i].VendorProfileId,
                        compName: data[i].CompanyName.replace('&amp;', '&'),
                        key: data[i][keyIndex],
                        status: data[i].StatusName
                    };
                    pooldata.push(obj);
                }
            }

            var tbody = $('#tbodyAssigning');
            tbody.empty();
            var templateSource = $("#assign-template").html();

            var _template = Handlebars.compile(templateSource);
            var data = {
                hodupcmdata: hodupcmdata,
                admindata: admindata,
                picdata: picdata,
                pooldata: pooldata,
                pooldatalength: pooldata.length,
                picdatalength: picdata.length,
                admindatalength: admindata.length,
                hodupcmdatalength: hodupcmdata.length,
            };

            Handlebars.registerHelper("inc", function (value, options) {
                return parseInt(value) + 2;
            });


            var $NewRow = _template(data);
            tbody.append($NewRow);
            $("#CSApprover1").select2({ placeholder: "Select PIC", width: "100%", dropdownAutoWidth: "auto" });
            $("#CSApprover2").select2({ placeholder: "Select PIC", width: "100%", dropdownAutoWidth: "auto" });
            $("#CSApprover3").select2({ placeholder: "Select Admin", width: "100%", dropdownAutoWidth: "auto" });
            $("#CSApprover4").select2({ placeholder: "Select HOD/UPCM", width: "100%", dropdownAutoWidth: "auto" });
        }


    });

    $("body").on("click", "#assignBulkBtn2", function (e) {
        if (assignBulkValid()) {
            if ($("#CSApprover1").length > 0) {
                for (var i = 0; i < pooldata.length; i++) {
                    var vendorProfileId = pooldata[i].id;
                    var vendorProfileType = 2;
                    var key = "PIC";
                    var assignee = $("#CSApprover1 option:selected").val();

                    $.ajax({
                        url: window.ajaxUrl.DoAssigning,
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        data: JSON.stringify({
                            VendorProfileId: vendorProfileId,
                            VendorProfile: vendorProfileType,
                            assignee: assignee,
                            key: key,
                        }),
                        async: false,
                        success: function (result) {
                        }
                    });
                }
            }

            if ($("#CSApprover2").length > 0) {
                for (var i = 0; i < picdata.length; i++) {
                    var vendorProfileId = picdata[i].id;
                    var vendorProfileType = 2;
                    var key = "PIC";
                    var assignee = $("#CSApprover2 option:selected").val();

                    $.ajax({
                        url: window.ajaxUrl.DoAssigning,
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        data: JSON.stringify({
                            VendorProfileId: vendorProfileId,
                            VendorProfile: vendorProfileType,
                            assignee: assignee,
                            key: key,
                        }),
                        async: false,
                        success: function (result) {
                        }
                    });
                }
            }

            if ($("#CSApprover3").length > 0) {
                for (var i = 0; i < admindata.length; i++) {
                    var vendorProfileId = admindata[i].id;
                    var vendorProfileType = 2;
                    var key = "ADMIN";
                    var assignee = $("#CSApprover3 option:selected").val();

                    $.ajax({
                        url: window.ajaxUrl.DoAssigning,
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        data: JSON.stringify({
                            VendorProfileId: vendorProfileId,
                            VendorProfile: vendorProfileType,
                            assignee: assignee,
                            key: key,
                        }),
                        async: false,
                        success: function (result) {
                        }
                    });
                }
            }

            if ($("#CSApprover4").length > 0) {
                for (var i = 0; i < hodupcmdata.length; i++) {
                    var vendorProfileId = hodupcmdata[i].id;
                    var vendorProfileType = 2;
                    var key = "HODUPCM";
                    var assignee = $("#CSApprover4 option:selected").val();

                    $.ajax({
                        url: window.ajaxUrl.DoAssigning,
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        data: JSON.stringify({
                            VendorProfileId: vendorProfileId,
                            VendorProfile: vendorProfileType,
                            assignee: assignee,
                            key: key,
                        }),
                        async: false,
                        success: function (result) {
                        }
                    });
                }
            }
            $("#SMLAssignModal").modal("hide");
            Swal.fire({
                title: "<span class='swal-custom-title'>Assigned!</span>",
                confirmButtonColor: "#16a085",
                confirmButtonText: "OK",
                type: "success",
            }).then(function (result) {
                location.reload();
            });
        }
    });
    //#endregion
});



//var table = $(`#listOfConsultantTable`).DataTable({
//    "searching": true,
//    "ordering": true,
//    "lengthMenu": [[50, 100, 200, -1], [50, 100, 200]],
//    "aaSorting": [],
//    columnDefs: [
//     {
//         className: 'select-checkbox excludeClick',
//         targets: 2,
//         visible: isAllowedToAssign,
//         orderable: false
//     }],
//    select: {
//        style: 'multi',
//    }
//});

//table.on("click", "th.select-checkbox", function () {
//    if ($("th.select-checkbox").hasClass("selected")) {
//        table.rows().deselect();
//        $("th.select-checkbox").removeClass("selected");
//    } else {
//        table.rows().select();
//        $("th.select-checkbox").addClass("selected");
//    }
//}).on("select deselect", function () {
//    ("Some selection or deselection going on")
//    if (table.rows({
//        selected: true
//    }).count() !== table.rows().count()) {
//        $("th.select-checkbox").removeClass("selected");
//    } else {
//        $("th.select-checkbox").addClass("selected");
//    }
//});

//var table2 = $(`#listOfPendingTask`).DataTable({
//    "searching": true,
//    "ordering": true,
//    "lengthMenu": [[50, 100, 200, -1], [50, 100, 200]],
//    "aaSorting": [],
//    columnDefs: [
//     {
//         className: 'select-checkbox excludeClick',
//         targets: 2,
//         visible: isAllowedToAssign,
//         orderable: false
//     }],
//    select: {
//        style: 'multi',
//    }
//});

//table2.on("click", "th.select-checkbox", function () {
//    if ($("th.select-checkbox").hasClass("selected")) {
//        table2.rows().deselect();
//        $("th.select-checkbox").removeClass("selected");
//    } else {
//        table2.rows().select();
//        $("th.select-checkbox").addClass("selected");
//    }
//}).on("select deselect", function () {
//    ("Some selection or deselection going on")
//    if (table2.rows({
//        selected: true
//    }).count() !== table2.rows().count()) {
//        $("th.select-checkbox").removeClass("selected");
//    } else {
//        $("th.select-checkbox").addClass("selected");
//    }
//});

//$('#listOfConsultantTable tbody').on('click', 'tr', function (e) {
//    if (!$(e.target).parents().addBack().hasClass('excludeClick')) {
//        var data = table.row(this).data();
//        window.location.href = "/SML/Consultant/Consultant?id=" + data[0] + "&AccessMode=" + data[1];
//    }
//});

//$('#listOfPendingTask tbody').on('click', 'tr', function (e) {
//    if (!$(e.target).parents().addBack().hasClass('excludeClick')) {
//        var data = table2.row(this).data();
//        window.location.href = "/SML/Consultant/Consultant?id=" + data[0] + "&AccessMode=" + data[1];
//    }
//});

//$('#listOfConsultantTable tbody').on('click', '.viewPendingApprovals', function () {
//    var thisRow = $(this).closest("tr");
//    var vendorID = thisRow.find('input[name="ctVendorProfileID"]').val();
//    getPendingApproval(vendorID);
//});

//$('#listOfPendingTask tbody').on('click', '.viewPendingApprovals', function () {
//    var thisRow = $(this).closest("tr");
//    var vendorID = thisRow.find('input[name="ctVendorProfileID"]').val();
//    getPendingApproval(vendorID);
//});
