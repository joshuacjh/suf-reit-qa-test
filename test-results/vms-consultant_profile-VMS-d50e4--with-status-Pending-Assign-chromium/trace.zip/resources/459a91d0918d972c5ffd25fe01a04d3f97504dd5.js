//#region ButtonAction
$(document).ready(function () {
    $("#frmContractor, #frmConsultant, #frmGeneral, #frmMarketingSupplier, #frmIndividual").submit(function (e) {
        window.removeEventListener("beforeunload", function (e) {});

        $(".SMLError").addClass("d-none");
        $(".vmstabhigherror").addClass("hidden");
        $('.smlinputrequired').each(function () {
            $(this).removeClass('smlinputrequired');
        });

        $(this).find('input[type="submit"]').attr('disabled', true);
        let requiredvalidation = $("#requiredvalidation").val();

        openEditableTableInput();
        updateAddCompanyIndex();
        updateAddDirectorIndex();
        updateAddShareHolderIndex();
        updateKMSIndex();
        updateTechComptenciesIndex();
        updateGradeIndex();
        ProfIndemnityAmountRemoveComma();
        KMSPhoneCodeUpdate();
        
        if (requiredvalidation == "true") {
            ProfIndemnityAmountCheck();
            ProjectQualityPlanCheckboxesMin();
            let ret1 = isSMLFormValid();
            let ret2 = isRAModalValid();
            let ret3 = isCAModalValid();
            let ret4 = checkPrincipleInactive();
            let ret5 = BankDetailsValid();
            let ret6 = isTLandAwardTableValid();
            let ret7 = checkPrincipleExist();
            let ret8 = CheckROCROBTable();
            let ret9 = ProjectQualityPlanCheckboxesMin();
            let ret10 = ProfIndemValid();
            let ret11 = ISOValid();
            let ret12 = isProjRefFormValid();
            let ret13 = checkProjRefTable();
            let ret14 = KMSTechCompCheck();
            let ret15 = isProjRefFormIsOpen();

            if (!!$("#frmMarketingSupplier").html()) {
                if (ret1 && ret12 && ret13 && ret15) {
                    $("#frmMarketingSupplier").find(':input:disabled').prop('disabled', false);
                    return true;
                }
                else if ($("#projRefTable tbody tr").length == 0) {
                    Swal.fire({
                        title: "<span class='swal-custom-title'>Warning</span>",
                        html: "<span class='swal-custom-text'>Please add at least one Project Reference. Thank you.</span>",
                        confirmButtonColor: "#16a085",
                        confirmButtonText: "OK",
                        icon: "warning",
                    })
                    return false;
                }
                else {
                    Swal.fire({
                        title: "<span class='swal-custom-title'>Oops</span>",
                        html: "<span class='swal-custom-text'>Please key in all required fields. Thank you.</span>",
                        confirmButtonColor: "#16a085",
                        confirmButtonText: "OK",
                        icon: "warning",
                    })
                    return false;
                }
            }
            else {
                if (ret1 && ret2 && ret3 && ret4 && ret5 && ret6 && ret7 && ret8 && ret9 && ret10 && ret11 && ret12 && ret13 && ret14 && ret15) {
                    $("#frmContractor, #frmConsultant, #frmGeneral").find(':input:disabled').prop('disabled', false);
                    return true;
                }
                else {
                    Swal.fire({
                        title: "<span class='swal-custom-title'>Oops</span>",
                        html: "<span class='swal-custom-text'>Please key in all required fields. Thank you.</span>",
                        confirmButtonColor: "#16a085",
                        confirmButtonText: "OK",
                        icon: "warning",
                    })
                    return false;
                }
            }
        }
        else {
            let ret1 = isProjRefFormIsOpen();
            if (ret1) {
                $("#frmContractor, #frmConsultant, #frmGeneral, #frmMarketingSupplier").find(':input:disabled').prop('disabled', false);
                return true;
            }
            else
                return false;
        }
    });
});

function IndividualCustomValidator() {
    $(".SMLError").addClass("d-none");
    $(".vmstabhigherror").addClass("hidden");
    $('.smlinputrequired').each(function () {
        $(this).removeClass('smlinputrequired');
    });
    
    if ($("#requiredvalidation").val() == "true") {
        let ret1 = isSMLFormValid();
        let ret2 = isRAModalValid();
        let ret3 = isCAModalValid();
        let ret4 = BankDetailsValid();
        let ret5 = ExistIndividualNRIC();

        if (ret1 && ret2 && ret3 && ret4 && ret5) {
            $("#frmIndividual").find(':input:disabled').prop('disabled', false);
            return true;
        }
        //ret5 already shows an warning message, bottom ELSEIF check used to not have it override the other warning message instead of just ELSE
        else if (ret5) {
            Swal.fire({
                title: "<span class='swal-custom-title'>Oops</span>",
                html: "<span class='swal-custom-text'>Please key in all required fields. Thank you.</span>",
                confirmButtonColor: "#16a085",
                confirmButtonText: "OK",
                icon: "warning",
            })
            return false;
        }
    }
    else {
        if (isProjRefFormIsOpen()) {
            $("#frmIndividual").find(':input:disabled').prop('disabled', false);
            return true;
        }
        else
            return false;
    }
}

function SMLCustomValidator() {
    $(".SMLError").addClass("d-none");
    $(".vmstabhigherror").addClass("hidden");
    $('.smlinputrequired').each(function () {
        $(this).removeClass('smlinputrequired');
    });

    let requiredvalidation = $("#requiredvalidation").val();

    openEditableTableInput();
    updateAddCompanyIndex();
    updateAddDirectorIndex();
    updateAddShareHolderIndex();
    updateKMSIndex();
    updateTechComptenciesIndex();
    updateGradeIndex();
    ProfIndemnityAmountRemoveComma();
    KMSPhoneCodeUpdate();
    checkProjRefTable();

    if (requiredvalidation == "true") {
        ProfIndemnityAmountCheck();
        ProjectQualityPlanCheckboxesMin();

        let ret1 = isSMLFormValid();
        let ret2 = isRAModalValid();
        let ret3 = isCAModalValid();
        let ret4 = checkPrincipleInactive();
        let ret5 = BankDetailsValid();
        let ret6 = isTLandAwardTableValid();
        let ret7 = checkPrincipleExist();
        let ret8 = CheckROCROBTable();
        let ret9 = ProjectQualityPlanCheckboxesMin();
        let ret10 = ProfIndemValid();
        let ret11 = ISOValid();
        let ret12 = isProjRefFormValid();
        let ret13 = checkProjRefTable();
        let ret14 = KMSTechCompCheck();
        let ret15 = isProjRefFormIsOpen();

        if (!!$("#frmMarketingSupplier").html()) {
            if (ret1 && ret12 && ret13 && ret15) {
                $("#frmMarketingSupplier").find(':input:disabled').prop('disabled', false);
                return true;
            }
            else if ($("#projRefTable tbody tr").length == 0) {
                Swal.fire({
                    title: "<span class='swal-custom-title'>Warning</span>",
                    html: "<span class='swal-custom-text'>Please add at least one Project Reference. Thank you.</span>",
                    confirmButtonColor: "#16a085",
                    confirmButtonText: "OK",
                    icon: "warning",
                })
                return false;
            }
            else {
                Swal.fire({
                    title: "<span class='swal-custom-title'>Oops</span>",
                    html: "<span class='swal-custom-text'>Please key in all required fields. Thank you.</span>",
                    confirmButtonColor: "#16a085",
                    confirmButtonText: "OK",
                    icon: "warning",
                })
                return false;
            }
        }
        else {
            if (ret1 && ret2 && ret3 && ret4 && ret5 && ret6 && ret7 && ret8 && ret9 && ret10 & ret11 && ret12 && ret13 && ret14 && ret15) {
                $("#frmContractor, #frmConsultant, #frmGeneral").find(':input:disabled').prop('disabled', false);
                return true;
            }
            else if (!ret14) {
                Swal.fire({
                    title: "<span class='swal-custom-title'>Oops</span>",
                    html: "<span class='swal-custom-text'>The total records of Key Management and Staff are not aligned with the total records of Technical Competencies / Please key in all required fields. Thank you.</span>",
                    confirmButtonColor: "#16a085",
                    confirmButtonText: "OK",
                    icon: "warning",
                })
                return false;
            }
            else {
                Swal.fire({
                    title: "<span class='swal-custom-title'>Oops</span>",
                    html: "<span class='swal-custom-text'>Please key in all required fields. Thank you.</span>",
                    confirmButtonColor: "#16a085",
                    confirmButtonText: "OK",
                    icon: "warning",
                })
                return false;
            }
        }
    }
    else {
        let ret1 = isProjRefFormIsOpen();
        if (ret1) {
            $("#frmContractor, #frmConsultant, #frmGeneral, #frmMarketingSupplier").find(':input:disabled').prop('disabled', false);
            return true;
        }
        else
            return false;
    }
}

function ReCheckValidation() {
    $(".SMLError").addClass("d-none");
    $(".vmstabhigherror").addClass("hidden");
    $('.smlinputrequired').each(function () {
        $(this).removeClass('smlinputrequired');
    });

    ProjectQualityPlanCheckboxesMin();
    isSMLFormValid();
    isRAModalValid();
    isCAModalValid();
    checkPrincipleInactive();
    BankDetailsValid();
    isTLandAwardTableValid();
    checkPrincipleExist();
    CheckROCROBTable();
    ProjectQualityPlanCheckboxesMin();
    ProfIndemValid();
    ISOValid();
    ProfIndemnityAmountRemoveComma();
    checkProjRefTable();
}
//#endregion

//#region General
$(function () {
    $(".CPDNewIDNo").mask("000000-00-0000", { reverse: false, clearIfNotMatch: true, placeholder: "000000-00-0000" });
    $(".CPSHNewIDNo").mask("000000-00-0000", { reverse: false, clearIfNotMatch: true, placeholder: "000000-00-0000" });
    $("#RAPostcode").mask("00000", { reverse: false, clearIfNotMatch: true, placeholder: "XXXXX" });
    $("#CAPostcode").mask("00000", { reverse: false, clearIfNotMatch: true, placeholder: "XXXXX" });
    $("#AAPostcode").mask("00000", { reverse: false, clearIfNotMatch: true, placeholder: "XXXXX" });

    //autosize textarea height
    setInterval(function () {
        let ta = $('textarea');
        ta.each(function () {
            if (!$(this).hasClass("txtareaautosized")) {
                autosize($(this));
                autosize.update($(this));

                $(this).addClass("txtareaautosized");
            }
        });
    }, 500);

    $("form").validate().settings.ignore = "*";

    //disable enter key unless textarea
    $(document).on("keydown", ":input:not(textarea)", function (event) {
        if (event.key == "Enter")
            event.preventDefault();
    });

    let invalidChars = [
        "-",
        "+",
        "e",
    ];

    $('.numericVMS').keyup(function (e) {
        if (invalidChars.includes(e.key))
            e.preventDefault();
    })

    $(".numericVMS").on("input", function () {
        let nonNumReg = /[^0-9]/gi
        $(this).val($(this).val().replace(nonNumReg, ''));
    });
})
//#endregion

//#region Validation
//in order to use this validation make sure input, dropdown or table contain this span
//<span class="text-danger d-none error" errorfor="[Here your Key ID]">Field Required!</span>
//add this attribute to the input inputfor="[Here your Key ID]" customvalidation="yes" 
//<input type="text" inputfor="[Here your Key ID]" customvalidation="yes" />
$(function () {
    $('a[data-bs-toggle="tab"]').on('shown.bs.tab', function (e) {
        let isVersion = $("#isVersion").val();
        let isFormDisabled = $("#isFormDisabled").val();

        if (isVersion === "False" && isFormDisabled === "False")
            ReCheckValidation();
    });

    $('a[data-bs-toggle="tab"]').on('click', function () {
        if ($("#ProjectReferenceForm").length > 0) {
            if (!$("#ProjectReferenceForm").hasClass("hidden")) {
                $("#addProjectReference").trigger("click");
                $('html, body').animate({
                    scrollTop: $("#ProjectReferenceForm").offset().top - 270
                }, 2000);
                return false;
            }
        }
    });

    $("body").on('change blur', "input[type=text]:not([smlurl='yes']):not([smlemail='yes']:not([individualemail='yes']), textarea", function () {
        $(this).val(function (_, val) {
            return val.toUpperCase();
        });
    });

    $("body").on("change input click", 'input[customvalidation="yes"],input[sevalid="yes"],input[ravalid="yes"], input[cavalid="yes"], input[aavalid="yes"], input[kmsformvalid="yes"], input[projRefValid="yes"], input[tlValid="yes"], input[FSValid="yes"], input[awardValid="yes"], input[lcValid="yes"], input[tcompValid="yes"], input[profIndemValid="yes"], input[bankvalid="yes"], input[bankvalid2="yes"]', function () {
        let _this = $(this);
        let keyfor = _this.attr("inputfor");
        let keyModalfor = _this.attr("modalfor");
        _this.removeClass('smlinputrequired');
        $('span[errorfor="' + keyfor + '"]').addClass("d-none");
        $('span[errorfor="' + keyModalfor + '"]').addClass("d-none");
    });

    $("body").on("change input click", 'select[customvalidation="yes"],select[assignValid="yes"],select[assignBulkValid="yes"],select[FSValid="yes"], select[sevalid="yes"],select[ravalid="yes"], select[cavalid="yes"], select[aavalid="yes"], select[kmsformvalid="yes"], select[projRefValid="yes"], select[tlValid="yes"], select[awardValid="yes"], select[lcValid="yes"], select[bankvalid="yes"]', function () {
        let _this = $(this);
        let keyfor = _this.attr("inputfor");
        _this.removeClass('smlinputrequired');

        if (_this.siblings('span.select2.select2-container').length > 0)
            _this.siblings('span.select2.select2-container').removeClass('smlinputrequired');

        $('span[errorfor="' + keyfor + '"]').addClass("d-none");
    });

    $("body").on("change input click", 'textarea[customvalidation="yes"],textarea[lcValid="yes"],textarea[projRefValid="yes"]', function () {
        let _this = $(this);
        let keyfor = _this.attr("inputfor");
        let keyModalfor = _this.attr("modalfor");
        _this.removeClass('smlinputrequired');
        $('span[errorfor="' + keyfor + '"]').addClass("d-none");
        $('span[errorfor="' + keyModalfor + '"]').addClass("d-none");
    });

    $("body").on("change keyup input click", 'input[smlemail="yes"]', function () {
        let _this = $(this);
        let keyfor = _this.attr("inputfor");
        let keyModalfor = _this.attr("modalfor");
        $('span[errorfor="' + keyfor + '"]').addClass("d-none");
        $('span[errorfor="' + keyModalfor + '"]').addClass("d-none");

        let regex = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i;
        if (!regex.test(_this.val())) {
            $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("Please enter a valid email address!");
            $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
        }
        else {
            $('span[errorfor="' + keyfor + '"]').addClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("This field is required!");
            $('span[errorfor="' + keyModalfor + '"]').addClass("d-none");
        }

        if (_this.val().length == 0) {
            $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("This field is required!");
            $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
        }
    })

    $("body").on("change keyup input click", 'input[smlurl="yes"]', function () {
        let _this = $(this);
        let keyfor = _this.attr("inputfor");
        let keyModalfor = _this.attr("modalfor");
        $('span[errorfor="' + keyfor + '"]').addClass("d-none");
        $('span[errorfor="' + keyModalfor + '"]').addClass("d-none");

        let regex = /[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)?/gi;
        if (!regex.test(_this.val())) {
            $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("Please enter a valid URL!");
            $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
        }
    })

    $("body").on("keydown", '[type="number"]', function (e) {
        if ([69, 187, 188, 189, 190].includes(e.keyCode))
            e.preventDefault();
    })

    let numberOfRows = $("table[customvalidation='yes'] tbody>tr").length;
    $("table[customvalidation='yes']").bind("DOMSubtreeModified", function () {
        if ($("table[customvalidation='yes'] tbody>tr").length !== numberOfRows) {
            numberOfRows = $("#myTable>tbody>tr").length;
            let _this = $(this);
            let keyfor = _this.attr("inputfor");
            let keyModalfor = _this.attr("modalfor");
            $('span[errorfor="' + keyfor + '"]').addClass("d-none");
            $('span[errorfor="' + keyModalfor + '"]').addClass("d-none");
            $(this).removeClass('smlinputrequired');
        }
    });

    $("body").on("change", '.ProjectQualities_IsSelected', function () {
        ProjectQualityPlanCheckboxesMin();
    })

    $("body").on("change input click", '.CPDNewIDNo', function () {
        $(this).removeClass('smlinputrequired');
        let $this = $(this).closest("tr");
        $this.find(".CPDOldICNo_ROC_ROB").removeClass('smlinputrequired');
        $('span[errorfor="dirROCROBValid"]').addClass("d-none");
    })

    $("body").on("change input click", '.CPDOldICNo_ROC_ROB', function () {
        $(this).removeClass('smlinputrequired');
        $this = $(this).closest("tr");
        $this.find(".CPDNewIDNo").removeClass('smlinputrequired');
        $('span[errorfor="dirROCROBValid"]').addClass("d-none");
    })

    $("body").on("change input click", '.CPSHNewIDNo', function () {
        $(this).removeClass('smlinputrequired');
        $this = $(this).closest("tr");
        $this.find(".CPSHOldICNo_ROC_ROB").removeClass('smlinputrequired');
        $('span[errorfor="sharehROCROBValid"]').addClass("d-none");
    })

    $("body").on("change input click", '.CPSHOldICNo_ROC_ROB', function () {
        $(this).removeClass('smlinputrequired');
        $this = $(this).closest("tr");
        $this.find(".CPSHNewIDNo").removeClass('smlinputrequired');
        $('span[errorfor="sharehROCROBValid"]').addClass("d-none");
    })
})
function isSMLFormValid() {
    let isValid = true;

    //#region Validate Input
    let inputlist = $('input[customvalidation="yes"]:not([readonly="readonly"]):not(:disabled)');
    let textarealist = $('textarea[customvalidation="yes"]:not([readonly="readonly"]):not(:disabled)');
    let inputCheckBoxlist = $('input[type="checkbox"][customvalidation="yes"]:not(:disabled)');
    let inputRadiolist = $('input[type="radio"][customvalidation="yes"]:not(:disabled)');
    let email = $('input[smlemail="yes"][customvalidation="yes"]');

    let countreqempty = 0;
    $(inputlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker')) {
                    _this.focus().select();
                }
                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });

    $(textarealist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });

    //checkbox validation
    $(inputCheckBoxlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (!_this.prop('checked')) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });

    //radio button validation
    $(inputRadiolist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if ($('input:radio[name="' + _this.attr('name') + '"]:checked').length == 0) {
                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");
                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });
    //#endregion

    //#region Validate Dropdown
    let DropdownList = $('select[customvalidation="yes"]');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;

        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            //at least one selected
            if (_this.find('option:selected').length && _this.val() != "" && _this.val() != null)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });
    //#endregion

    //#region Validate Table
    let TableList = $('table[customvalidation="yes"]');
    $(TableList).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            let _totalRow = _this.find("tbody > tr")
            let isSelected = false;

            //at least one selected
            if (_totalRow.length)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });
    //#endregion

    $(email).each(function () {
        let _this = $(this);
        let keyfor = _this.attr("inputfor");
        let keyModalfor = _this.attr("modalfor");
        let errortabid = _this.attr("smltabfor");

        if (_this.attr("readonly") == "readonly")
            return;

        let regex = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i;
        if (!regex.test(_this.val())) {
            $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("Please enter a valid email address!");
            $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }

        if (_this.val().length == 0) {
            $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("This field is required!");
            $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");
        }
    });
    
    //companyresources attachment
    let CompOrg = $("#CompOrgChartAttachmentTable").length;
    let CompOrgtbody = $("#CompOrgChartAttachmentTable tbody tr").length;
    let hasCompanyOrgChart = $('input[type=radio][name="Consultant.CompanyResources.CompanyOrgChart"]:checked').val();

    if (CompOrg > 0 && hasCompanyOrgChart.toLowerCase() === "true") {
        if (!CompOrgtbody > 0) {
            $('span[errorfor="compResourceAttach"]').removeClass("d-none");
            $('span[smltaberr="CompanyResources"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="CompanyResources"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }
        else
            $('span[errorfor="compResourceAttach"]').addClass("d-none");
    }
    else
        $('span[errorfor="compResourceAttach"]').addClass("d-none");

    //ctos attachment
    let checkedVal = $('#RequireCTOSYes:checked').val();
    if (checkedVal == 1) {
        let ctos = $("#CTOSAttachmentTable").length;
        let ctostbody = $("#CTOSAttachmentTable tbody tr").length;
        if (ctos > 0 && !ctostbody > 0) {
            $('span[errorfor="ctosAttachValid"]').removeClass("d-none");
            $('span[smltaberr="CTOS"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="CTOS"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }
        else
            $('span[errorfor="ctosAttachValid"]').addClass("d-none");
    }

    if (countreqempty > 0)
        isValid = false;

    return isValid;
}

function isRAModalValid() {
    let isValid = true;

    //#region Validate Input
    let inputlist = $('input[ravalid="yes"]');
    let countreqempty = 0;
    $(inputlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });
    //#endregion

    //#region Validate Dropdown
    let DropdownList = $('select[ravalid="yes"]');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            //at least one selected
            if (_this.find('option:selected').length && _this.val() != "" && _this.val() != null)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });
    //#endregion


    if (countreqempty > 0)
        isValid = false;
    else
        $('span[errorfor="regAddValid"]').addClass("d-none");

    return isValid;
}

function isCAModalValid() {
    let isValid = true;

    //#region Validate Input
    let inputlist = $('input[cavalid="yes"]');
    let email = $('input[smlemail="yes"][cavalid="yes"]');
    let url = $('input[smlurl="yes"][cavalid="yes"]');
    
    let countreqempty = 0;
    $(inputlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });
    //#endregion 

    //#region Validate Dropdown
    let DropdownList = $('select[cavalid="yes"]');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            //at least one selected
            if (_this.find('option:selected').length && _this.val() != "" && _this.val() != null)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });
    //#endregion

    $(email).each(function () {
        let _this = $(this);
        let keyfor = _this.attr("inputfor");
        let keyModalfor = _this.attr("modalfor");
        let errortabid = _this.attr("smltabfor");

        if (_this.attr("readonly") == "readonly")
            return;

        let regex = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i;
        if (!regex.test(_this.val())) {
            $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("Please enter a valid email address!");
            $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }

        if (_this.val().length == 0) {
            $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("This field is required!");
            $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");
        }
    });

    $(url).each(function () {
        let _this = $(this);
        let keyfor = _this.attr("inputfor");
        let keyModalfor = _this.attr("modalfor");
        let errortabid = _this.attr("smltabfor");

        if (_this.val().length > 0) {
            let regex = /[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)?/gi;
            if (!regex.test(_this.val())) {
                $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
                $('span[errorfor="' + keyfor + '"]').text("Please enter a valid URL!");
                $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });


    if (countreqempty > 0)
        isValid = false;
    else
        $('span[errorfor="corrAddValid"]').addClass("d-none");

    return isValid;
}

function isAAModalValid() {
    let isValid = true;

    //#region Validate Input
    let inputlist = $('input[aavalid="yes"]');
    let email = $('input[smlemail="yes"][aavalid="yes"]');
    let url = $('input[smlurl="yes"][aavalid="yes"]');
    let countreqempty = 0;
    $(inputlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });
    //#endregion 

    //#region Validate Dropdown
    let DropdownList = $('select[aavalid="yes"]');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none') && _this.find('option:selected').length && _this.val() != "" && _this.val() != null)
            isSelected = true;

        if (!isSelected) {
            _this.focus().select();
            _this.addClass('smlinputrequired');

            if (_this.siblings('span.select2.select2-container').length > 0)
                _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

            let errorid = _this.attr('inputfor');
            let errormodalid = _this.attr('modalfor');
            let errortabid = _this.attr("smltabfor");

            $('span[errorfor="' + errorid + '"]').removeClass("d-none");
            $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }
    });
    //#endregion
    
    $(email).each(function () {
        let _this = $(this);
        let keyfor = _this.attr("inputfor");
        let keyModalfor = _this.attr("modalfor");

        if (_this.attr("readonly") == "readonly")
            return;

        let regex = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i;
        if (!regex.test(_this.val())) {
            $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("Please enter a valid email address!");
            $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }

        if (_this.val().length == 0) {
            $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("This field is required!");
            $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");
        }
    });

    $(url).each(function () {
        let _this = $(this);
        let keyfor = _this.attr("inputfor");
        let keyModalfor = _this.attr("modalfor");
        if (_this.val().length > 0) {
            let regex = /[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)?/gi;
            if (!regex.test(_this.val())) {
                $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
                $('span[errorfor="' + keyfor + '"]').text("Please enter a valid URL!");
                $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });

    if (countreqempty > 0)
        isValid = false;
    else
        $('span[errorfor="addAddValid"]').addClass("d-none");

    return isValid;
}

function isKMSFormValid() {
    let isValid = true;

    //#region Validate Input
    let inputlist = $('input[kmsformvalid="yes"]:not([readonly="readonly"])');
    let inputCheckBoxlist = $('input[type="checkbox"][kmsformvalid="yes"]');
    let email = $('input[smlemail="yes"][kmsformvalid="yes"]');

    let countreqempty = 0;
    $(inputlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });

    //checkbox validation
    $(inputCheckBoxlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (!_this.prop('checked')) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });
    //#endregion 

    //#region Validate Dropdown
    let DropdownList = $('select[kmsformvalid="yes"]');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none') && _this.find('option:selected').length && _this.val() != "" && _this.val() != null)
            isSelected = true;

        if (!isSelected) {
            _this.focus().select();
            _this.addClass('smlinputrequired');

            if (_this.siblings('span.select2.select2-container').length > 0)
                _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

            let errorid = _this.attr('inputfor');
            let errormodalid = _this.attr('modalfor');
            let errortabid = _this.attr("smltabfor");

            $('span[errorfor="' + errorid + '"]').removeClass("d-none");
            $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }
    });
    //#endregion

    $(email).each(function () {
        let _this = $(this);
        let keyfor = _this.attr("inputfor");
        let keyModalfor = _this.attr("modalfor");

        if (_this.attr("readonly") == "readonly")
            return;

        let regex = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i;
        if (!regex.test(_this.val())) {
            $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("Please enter a valid email address!");
            $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }

        if (_this.val().length == 0) {
            $('span[errorfor="' + keyfor + '"]').removeClass("d-none");
            $('span[errorfor="' + keyfor + '"]').text("This field is required!");
            $('span[errorfor="' + keyModalfor + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");
            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");
        }
    });

    if (countreqempty > 0)
        isValid = false;

    return isValid;
}

function isCIDBModalValid() {
    let isValid = true;

    let countreqempty = 0;
    //#region Validate Dropdown
    let DropdownList = $('select[cidbModalValid="yes"]');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none') && _this.find('option:selected').length && _this.val() != "" && _this.val() != null)
            isSelected = true;

        if (!isSelected) {
            _this.focus().select();
            _this.addClass('smlinputrequired');

            if (_this.siblings('span.select2.select2-container').length > 0)
                _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

            let errorid = _this.attr('inputfor');
            let errormodalid = _this.attr('modalfor');
            let errortabid = _this.attr("smltabfor");

            $('span[errorfor="' + errorid + '"]').removeClass("d-none");
            $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }
    });
    //#endregion

    //#region Validate Table
    let TableList = $('table[cidbModalValid="yes"]');
    $(TableList).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            let _totalRow = _this.find("tbody > tr")
            let isSelected = false;
            if (_totalRow.length)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });
    //#endregion
    
    if (countreqempty > 0)
        isValid = false;
    else {
        $('span[errorfor="CIDBGrade"]').addClass("d-none");
        $('span[smltaberr="TechnicalQualification"]').addClass("hidden");

        if ($('.dropdown-menu span[smltaberr="TechnicalQualification"]').hasClass("moretab"))
            $('span[smltaberr="MoreTab"]').addClass("hidden");
    }

    return isValid;
}

function isProjRefFormValid() {
    let isValid = true;

    //#region Validate Input
    if ($("#ProjectReferenceForm").length > 0) {
        if (!$("#ProjectReferenceForm").hasClass("hidden")) {
            let inputlist = $('input[projRefValid="yes"]:not([readonly="readonly"])');
            let textarealist = $('textarea[projRefValid="yes"]:not([readonly="readonly"])');
            let countreqempty = 0;
            $(inputlist).each(function () {
                let _this = $(this);
                if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
                    if (_this.val().length == 0) {
                        if (!_this.data('datepicker'))
                            _this.focus().select();

                        _this.addClass('smlinputrequired');

                        let errorid = _this.attr('inputfor');
                        let errormodalid = _this.attr('modalfor');
                        let errortabid = _this.attr("smltabfor");
                        
                        $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                        $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                        $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                        if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                            $('span[smltaberr="MoreTab"]').removeClass("hidden");

                        countreqempty++;
                    }
                }

                if (_this.hasClass('PRContractAmount')) {
                    if (_this.val() == "0.00" || _this.val() == "0") {
                        _this.focus().select();
                        _this.addClass('smlinputrequired');

                        let errorid = _this.attr('inputfor');
                        let errormodalid = _this.attr('modalfor');
                        let errortabid = _this.attr("smltabfor");

                        $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                        $('span[errorfor="' + errorid + '"]').text("Please enter a valid amount!");
                        $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                        $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");
                        if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                            $('span[smltaberr="MoreTab"]').removeClass("hidden");

                        countreqempty++;
                    }
                }
            });

            $(textarealist).each(function () {
                let _this = $(this);
                if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
                    if (_this.val().length == 0) {
                        _this.focus().select();
                        _this.addClass('smlinputrequired');

                        let errorid = _this.attr('inputfor');
                        let errormodalid = _this.attr('modalfor');
                        let errortabid = _this.attr("smltabfor");

                        $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                        $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                        $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                        if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                            $('span[smltaberr="MoreTab"]').removeClass("hidden");

                        countreqempty++;
                    }
                }
            });
            //#endregion

            //#region Validate Dropdown
            let DropdownList = $('select[projRefValid="yes"]');
            $(DropdownList).each(function () {
                let _this = $(this);
                let isSelected = false;
                if (!_this.hasClass('hidden') && !_this.hasClass('d-none') && _this.find('option:selected').length && _this.val() != "" && _this.val() != null)
                    isSelected = true;

                if (!isSelected) {
                    _this.focus().select();
                    _this.addClass('smlinputrequired');

                    if (_this.siblings('span.select2.select2-container').length > 0)
                        _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                    let errorid = _this.attr('inputfor');
                    let errortabid = _this.attr("smltabfor");

                    $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                    $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                    if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                        $('span[smltaberr="MoreTab"]').removeClass("hidden");

                    countreqempty++;
                }
            });
            //#endregion

            //#region Validate Table
            let TableList = $('table[projRefValid="yes"]');
            $(TableList).each(function () {
                let _this = $(this);
                if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
                    let _totalRow = _this.find("tbody > tr")
                    let isSelected = false;
                    if (_totalRow.length)
                        isSelected = true;

                    if (!isSelected) {
                        _this.focus().select();
                        _this.addClass('smlinputrequired');

                        if (_this.siblings('span.select2.select2-container').length > 0)
                            _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                        let errorid = _this.attr('inputfor');
                        let errortabid = _this.attr("smltabfor");

                        $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                        $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                        if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                            $('span[smltaberr="MoreTab"]').removeClass("hidden");

                        countreqempty++;
                    }
                }
            });
            //#endregion
            
            if (countreqempty > 0)
                isValid = false;
            else {
                $('span[smltaberr="ProjectReference"]').addClass("hidden");

                if ($('.dropdown-menu span[smltaberr="ProjectReference"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').addClass("hidden");
            }
        }
        else if (!!$("#frmMarketingSupplier").html() && $("#projRefTable tbody tr").length == 0)
            isValid = false;
    }

    return isValid;
}

function TLFormValid() {
    let isValid = true;

    //#region Validate Input
    let inputlist = $('input[tlValid="yes"]:not([readonly="readonly"])');
    let countreqempty = 0;
    $(inputlist).each(function () {
        let _this = $(this);

        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });
    //#endregion 

    //#region Validate Dropdown
    let DropdownList = $('select[tlValid="yes"]');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none') && _this.find('option:selected').length && _this.val() != "" && _this.val() != null)
            isSelected = true;

        if (!isSelected) {
            _this.focus().select();
            _this.addClass('smlinputrequired');

            if (_this.siblings('span.select2.select2-container').length > 0)
                _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

            let errorid = _this.attr('inputfor');
            let errortabid = _this.attr("smltabfor");

            $('span[errorfor="' + errorid + '"]').removeClass("d-none");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }
    });
    //#endregion

    //#region Validate Table
    let TableList = $('table[tlValid="yes"]');
    $(TableList).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            let _totalRow = _this.find("tbody > tr")
            let isSelected = false;
            if (_totalRow.length)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errortabid = _this.attr("smltabfor");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");
                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                countreqempty++;
            }
        }
    });

    if ($("#tbodyTLAtc > tr").length > 0)
        $('span[errorfor="tlAttach"]').addClass("d-none");
    else {
        $('span[errorfor="tlAttach"]').removeClass("d-none");
        $('span[smltaberr="ProjectReference"]').removeClass("hidden");

        if ($('.dropdown-menu span[smltaberr="ProjectReference"]').hasClass("moretab"))
            $('span[smltaberr="MoreTab"]').removeClass("hidden");

        countreqempty++;
    }
    //#endregion

    if (countreqempty > 0)
        isValid = false;
    else {
        $('span[smltaberr="ProjectReference"]').addClass("hidden");

        if ($('.dropdown-menu span[smltaberr="ProjectReference"]').hasClass("moretab"))
            $('span[smltaberr="MoreTab"]').addClass("hidden");
    }

    return isValid;
}

function AwardFormValid() {
    let isValid = true;

    //#region Validate Input
    let inputlist = $('input[awardValid="yes"]:not([readonly="readonly"])');
    let countreqempty = 0;
    $(inputlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                countreqempty++;
            }
        }
    });
    //#endregion

    //#region Validate Dropdown
    let DropdownList = $('select[awardValid="yes"]');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none') && _this.find('option:selected').length && _this.val() != "" && _this.val() != null)
            isSelected = true;

        if (!isSelected) {
            _this.focus().select();
            _this.addClass('smlinputrequired');

            if (_this.siblings('span.select2.select2-container').length > 0)
                _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

            let errorid = _this.attr('inputfor');
            let errortabid = _this.attr("smltabfor");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            $('span[errorfor="' + errorid + '"]').removeClass("d-none");
            countreqempty++;
        }
    });
    //#endregion

    //#region Validate Table
    let TableList = $('table[awardValid="yes"]');
    $(TableList).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            let _totalRow = _this.find("tbody > tr")
            let isSelected = false;

            if (_totalRow.length)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errortabid = _this.attr("smltabfor");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                countreqempty++;
            }
        }
    });
    //#endregion

    if ($("#tbodyAWAtc > tr").length > 0)
        $('span[errorfor="awardAttach"]').addClass("d-none");
    else {
        $('span[errorfor="awardAttach"]').removeClass("d-none");
        $('span[smltaberr="ProjectReference"]').removeClass("hidden");

        if ($('.dropdown-menu span[smltaberr="ProjectReference"]').hasClass("moretab"))
            $('span[smltaberr="MoreTab"]').removeClass("hidden");

        countreqempty++;
    }
    
    if (countreqempty > 0)
        isValid = false;
    else {
        $('span[smltaberr="ProjectReference"]').addClass("hidden");

        if ($('.dropdown-menu span[smltaberr="ProjectReference"]').hasClass("moretab"))
            $('span[smltaberr="MoreTab"]').addClass("hidden");
    }

    return isValid;
}

function LCValid() {
    let isValid = true;
    //#region Validate Input
    let inputlist = $('input[lcValid="yes"]:not([readonly="readonly"])').filter(':visible');
    let countreqempty = 0;
    $(inputlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                countreqempty++;
            }
        }
    });
    //#endregion 

    //#region Validate Textarea
    let textareaList = $('textarea[lcValid="yes"]:not([readonly="readonly"])').filter(':visible');
    $(textareaList).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                countreqempty++;
            }
        }
    });
    //#endregion

    //#region Validate Dropdown
    let DropdownList = $('select[lcValid="yes"]').filter(':visible');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none') && _this.find('option:selected').length && _this.val() != "" && _this.val() != null)
            isSelected = true;

        if (!isSelected) {
            _this.focus().select();
            _this.addClass('smlinputrequired');

            if (_this.siblings('span.select2.select2-container').length > 0)
                _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

            let errorid = _this.attr('inputfor');
            let errortabid = _this.attr("smltabfor");
            $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            $('span[errorfor="' + errorid + '"]').removeClass("d-none");
            countreqempty++;
        }
    });
    //#endregion
    
    if (countreqempty > 0)
        isValid = false;
    else {
        $('span[smltaberr="LegalCases"]').addClass("hidden");

        if ($('.dropdown-menu span[smltaberr="LegalCases"]').hasClass("moretab"))
            $('span[smltaberr="MoreTab"]').addClass("hidden");
    }

    return isValid;
}

function isTLandAwardTableValid() {
    let isValid = true;

    let countreqempty = 0;
    //#region Validate Table
    let TableListTL = $('table[TLTableValid="yes"]');
    let TableListAward = $('table[AwardTableValid="yes"]');

    if ($("input:radio.PRTestimonialLetters:checked").val() == "True") {
        $(TableListTL).each(function () {
            let _this = $(this);
            if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
                let _totalRow = _this.find("tbody > tr")
                let isSelected = false;
                if (_totalRow.length)
                    isSelected = true;

                if (!isSelected) {
                    _this.focus().select();
                    _this.addClass('smlinputrequired');

                    if (_this.siblings('span.select2.select2-container').length > 0)
                        _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                    let errorid = _this.attr('inputfor');
                    let errortabid = _this.attr("smltabfor");
                    $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                    if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                        $('span[smltaberr="MoreTab"]').removeClass("hidden");

                    $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                    countreqempty++;
                }
            }
        });
    }
    else
        $('span[errorfor="TLTable"]').addClass("d-none");

    if ($("input:radio.PRAward:checked").val() == "True") {
        $(TableListAward).each(function () {
            let _this = $(this);
            if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
                let _totalRow = _this.find("tbody > tr")
                let isSelected = false;
                if (_totalRow.length)
                    isSelected = true;

                if (!isSelected) {
                    if (_this.siblings('span.select2.select2-container').length > 0)
                        _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                    let errorid = _this.attr('inputfor');
                    let errortabid = _this.attr("smltabfor");
                    $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                    if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                        $('span[smltaberr="MoreTab"]').removeClass("hidden");

                    $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                    countreqempty++;
                }
            }
        });
    }
    else
        $('span[errorfor="AwardTable"]').addClass("d-none");
    //#endregion
    
    if (countreqempty > 0)
        isValid = false;
    else {
        $('span[smltaberr="ProjectReference"]').addClass("hidden");

        if ($('.dropdown-menu span[smltaberr="ProjectReference"]').hasClass("moretab"))
            $('span[smltaberr="MoreTab"]').addClass("hidden");
    }

    return isValid;
}

function isFSFormValid() {
    let isValid = true;

    //#region Validate Input
    let inputlist = $('input[FSValid="yes"]');
    let countreqempty = 0;
    $(inputlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                countreqempty++;
            }
        }
    });

    let DropdownList = $('select[FSValid="yes"]');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;

        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.find('option:selected').length && _this.val() != "" && _this.val() != null)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                countreqempty++;
            }
        }
    });
    //#endregion 
    
    if (countreqempty > 0)
        isValid = false;
    else {
        $('span[smltaberr="FinancialStability"]').addClass("hidden");

        if ($('.dropdown-menu span[smltaberr="FinancialStability"]').hasClass("moretab"))
            $('span[smltaberr="MoreTab"]').addClass("hidden");
    }

    return isValid;
}

function isFSFormValid2() {
    let isValid = true;

    //#region Validate Input
    let inputlist = $('input[FSValid2="yes"]');
    let countreqempty = 0;
    $(inputlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                countreqempty++;
            }
        }
    });

    let DropdownList = $('select[FSValid2="yes"]');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;

        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.find('option:selected').length && _this.val() != "" && _this.val() != null)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                countreqempty++;
            }
        }
    });
    //#endregion 

    if (countreqempty > 0)
        isValid = false;
    else {
        $('span[smltaberr="FinancialStability"]').addClass("hidden");

        if ($('.dropdown-menu span[smltaberr="FinancialStability"]').hasClass("moretab"))
            $('span[smltaberr="MoreTab"]').addClass("hidden");
    }

    return isValid;
}

function isSEFormValid() {
    let isValid = true;
    //#region Validate Input
    let inputlist = $('input[sevalid="yes"]:not([readonly="readonly"])').filter(':visible');
    let countreqempty = 0;
    $(inputlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                countreqempty++;
            }
        }
    });

    let DropdownList = $('select[sevalid="yes"]').filter(':visible');
    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;

        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.find('option:selected').length && _this.val() != "" && _this.val() != null)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                countreqempty++;
            }
        }
    });
    //#endregion 
    
    if (countreqempty > 0)
        isValid = false;

    return isValid;
}

//#region ValidationFunctionsRelatedToTabs
function openEditableTableInput() {
    $("#tbodyCompany")
        .find(".fa-pencil")
        .trigger("click");

    $("#tbodyShareHolder")
        .find(".fa-pencil")
        .trigger("click");

    $("#tbodyDirector")
        .find(".fa-pencil")
        .trigger("click");

    $("#tbodyGrade")
        .find(".fa-pencil")
        .trigger("click");

    $("#SiteVisitsbody")
        .find(".fa-pencil")
        .trigger("click");
}

function closeEditableTableInput() {
    $("#tbodyCompany")
        .find(".fa-save")
        .trigger("click");

    $("#tbodyShareHolder")
        .find(".fa-save")
        .trigger("click");

    $("#tbodyDirector")
        .find(".fa-save")
        .trigger("click");

    $("#tbodyGrade")
        .find(".fa-save")
        .trigger("click");

    $("#SiteVisitsbody")
        .find(".fa-save")
        .trigger("click");
}

function updateAddCompanyIndex() {
    let i = 0;
    $("#tbodyCompany tr").each(function (index, elem) {
        let CPCompParentChild = $(this).find(".CPCompParentChild");
        if (CPCompParentChild) {
            CPCompParentChild.attr("id", "CPCompParentChild" + i);
            CPCompParentChild.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPCompany[" + i + "].CPCompParentChild"
            );
        }

        let CPCompParentChildName = $(this).find(".CPCompParentChildName");
        if (CPCompParentChildName) {
            CPCompParentChildName.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPCompany[" +
                i +
                "].CPCompParentChildName"
            );
        }

        let CPCompName = $(this).find(".CPCompName");
        if (CPCompName) {
            CPCompName.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPCompany[" + i + "].CPCompName"
            );
        }

        let CPCfoVendorProfileID = $(this).find(".CPCfoVendorProfileID");
        if (CPCfoVendorProfileID) {
            CPCfoVendorProfileID.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPCompany[" +
                i +
                "].CPCfoVendorProfileID"
            );
        }

        let CPCompID = $(this).find(".CPCompID");
        if (CPCompID) {
            CPCompID.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPCompany[" + i + "].CPCompID"
            );
        }

        i++;
    });
}

function updateAddDirectorIndex() {
    let i = 0;
    $("#tbodyDirector tr").each(function (index, elem) {
        let CPDName = $(this).find(".CPDName");
        if (CPDName) {
            CPDName.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPDirector[" + i + "].CPDName"
            );
        }

        let CPDResidentialAdd = $(this).find(".CPDResidentialAdd");
        if (CPDResidentialAdd) {
            CPDResidentialAdd.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPDirector[" +
                i +
                "].CPDResidentialAdd"
            );
        }

        let CPDNewIDNo = $(this).find(".CPDNewIDNo");
        if (CPDNewIDNo) {
            CPDNewIDNo.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPDirector[" + i + "].CPDNewIDNo"
            );
        }

        let CPDOldICNo_ROC_ROB = $(this).find(".CPDOldICNo_ROC_ROB");
        if (CPDOldICNo_ROC_ROB) {
            CPDOldICNo_ROC_ROB.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPDirector[" +
                i +
                "].CPDOldICNo_ROC_ROB"
            );
        }

        let CPDDesignation = $(this).find(".CPDDesignation");
        if (CPDDesignation) {
            CPDDesignation.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPDirector[" + i + "].CPDDesignation"
            );
        }

        let CPDDesignationName = $(this).find(".CPDDesignationName");
        if (CPDDesignationName) {
            CPDDesignationName.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPDirector[" +
                i +
                "].CPDDesignationName"
            );
        }

        let CPDDOA = $(this).find(".CPDDOA");
        if (CPDDOA) {
            CPDDOA.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPDirector[" + i + "].CPDDOA"
            );
        }

        let CPDDOR = $(this).find(".CPDDOR");
        if (CPDDOR) {
            CPDDOR.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPDirector[" + i + "].CPDDOR"
            );
        }

        let CPDRemarks = $(this).find(".CPDRemarks");
        if (CPDRemarks) {
            CPDRemarks.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPDirector[" + i + "].CPDRemarks"
            );
        }

        let CPDfoVendorProfileID = $(this).find(".CPDfoVendorProfileID");
        if (CPDfoVendorProfileID) {
            CPDfoVendorProfileID.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPDirector[" +
                i +
                "].CPDfoVendorProfileID"
            );
        }

        let CPDID = $(this).find(".CPDID");
        if (CPDID) {
            CPDID.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPDirector[" + i + "].CPDID"
            );
        }

        i++;
    });
}

function updateAddShareHolderIndex() {
    let i = 0;
    $("#tbodyShareHolder tr").each(function (index, elem) {
        let CPSHName = $(this).find(".CPSHName");
        if (CPSHName) {
            CPSHName.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPShareholder[" + i + "].CPSHName"
            );
        }

        let CPSHNewIDNo = $(this).find(".CPSHNewIDNo");
        if (CPSHNewIDNo) {
            CPSHNewIDNo.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPShareholder[" + i + "].CPSHNewIDNo"
            );
        }

        let CPSHOldICNo_ROC_ROB = $(this).find(".CPSHOldICNo_ROC_ROB");
        if (CPSHOldICNo_ROC_ROB) {
            CPSHOldICNo_ROC_ROB.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPShareholder[" +
                i +
                "].CPSHOldICNo_ROC_ROB"
            );
        }

        let CPSHShareholding = $(this).find(".CPSHShareholding");
        if (CPSHShareholding) {
            CPSHShareholding.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPShareholder[" +
                i +
                "].CPSHShareholding"
            );
        }

        let CPSHShareholdingP = $(this).find(".CPSHShareholdingP");
        if (CPSHShareholdingP) {
            CPSHShareholdingP.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPShareholder[" +
                i +
                "].CPSHShareholdingP"
            );
        }

        let CPSHfoVendorProfileID = $(this).find(".CPSHfoVendorProfileID");
        if (CPSHfoVendorProfileID) {
            CPSHfoVendorProfileID.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPShareholder[" +
                i +
                "].CPSHfoVendorProfileID"
            );
        }

        let CPSHID = $(this).find(".CPSHID");
        if (CPSHID) {
            CPSHID.attr(
                "name",
                "GeneralInfo.CompanyParticular.CPShareholder[" + i + "].CPSHID"
            );
        }

        i++;
    });
}

function updateKMSIndex() {
    let i = 0;
    $("#tbodykeyMgmt tr").each(function (index, elem) {
        let KMSVendorID = $(this).find(".KMSVendorID");
        let KMSID = $(this).find(".KMSID");
        let CreatedBy = $(this).find(".CreatedBy");
        let CreatedOn = $(this).find(".CreatedOn");
        let ModifiedBy = $(this).find(".ModifiedBy");
        let ModifiedAt = $(this).find(".ModifiedAt");
        let IsDeleted = $(this).find(".IsDeleted");
        let KMSDesign = $(this).find(".KMSDesign");
        let KMSDesignR = $(this).find(".KMSDesignR");
        let KMSContactNo = $(this).find(".KMSContactNo");
        let KMSEmail = $(this).find(".KMSEmail");
        let KMSPrincipal = $(this).find(".KMSPrincipal");
        let KMSStatus = $(this).find(".KMSStatus");
        let KMSName = $(this).find(".KMSName");
        let KMSContactNoDialCode = $(this).find(".KMSContactNoDialCode");
        let KMSContactNoCountry = $(this).find(".KMSContactNoCountry");
        let KMSDesignID = $(this).find(".KMSDesignID");
        let KMSPrincipalID = $(this).find(".KMSPrincipalID");
        let KMSStaffStatusID = $(this).find(".KMSStaffStatusID");
        let KMSDesignLabel = $(this).find(".KMSDesignLabel");
        let KMSDesignRLabel = $(this).find(".KMSDesignRLabel");
        let KMSContactNoLabel = $(this).find(".KMSContactNoLabel");
        let KMSEmailLabel = $(this).find(".KMSEmailLabel");
        let KMSPrincipalLabel = $(this).find(".KMSPrincipalLabel");
        let KMSStatusLabel = $(this).find(".KMSStatusLabel");
        let KMSNameLabel = $(this).find(".KMSNameLabel");
        let editKMS = $(this).find(".editKMS");

        if (KMSVendorID) {
            KMSVendorID.attr("id", "KMSVendorID" + i);
            KMSVendorID.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].KMSfoVendorProfileID"
            );
        }

        if (KMSID) {
            KMSID.attr("id", "KMSID" + i);
            KMSID.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" + i + "].KMSID"
            );
        }

        if (CreatedBy) {
            CreatedBy.attr("id", "CreatedBy" + i);
            CreatedBy.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].CreatedBy"
            );
        }

        if (CreatedOn) {
            CreatedOn.attr("id", "CreatedOn" + i);
            CreatedOn.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].CreatedOn"
            );
        }

        if (ModifiedBy) {
            ModifiedBy.attr("id", "ModifiedBy" + i);
            ModifiedBy.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].ModifiedBy"
            );
        }

        if (ModifiedAt) {
            ModifiedAt.attr("id", "ModifiedAt" + i);
            ModifiedAt.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].ModifiedAt"
            );
        }

        if (IsDeleted) {
            IsDeleted.attr("id", "IsDeleted" + i);
            IsDeleted.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].IsDeleted"
            );
        }

        if (KMSDesign) {
            KMSDesign.attr("id", "KMSDesign" + i);
            KMSDesign.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].KMSDesignation"
            );
        }

        if (KMSDesignR) {
            KMSDesignR.attr("id", "KMSDesignR" + i);
            KMSDesignR.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].KMSDesignationRemark"
            );
        }

        if (KMSPrincipal) {
            KMSPrincipal.attr("id", "KMSPrincipal" + i);
            KMSPrincipal.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].KMSPrincipal"
            );
        }

        if (KMSStatus) {
            KMSStatus.attr("id", "KMSStatus" + i);
            KMSStatus.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].KMSStaffStatus"
            );
        }

        if (KMSContactNo) {
            KMSContactNo.attr("id", "KMSContactNo" + i);
            KMSContactNo.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].KMSContactNo"
            );
        }

        if (KMSEmail) {
            KMSEmail.attr("id", "KMSEmail" + i);
            KMSEmail.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" +
                i +
                "].KMSEmail"
            );
        }

        if (KMSName) {
            KMSName.attr("id", "KMSName" + i);
            KMSName.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" + i + "].KMSName"
            );
        }

        if (KMSDesignID) {
            KMSDesignID.attr("id", "KMSDesignID" + i);
        }

        if (KMSPrincipalID) {
            KMSPrincipalID.attr("id", "KMSPrincipalID" + i);
        }

        if (KMSStaffStatusID) {
            KMSStaffStatusID.attr("id", "KMSStaffStatusID" + i);
        }

        if (KMSContactNoDialCode) {
            KMSContactNoDialCode.attr("id", "KMSContactNoDialCode" + i);
            KMSContactNoDialCode.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" + i + "].KMSContactNoDialCode"
            );
        }

        if (KMSContactNoCountry) {
            KMSContactNoCountry.attr("id", "KMSContactNoCountry" + i);
            KMSContactNoCountry.attr(
                "name",
                "GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" + i + "].KMSContactNoCountry"
            );
        }

        if (KMSDesignLabel) {
            KMSDesignLabel.attr("id", "KMSDesignLabel" + i);
        }

        if (KMSDesignRLabel) {
            KMSDesignRLabel.attr("id", "KMSDesignRLabel" + i);
        }

        if (KMSPrincipalLabel) {
            KMSPrincipalLabel.attr("id", "KMSPrincipalLabel" + i);
        }

        if (KMSStatusLabel) {
            KMSStatusLabel.attr("id", "KMSStatusLabel" + i);
        }

        if (KMSContactNoLabel) {
            KMSContactNoLabel.attr("id", "KMSContactNoLabel" + i);
        }

        if (KMSEmailLabel) {
            KMSEmailLabel.attr("id", "KMSEmailLabel" + i);
        }

        if (KMSNameLabel) {
            KMSNameLabel.attr("id", "KMSNameLabel" + i);
        }

        if (editKMS) {
            editKMS.attr("data-id", i);
        }

        i++;
    });
}

function updateTechComptenciesIndex() {
    let i = 0;
    $("#techCompTbody > tr").each(function (index, elem) {
        let IsPosition = $(this).find(".IsPosition");
        let IsKMSID = $(this).find(".IsKMSID");
        let IsTCID = $(this).find(".IsTCID");
        let TCAtcBody = $(this).find(".TCAtcBody");
        let IsProfBodyQualification = $(this).find(".IsProfBodyQualification");
        let IsQualifications = $(this).find(".IsQualifications");
        let IsServiceYearSince = $(this).find(".IsServiceYearSince");
        let IsYearsOfExperience = $(this).find(".IsYearsOfExperience");
        let editTCAttch1 = $(this).find(".editTCAttch1");


        if (TCAtcBody) {
            TCAtcBody.attr("id", "TCAtcBody" + i);
        }

        if (IsTCID) {
            IsTCID.attr("id", "IsTCID" + i);
            IsTCID.attr(
                "name",
                "Consultant.TechnicalCompentencies.StaffTechCompentencies[" +
                i +
                "].TCID"
            );
        }

        if (IsKMSID) {
            IsKMSID.attr("id", "IsKMSID" + i);
            IsKMSID.attr(
                "name",
                "Consultant.TechnicalCompentencies.StaffTechCompentencies[" +
                i +
                "].KMSID"
            );
        }

        if (IsPosition) {
            IsPosition.attr("id", "IsPosition" + i);
            IsPosition.attr(
                "name",
                "Consultant.TechnicalCompentencies.StaffTechCompentencies[" +
                i +
                "].PositionId"
            );
        }

        if (IsProfBodyQualification) {
            IsProfBodyQualification.attr("id", "IsProfBodyQualification" + i);
            IsProfBodyQualification.attr(
                "name",
                "Consultant.TechnicalCompentencies.StaffTechCompentencies[" +
                i +
                "].ProfBodyQualification"
            );
        }

        if (IsQualifications) {
            IsQualifications.attr("id", "IsQualifications" + i);
            IsQualifications.attr(
                "name",
                "Consultant.TechnicalCompentencies.StaffTechCompentencies[" +
                i +
                "].QualificationId"
            );
        }

        if (IsYearsOfExperience) {
            IsYearsOfExperience.attr("id", "IsYearsOfExperience" + i);
            IsYearsOfExperience.attr(
                "name",
                "Consultant.TechnicalCompentencies.StaffTechCompentencies[" +
                i +
                "].YearsOfExperience"
            );
        }

        if (IsServiceYearSince) {
            IsServiceYearSince.attr("id", "IsServiceYearSince" + i);
            IsServiceYearSince.attr(
                "name",
                "Consultant.TechnicalCompentencies.StaffTechCompentencies[" +
                i +
                "].ServiceYearSince"
            );
        }
        
        if (editTCAttch1) {
            editTCAttch1.attr("data-index", i);
        }
        
        i++;
    });

    TechCompAttachIndex();
}

function TechCompAttachIndex() {
    let i = 0;
    $("#techCompTbody > tr").each(function () {
        let j = 0;
        $(this).find("tbody > tr").each(function () {
            let AttachmentID = $(this).find(".AttachmentID");
            if (AttachmentID) {
                AttachmentID.attr(
                    "name",
                    "Consultant.TechnicalCompentencies.StaffTechCompentencies[" + i + "].Attachments[" + j + "].AttachmentID"
                );
            }

            let AttachmentfoRefNo = $(this).find(".AttachmentfoRefNo");
            if (AttachmentfoRefNo) {
                AttachmentfoRefNo.attr(
                    "name",
                    "Consultant.TechnicalCompentencies.StaffTechCompentencies[" + i + "].Attachments[" + j + "].AttachmentfoRefNo"
                );
            }

            let AttachmentURL = $(this).find(".AttachmentURL");
            if (AttachmentURL) {
                AttachmentURL.attr(
                    "name",
                    "Consultant.TechnicalCompentencies.StaffTechCompentencies[" + i + "].Attachments[" + j + "].AttachmentURL"
                );
            }

            let AttachmentName = $(this).find(".AttachmentName");
            if (AttachmentName) {
                AttachmentName.attr(
                    "name",
                    "Consultant.TechnicalCompentencies.StaffTechCompentencies[" + i + "].Attachments[" + j + "].AttachmentName"
                );
            }

            let AttachmentTabID = $(this).find(".AttachmentTabID");
            if (AttachmentTabID) {
                AttachmentTabID.attr(
                    "name",
                    "Consultant.TechnicalCompentencies.StaffTechCompentencies[" + i + "].Attachments[" + j + "].AttachmentTabID"
                );
            }

            j++;
        });
        i++;
    });
}

function checkPrincipleInactive() {
    let i = 0;
    let isValid = false;

    if ($("#tbodykeyMgmt tr").length > 0) {
        $("#tbodykeyMgmt tr").each(function (index, elem) {
            if ($("#KMSPrincipal" + i).val() == "Yes" && $("#KMSStatus" + i).val() == "Inactive") {
                $("#kmsPricipalCheck").removeClass("d-none");
                $('span[smltaberr="KeyManagementAndStaff"]').removeClass("hidden");

                if ($('span[smltaberr="KeyManagementAndStaff"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                isValid = false;
                return isValid;
            }
            else {
                $("#kmsPricipalCheck").addClass("d-none");
                isValid = true;
            }
            i++;
        });
    }
    else
        isValid = true;

    return isValid;
}

function checkPrincipleExist() {
    let i = 0;
    let isValid = false;

    if (!!document.getElementById("tbodykeyMgmt")) {
        if ($("#tbodykeyMgmt tr").length > 0) {
            let isExist = 0;
            $("#tbodykeyMgmt tr").each(function (index, elem) {
                if ($("#KMSPrincipal" + i).val() == "Yes")
                    isExist = isExist + 1;
                i++;
            });

            if (isExist > 0) {
                $("#kmsPricipalExist").addClass("d-none");
                isValid = true;
            }
            else {
                $("#kmsPricipalExist").removeClass("d-none");
                $('span[smltaberr="KeyManagementAndStaff"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="KeyManagementAndStaff"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");
            }
        }
        else {
            $("#kmsPricipalExist").removeClass("d-none");
            $('span[smltaberr="KeyManagementAndStaff"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="KeyManagementAndStaff"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");
        }
    }
    else
        isValid = true;

    return isValid;
}

function checkTechCompentency() {
    let i = 0;
    let isValid = false;

    if ($("#tblTechnicalCompentency tbody tr").length > 0) {
        $("#tblTechnicalCompentency tbody tr").each(function (index, elem) {
            let $validator = $("#TechCompTableValid");

            let tdPositionDesc = $(this).find(".tdPositionDesc");
            let tdQualificationDesc = $(this).find(".tdQualificationDesc");

            if (tdPositionDesc.text() == "") {
                $validator.removeClass("d-none");
                isValid = false;
                return isValid;
            }
            else {
                $validator.addClass("d-none");
                isValid = true;
            }

            if (tdQualificationDesc.text() == "") {
                $validator.removeClass("d-none");
                isValid = false;
                return isValid;
            }
            else {
                $validator.addClass("d-none");
                isValid = true;
            }

            i++;
        });
    }
    else
        isValid = true;

    return isValid;
}

function ProfIndemnityAmountCheck() {
    $(".AnyOneClaimDataAmount").each(function (index, elem) {
        let _this = $(this);

        let amount = _this.val().replace(/,/g, "");
        _this.val(amount);
    });

    $(".AggregateDataAmount").each(function (index, elem) {
        let _this = $(this);

        let amount = _this.val().replace(/,/g, "");
        _this.val(amount);
    });

    $(".DeductibleDataAmount").each(function (index, elem) {
        let _this = $(this);

        let amount = _this.val().replace(/,/g, "");
        _this.val(amount);
    });

    $(".RetroactiveDataAmount").each(function (index, elem) {
        let _this = $(this);

        let amount = _this.val().replace(/,/g, "");
        _this.val(amount);
    });
}

function ProjectQualityPlanCheckboxesMin() {
    let i = 0;
    let isValid = true;

    let countreqempty = 0;
    if ($(".ProjectQualities_IsSelected").length > 0) {
        $(".ProjectQualities_IsSelected").each(function (index, elem) {
            let _this = $(this);
            if (_this.prop('checked'))
                i++;
        });

        if (i >= 5)
            $('span[errorfor="QualityPlanCheckboxes"]').addClass("d-none");
        else {
            countreqempty++;
            $('span[errorfor="QualityPlanCheckboxes"]').removeClass("d-none");
            $('span[smltaberr="ProjectQualityPlan"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="ProjectQualityPlan"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");
        }

        if (countreqempty > 0)
            isValid = false;

        return isValid;
    }
    else
        return true;
}

function BankDetailsValid() {
    let isValid = true;

    let countreqempty = 0;

    if ($("input[name='GeneralInfo.BankDetail.BDBankInfo']:checked").val() == "True") {
        let inputlist = $('input[bankvalid="yes"]:not([readonly="readonly"])');
        let inputlist2 = $('input[bankvalid2="yes"]:not([readonly="readonly"])');

        $(inputlist).each(function () {
            let _this = $(this);
            if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
                if (_this.val().length == 0) {
                    if (!_this.data('datepicker'))
                        _this.focus().select();

                    _this.addClass('smlinputrequired');

                    let errorid = _this.attr('inputfor');
                    let errormodalid = _this.attr('modalfor');
                    let errortabid = _this.attr("smltabfor");

                    $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                    $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                    $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                    if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                        $('span[smltaberr="MoreTab"]').removeClass("hidden");

                    countreqempty++;
                }
            }
        });

        let DropdownList = $('select[bankvalid="yes"]');
        $(DropdownList).each(function () {
            let _this = $(this);
            let isSelected = false;
            if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
                if (_this.find('option:selected').length && _this.val() != "" && _this.val() != null)
                    isSelected = true;

                if (!isSelected) {
                    _this.focus().select();
                    _this.addClass('smlinputrequired');

                    if (_this.siblings('span.select2.select2-container').length > 0)
                        _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                    let errorid = _this.attr('inputfor');
                    let errormodalid = _this.attr('modalfor');
                    let errortabid = _this.attr("smltabfor");

                    $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                    $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                    $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                    countreqempty++;
                }
            }
        });
        
        if ($("input[name='GeneralInfo.BankDetail.BDChangePayeeName']:checked").val() == "True") {
            $(inputlist2).each(function () {
                let _this = $(this);
                if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
                    if (_this.val().length == 0) {
                        _this.focus().select();
                        _this.addClass('smlinputrequired');

                        _this.find('.select2-container').addClass('smlinputrequired');

                        let errorid = _this.attr('inputfor');
                        let errormodalid = _this.attr('modalfor');
                        let errortabid = _this.attr("smltabfor");

                        $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                        $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                        $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                        if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                            $('span[smltaberr="MoreTab"]').removeClass("hidden");

                        countreqempty++;
                    }
                }
            });
        }
    }

    if (countreqempty > 0)
        isValid = false;

    return isValid;
}

function ISOValid() {
    let isValid = true;

    let countreqempty = 0;
    let iso9001CertIsChecked = $('input[type=radio][name="Consultant.ISO9001Certificate.HasISO9001Certificate"]:checked').val();

    let inputlist = $('input[isoValid="yes"]:not([readonly="readonly"])');
    let inputlist2 = $('input[isoValid2="yes"]:not([readonly="readonly"])');
    let inputCheckBoxlist = $('input[type="checkbox"][isoValid="yes"]:not(:disabled)');
    let inputRadiolist = $('input[type="radio"][isoValid="yes"]:not(:disabled)');

    $(inputlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.val().length == 0) {
                if (!_this.data('datepicker'))
                    _this.focus().select();

                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });

    $(inputCheckBoxlist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (!_this.prop('checked')) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });

    //radio button validation
    $(inputRadiolist).each(function () {
        let _this = $(this);
        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if ($('input:radio[name="' + _this.attr('name') + '"]:checked').length == 0) {
                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });

    if (iso9001CertIsChecked == "Yes") {
        $(inputlist2).each(function () {
            let _this = $(this);
            if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
                if (_this.val().length == 0) {
                    _this.focus().select();
                    _this.addClass('smlinputrequired');

                    let errorid = _this.attr('inputfor');
                    let errormodalid = _this.attr('modalfor');
                    let errortabid = _this.attr("smltabfor");

                    $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                    $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                    $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                    if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                        $('span[smltaberr="MoreTab"]').removeClass("hidden");

                    countreqempty++;
                }
            }
        });
    }

    //iso attachment
    let isotbody = $("#iso9001CertAttachmentTable tbody tr").length;
    if (iso9001CertIsChecked == "Yes") {
        if (!isotbody > 0) {
            $('span[errorfor="isoAttach"]').removeClass("d-none");
            $('span[smltaberr="ISO9001Certificate"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="ISO9001Certificate"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }
        else
            $('span[errorfor="isoAttach"]').addClass("d-none");
    }

    if (countreqempty > 0)
        isValid = false;

    return isValid;
}

function ProfIndemValid() {
    let isValid = true;

    let countreqempty = 0;

    if ($("input[name='Consultant.ProfessionalIndemity.ProfIndemnityItem.IsProfessionalIndemnity']:checked").val() == "True") {
        //#region Validate Input
        let inputlist = $('input[profIndemValid="yes"]:not([readonly="readonly"])');
        let inputRadiolist = $('input[type="radio"][profIndemValid="yes"]');
        $(inputlist).each(function () {
            let _this = $(this);
            if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
                if (_this.val().length == 0) {
                    if (!_this.data('datepicker'))
                        _this.focus().select();

                    _this.addClass('smlinputrequired');

                    let errorid = _this.attr('inputfor');
                    let errormodalid = _this.attr('modalfor');
                    let errortabid = _this.attr("smltabfor");
                    $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");
                    $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                    $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");

                    if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                        $('span[smltaberr="MoreTab"]').removeClass("hidden");

                    countreqempty++;
                }
            }
        });

        //radio button validation
        $(inputRadiolist).each(function () {
            let _this = $(this);
            if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
                if ($('input:radio[name="' + _this.attr('name') + '"]:checked').length == 0) {
                    let errorid = _this.attr('inputfor');
                    let errormodalid = _this.attr('modalfor');
                    let errortabid = _this.attr("smltabfor");
                    $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");
                    $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                    $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");

                    if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                        $('span[smltaberr="MoreTab"]').removeClass("hidden");

                    countreqempty++;
                }
            }
        });
        //#endregion 

        //prof idem attachment
        let PItbody = $("#PItblAttachment tbody tr").length;
        if (!PItbody > 0) {
            $('span[errorfor="profIdemAttach"]').removeClass("d-none");
            $('span[smltaberr="ProfessionalIndemnity"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="ProfessionalIndemnity"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }
        else
            $('span[errorfor="profIdemAttach"]').addClass("d-none");
    }
    
    if (countreqempty > 0)
        isValid = false;
    return isValid;
}

function checkProjRefTable() {
    let i = 0;
    let countreqempty = 0;
    let isValid = true;
    $validator = $("#ProjRefTableValidation");

    if ($("#projectReferenceBody > tr").length > 0) {
        $("#projectReferenceBody > tr").each(function (index, elem) {
            $(this).find(".PRYearofAgreementReceived").each(function () {
                let _this = $(this);
                if (_this.val() == "") {
                    $validator.removeClass("d-none");
                    countreqempty++;
                }
            });

            $(this).find(".PRYearofDevelopmentCompleted").each(function () {
                let _this = $(this);
                if (_this.val() == "") {
                    $validator.removeClass("d-none");
                    countreqempty++;
                }
            });

            $(this).find(".TDfoSLIItemID").each(function () {
                let _this = $(this);
                if (_this.val() == "") {
                    $validator.removeClass("d-none");
                    countreqempty++;
                }
            });

            $(this).find(".PREmployer").each(function () {
                let _this = $(this);
                if (_this.val() == "") {
                    $validator.removeClass("d-none");
                    countreqempty++;
                }
            });

            $(this).find(".PRLfoLocationID").each(function () {
                let _this = $(this);
                if (_this.val() == "") {
                    $validator.removeClass("d-none");
                    countreqempty++;
                }
            });

            $(this).find(".PRProjectTitle").each(function () {
                let _this = $(this);
                if (_this.val() == "") {
                    $validator.removeClass("d-none");
                    countreqempty++;
                }
            });

            $(this).find(".PRCSfoSLItemID").each(function () {
                let _this = $(this);
                if (_this.val() == "") {
                    $validator.removeClass("d-none");
                    countreqempty++;
                }
            });

            $(this).find(".TableProjectCS").each(function () {
                let _this = $(this);
                if (_this.find('tbody tr').length <= 0) {
                    $validator.removeClass("d-none");
                    countreqempty++;
                }
            });

            $(this).find(".prtypeofdevelopmenttable").each(function () {
                let _this = $(this);
                if (_this.find('tbody tr').length <= 0) {
                    $validator.removeClass("d-none");
                    countreqempty++;
                }
            });

            $(this).find(".TableProjectofLocation").each(function () {
                let _this = $(this);
                if (_this.find('tbody tr').length <= 0) {
                    $validator.removeClass("d-none");
                    countreqempty++;
                }
            });

            i++;
        });
    }

    if (countreqempty > 0) {
        isValid = false;
        $('span[smltaberr="ProjectReference"]').removeClass("hidden");
        if ($('.dropdown-menu span[smltaberr="ProjectReference"]').hasClass("moretab"))
            $('span[smltaberr="MoreTab"]').removeClass("hidden");
    }
    else {
        $validator.addClass("d-none");
        $('span[smltaberr="ProjectReference"]').addClass("hidden");

        if ($('.dropdown-menu span[smltaberr="ProjectReference"]').hasClass("moretab"))
            $('span[smltaberr="MoreTab"]').addClass("hidden");
    }
    
    return isValid;
}

function assignBulkValid() {
    let isValid = true;

    let DropdownList = $('select[assignBulkValid="yes"]');
    let countreqempty = 0;

    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;

        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.find('option:selected').length && _this.val() != "" && _this.val() != null)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });

    if (countreqempty > 0)
        isValid = false;

    return isValid;
}

function assignValid() {
    let isValid = true;

    let DropdownList = $('select[assignValid="yes"]');
    let countreqempty = 0;

    $(DropdownList).each(function () {
        let _this = $(this);
        let isSelected = false;

        if (!_this.hasClass('hidden') && !_this.hasClass('d-none')) {
            if (_this.find('option:selected').length && _this.val() != "" && _this.val() != null)
                isSelected = true;

            if (!isSelected) {
                _this.focus().select();
                _this.addClass('smlinputrequired');

                if (_this.siblings('span.select2.select2-container').length > 0)
                    _this.siblings('span.select2.select2-container').addClass('smlinputrequired');

                let errorid = _this.attr('inputfor');
                let errormodalid = _this.attr('modalfor');
                let errortabid = _this.attr("smltabfor");

                $('span[errorfor="' + errorid + '"]').removeClass("d-none");
                $('span[errorfor="' + errormodalid + '"]').removeClass("d-none");
                $('span[smltaberr="' + errortabid + '"]').removeClass("hidden");

                if ($('.dropdown-menu span[smltaberr="' + errortabid + '"]').hasClass("moretab"))
                    $('span[smltaberr="MoreTab"]').removeClass("hidden");

                countreqempty++;
            }
        }
    });

    if (countreqempty > 0)
        isValid = false;

    return isValid;
}

function ProfIndemnityAmountRemoveComma() {
    $(".AmountFormat").each(function () {
        let _this = $(this);
        const value = _this.val().replace(/,/g, '');
        let amount = value;

        if (amount != "NaN")
            _this.val(amount);
        else {
            amount = parseFloat(0).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
            _this.val(amount);
        }
    });

    $(".AnyOneClaimDataAmount").each(function () {
        let _this = $(this);
        const value = _this.val().replace(/,/g, '');
        let amount = value;

        if (amount != "NaN")
            _this.val(amount);
        else {
            amount = parseFloat(0).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
            _this.val(amount);
        }
    });

    $(".AggregateDataAmount").each(function () {
        let _this = $(this);
        const value = _this.val().replace(/,/g, '');
        let amount = value;

        if (amount != "NaN")
            _this.val(amount);
        else {
            amount = parseFloat(0).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
            _this.val(amount);
        }
    });

    $(".DeductibleDataAmount").each(function () {
        let _this = $(this);
        const value = _this.val().replace(/,/g, '');
        let amount = value;

        if (amount != "NaN")
            _this.val(amount);
        else {
            amount = parseFloat(0).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
            _this.val(amount);
        }
    });

    $(".RetroactiveDataAmount").each(function () {
        let _this = $(this);
        const value = _this.val().replace(/,/g, '');
        let amount = value;

        if (amount != "NaN")
            _this.val(amount);
        else {
            amount = parseFloat(0).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
            _this.val(amount);
        }
    });
}

function CheckROCROBTable() {
    let i = 0;
    let j = 0;
    let isValid = true;

    let countreqempty = 0;

    $("#tbodyDirector tr").each(function (index, elem) {
        let CPDNewIDNo = $(this).find(".CPDNewIDNo");
        let CPDOldICNo_ROC_ROB = $(this).find(".CPDOldICNo_ROC_ROB");

        if (CPDNewIDNo.val().length == 0 && CPDOldICNo_ROC_ROB.val().length == 0) {

            CPDNewIDNo.focus().select();
            CPDOldICNo_ROC_ROB.focus().select();

            CPDNewIDNo.addClass('smlinputrequired');
            CPDOldICNo_ROC_ROB.addClass('smlinputrequired');

            $('span[errorfor="dirROCROBValid"]').removeClass("d-none");
            $('span[smltaberr="CompParticular"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="CompParticular"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }
        else {
            CPDNewIDNo.removeClass('smlinputrequired');
            CPDOldICNo_ROC_ROB.removeClass('smlinputrequired');
            $('span[errorfor="dirROCROBValid"]').addClass("d-none");
        }

        i++;
    });


    $("#tbodyShareHolder tr").each(function (index, elem) {
        let CPSHNewIDNo = $(this).find(".CPSHNewIDNo");
        let CPSHOldICNo_ROC_ROB = $(this).find(".CPSHOldICNo_ROC_ROB");

        if (CPSHNewIDNo.val().length === 0 && CPSHOldICNo_ROC_ROB.val().length === 0) {

            CPSHNewIDNo.focus().select();
            CPSHOldICNo_ROC_ROB.focus().select();

            CPSHNewIDNo.addClass('smlinputrequired');
            CPSHOldICNo_ROC_ROB.addClass('smlinputrequired');

            $('span[errorfor="sharehROCROBValid"]').removeClass("d-none");
            $('span[smltaberr="CompParticular"]').removeClass("hidden");

            if ($('.dropdown-menu span[smltaberr="CompParticular"]').hasClass("moretab"))
                $('span[smltaberr="MoreTab"]').removeClass("hidden");

            countreqempty++;
        }
        j++;
    });


    if (countreqempty > 0)
        isValid = false;

    return isValid;
}

function KMSPhoneCodeUpdate() {
    let i = 0;
    $("#tbodykeyMgmt tr").each(function (index, elem) {
        if (this["itikms" + i]) {
            let code = this["itikms" + i].getSelectedCountryData();
            $("#KMSContactNoCountry" + i).val(code.iso2);
            $("#KMSContactNoDialCode" + i).val(code.dialCode);
            $("input[name='GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" + i + "].KMSContactNoDialCode']").val(code.dialCode);
            $("input[name='GeneralInfo.KeyManagementAndStaff.KeyMgmtAndStaff[" + i + "].KMSContactNoCountry']").val(code.iso2);
            i++;
        }
    });
}

function updateGradeIndex() {
    let i = 0;
    $("#tbodyGrade tr").each(function (index, elem) {
        let GWorkTypeID = $(this).find(".GWorkTypeID");
        let OldGWorkTypeID = $(this).find(".OldGWorkTypeID");
        let GRemark = $(this).find(".GRemark");
        let GCreatedBy = $(this).find(".GCreatedBy");
        let GDate = $(this).find(".GDate");
        let GID = $(this).find(".GID");
        let GVendorID = $(this).find(".GVendorID");
        let GGradeID = $(this).find(".GGradeID");
        let OldGGradeID = $(this).find(".OldGGradeID");
        let GfoRcmdByHod = $(this).find(".GfoRcmdByHod");
        let GModifiedBy = $(this).find(".GModifiedBy");
        let GModifiedAt = $(this).find(".GModifiedAt");
        let GStatus = $(this).find(".GStatus");

        if (GWorkTypeID) {
            GWorkTypeID.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].GfoWorkType"
            );
        }

        if (OldGWorkTypeID) {
            OldGWorkTypeID.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].OldGfoWorkType"
            );
        }

        if (GGradeID) {
            GGradeID.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].GfoGrade"
            );
        }

        if (OldGGradeID) {
            OldGGradeID.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].OldGfoGrade"
            );
        }

        if (GfoRcmdByHod) {
            GfoRcmdByHod.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].GfoRcmdByHod"
            );
        }

        if (GRemark) {
            GRemark.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].GRemark"
            );
        }

        if (GCreatedBy) {
            GCreatedBy.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].CreatedBy"
            );
        }

        if (GDate) {
            GDate.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].CreatedOn"
            );
        }

        if (GVendorID) {
            GVendorID.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].GfoVendorProfileID"
            );
        }

        if (GID) {
            GID.attr("name", "Contractor.GradeViewModel.Grade[" + i + "].GID");
        }

        if (GModifiedBy) {
            GModifiedBy.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].ModifiedBy"
            );
        }

        if (GModifiedAt) {
            GModifiedAt.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].ModifiedAt"
            );
        }

        if (GStatus) {
            GStatus.attr(
                "name",
                "Contractor.GradeViewModel.Grade[" + i + "].GStatus"
            );
        }

        i++;
    });
}

function KMSTechCompCheck() {
    let isValid = true;
    let KMS = [];
    let TechComp = [];

    if ($("#tblTechnicalCompentency").length > 0) {

        $(".KMSDesign").each(function (index, elem) {
            let _this = $(this).closest('tr');
            let status = _this.find(".KMSStatus").val();
            if (status == "Active") {
                KMS.push($(this).find('option:selected').text().trim());
            }
        });

        $(".IsPosition").each(function (index, elem) {
            TechComp.push($(this).find('option:selected').text().trim());
        });

        if (KMS.length != TechComp.length) {
            isValid = false;
            $('span[smltaberr="TechnicalCompetencies"]').removeClass("hidden");
            if ($('.dropdown-menu span[smltaberr="TechnicalCompetencies"]').hasClass("moretab")) {
                $('span[smltaberr="MoreTab"]').removeClass("hidden");
            }
        }
    }

    return isValid;
}

function isProjRefFormIsOpen() {
    isValid = true;

    if ($("#ProjectReferenceForm").length > 0) {
        if (!$("#ProjectReferenceForm").hasClass("hidden")) {
            $("#addProjectReference").trigger("click");
            $('html, body').animate({
                scrollTop: $("#ProjectReferenceForm").offset().top - 270
            }, 2000);
            $("#loadermain").addClass("hidden");
            isValid = false;
        }
        else
            isValid = true;
    }

    return isValid;
}

function ExistIndividualNRIC() {
    let isValid = true;
    if ($("#tbodyATC .AtcTabFileCat").filter(function () { return $(this).val() == "SLI-0368"; }).length <= 0) {
        Swal.fire({
            title: "<span class='swal-custom-title'>Missing NRIC / Passport No Attachment</span>",
            html: "<span class='swal-custom-text'>Please upload NRIC / Passport No Attachment before proceeding.</span>",
            confirmButtonColor: "#16a085",
            confirmButtonText: "OK",
            icon: "warning",
        })
        isValid = false;
    }
    return isValid;
}
//#endregion